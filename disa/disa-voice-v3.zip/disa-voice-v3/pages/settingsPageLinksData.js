import Keys from "../constants/Keys";
import Colors from "../constants/Colors";

const settingsPageLinksData = {
  support: [
    {
      name: "Privacy & Terms",
      icon: "information",
      backgroundColor: Colors.greenwa,
      url: Keys.urlDisaPolicy, // Add URL here
    },
    {
      name: "Help Center",
      icon: "help",
      backgroundColor: Colors.greenwa,
      url: Keys.urlDisaHome, // Add URL here
    },
    
  ],
};

export default settingsPageLinksData;
