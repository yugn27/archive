import { useState, useEffect } from "react";
import Colors from "../constants/Colors";
import {
  View,
  Text,
  Linking,
  TouchableOpacity,
  KeyboardAvoidingView,
  Platform,
  TextInput,
  ActivityIndicator,
  Alert,
} from "react-native";
import Keys from "../constants/Keys";
import styles from "../constants/SignUpScreen.styles";

const SignUp = ({ navigation }) => {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [mobileNumber, setMobileNumber] = useState("");
  const [corporateCode, setCorporateCode] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [isFormValid, setIsFormValid] = useState(false);

  const keyboardVerticalOffset = Platform.OS === "ios" ? 90 : 0;

  useEffect(() => {
    // Update form validity whenever mobile number or password changes
    setIsFormValid(mobileNumber !== "" && password !== "");
  }, [mobileNumber, password]);

  const openLink = () => {
    Linking.openURL(Keys.urlDisaHome);
  };

  const handleSignUp = async () => {
    setLoading(true); // Set loading state to true on button press
    try {
      const response = await fetch(Keys.apiURLDisa + "/signup", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          id: "0",
          name: name,
          email: email,
          mobile_number: mobileNumber,
          corporate_code: corporateCode,
          password: password,
        }),
      });

      const data = await response.json();
      console.log("Signup Response:", data);
      Alert.alert("Sign Up", "Your account have been created.");

      // Handle navigation or any other logic based on response
      if (response.ok) {
        navigation.navigate("SignIn", { name: "Sign In" });
      } else {
        // Handle error or validation messages
        console.error("Signup Error:", data.detail);
        // Example: Alert.alert('Error', data.detail);

        // Handle error or validation messages
        //console.error("Signup Error:", data.detail);
        Alert.alert(
          "Error",
          data.detail || "Failed to sign up. Please try again."
        );
      }
    } catch (error) {
      console.error("Error signing up:", error);
      Alert.alert(
        "Error",
        "Failed to connect to the server. Please try again later."
      );
    } finally {
      setLoading(false); // Set loading state to false after request is complete
    }
  };

  return (
    <KeyboardAvoidingView
      keyboardVerticalOffset={keyboardVerticalOffset}
      style={{ flex: 1 }}
      behavior="padding"
    >
      <View style={styles.container}>
        <Text style={styles.description}>
          Please enter your details to sign up.
        </Text>

        <View style={styles.list}>
          <TextInput
            style={styles.input}
            placeholder="Name"
            placeholderTextColor="#000000"
            value={name}
            onChangeText={setName}
          />

          <TextInput
            style={styles.input}
            placeholder="Email"
            placeholderTextColor="#000000"
            value={email}
            onChangeText={setEmail}
            keyboardType="email-address"
          />

          <TextInput
            style={styles.input}
            placeholder="Mobile Number"
            placeholderTextColor="#000000"
            value={mobileNumber}
            onChangeText={setMobileNumber}
            keyboardType="phone-pad"
          />

          <TextInput
            style={styles.input}
            placeholder="Corporate Code"
            placeholderTextColor="#000000"
            value={corporateCode}
            onChangeText={setCorporateCode}
          />

          <TextInput
            style={styles.input}
            placeholder="Password"
            placeholderTextColor="#000000"
            value={password}
            onChangeText={setPassword}
            secureTextEntry
          />
        </View>

        <Text style={styles.legal}>
          You must be{" "}
          <Text style={styles.link} onPress={openLink}>
            at least 16 years old
          </Text>{" "}
          to register. Learn how Disa works with the{" "}
          <Text style={styles.link} onPress={openLink}>
            Disa Solutions
          </Text>
        </Text>

        <View style={{ flex: 1 }} />

        <Text style={styles.legal}>
          Already have an account?{" "}
          <Text
            style={styles.link}
            onPress={() =>
              navigation.navigate("SignIn", { name: "About Page" })
            }
          >
            SignIn Now
          </Text>
        </Text>

        <TouchableOpacity
          style={[
            styles.button,
            { marginBottom: 20 },
            {
              backgroundColor:
                loading || !isFormValid ? "grey" : Colors.greenwa,
            },
          ]}
          onPress={handleSignUp}
          disabled={loading || !isFormValid} // Disable the button when loading or form is invalid
        >
          {loading ? (
            <ActivityIndicator color={Colors.white} size="large" />
          ) : (
            <Text style={[styles.buttonText, styles.enabled]}>Sign Up</Text>
          )}
        </TouchableOpacity>
      </View>
    </KeyboardAvoidingView>
  );
};

export default SignUp;
