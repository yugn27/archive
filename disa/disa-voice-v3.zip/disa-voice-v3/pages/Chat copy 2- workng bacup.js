import React, { useEffect, useState, useCallback } from "react";
import {
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  TextInput,
  KeyboardAvoidingView,
  Platform,
  ImageBackground,
} from "react-native";
import { useNavigation, useRoute } from "@react-navigation/native";
import Ionicons from "react-native-vector-icons/Ionicons";
import AsyncStorage from "@react-native-async-storage/async-storage";
import Voice from '@react-native-voice/voice';
import { useAuth } from "../AuthContext";
import Colors from "../constants/Colors";
import Keys from "../constants/Keys";
import styles from "../constants/ChatScreen.styles";

function ChatScreen() {
  const { accessToken } = useAuth();
  const route = useRoute();
  const { chatId, userName } = route.params;

  const [messages, setMessages] = useState([]);
  const [messageText, setMessageText] = useState("");
  const [isListening, setIsListening] = useState(false);

  useEffect(() => {
    loadMessagesFromStorage();
    fetchMessages(chatId);

    // Voice recognition setup
    Voice.onSpeechStart = onSpeechStart;
    Voice.onSpeechEnd = onSpeechEnd;
    Voice.onSpeechResults = onSpeechResults;
    Voice.onSpeechError = onSpeechError;

    return () => {
      Voice.destroy().then(Voice.removeAllListeners);
    };
  }, [chatId]);

  const onSpeechStart = (e) => {
    console.log("onSpeechStart: ", e);
  };

  const onSpeechEnd = (e) => {
    console.log("onSpeechEnd: ", e);
    setIsListening(false);
  };

  const onSpeechResults = (e) => {
    console.log("onSpeechResults: ", e);
    const text = e.value[0];
    setMessageText(text);
  };

  const onSpeechError = (e) => {
    console.error("onSpeechError: ", e);
    setIsListening(false);
  };

  const startListening = async () => {
    try {
      await Voice.start("en-US");
      setIsListening(true);
    } catch (error) {
      console.error("Error starting voice recognition: ", error);
      setIsListening(false);
    }
  };

  const stopListening = async () => {
    try {
      await Voice.stop();
      setIsListening(false);
    } catch (error) {
      console.error("Error stopping voice recognition: ", error);
      setIsListening(false);
    }
  };

  const loadMessagesFromStorage = async () => {
    try {
      const messagesJson = await AsyncStorage.getItem(
        `@chat_messages_${chatId}`
      );
      if (messagesJson) {
        const storedMessages = JSON.parse(messagesJson);
        setMessages(storedMessages);
      }
    } catch (error) {
      console.error("Error loading messages from AsyncStorage:", error);
    }
  };

  const fetchMessages = useCallback(
    (chatId) => {
      fetch(Keys.apiURLDisa + `/chats/${chatId}/messages`, {
        headers: {
          Accept: "application/json",
          Authorization: `Bearer ${accessToken}`,
        },
      })
        .then((response) => response.json())
        .then((data) => {
          setMessages(data);
          storeMessagesInStorage(data);
        })
        .catch((error) => console.error("Error fetching messages:", error));
    },
    [accessToken]
  );

  const storeMessagesInStorage = async (messages) => {
    try {
      await AsyncStorage.setItem(
        `@chat_messages_${chatId}`,
        JSON.stringify(messages)
      );
    } catch (error) {
      console.error("Error storing messages in AsyncStorage:", error);
    }
  };

  const sendMessage = () => {
    if (!messageText.trim()) {
      return;
    }

    fetch(Keys.apiURLDisa + `/chats/${chatId}/send-message`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${accessToken}`,
      },
      body: JSON.stringify({
        message: messageText,
      }),
    })
      .then((response) => response.json())
      .then((data) => {
        setMessages(data);
        setMessageText("");
        fetchMessages(chatId);
      })
      .catch((error) => console.error("Error sending message:", error));
  };

  const renderMessages = () => {
    if (!messages || !Array.isArray(messages)) {
      return null;
    }

    return messages.map((message) => (
      <View
        key={message.message_id}
        style={[
          styles.bubble,
          message.sender_name !== "Disa AI" ? styles.sent : styles.received,
        ]}
      >
        <Text style={styles.bubbleTextName}>{message.sender_name}</Text>
        <Text style={styles.bubbleText}>{message.message}</Text>
        <Text style={styles.timestamp}>
          {new Date(message.sent_at).toLocaleTimeString([], {
            hour: "2-digit",
            minute: "2-digit",
          })}
        </Text>
      </View>
    ));
  };

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === "ios" ? "padding" : "height"}
      keyboardVerticalOffset={Platform.OS === "ios" ? 64 : 0}
    >
      <ScrollView
        style={styles.chatBubbleContainer}
        contentContainerStyle={{ paddingBottom: 20 }}
        keyboardDismissMode="on-drag"
      >
        {renderMessages()}
      </ScrollView>

      <View style={styles.inputToolbar}>
        <TouchableOpacity onPress={isListening ? stopListening : startListening}>
          <Ionicons
            name="mic-circle-outline"
            color={isListening ? Colors.red : Colors.greenwa}
            size={28}
          />
        </TouchableOpacity>
        <View style={styles.inputContainer}>
          <TextInput
            style={styles.input}
            placeholder="Type a message..."
            placeholderTextColor={Colors.gray}
            value={messageText}
            onChangeText={(text) => setMessageText(text)}
            onSubmitEditing={sendMessage}
          />
        </View>

        <TouchableOpacity onPress={sendMessage}>
          <Ionicons
            name="arrow-redo-circle-outline"
            color={Colors.greenwa}
            size={28}
          />
        </TouchableOpacity>
      </View>
    </KeyboardAvoidingView>
  );
}

export default ChatScreen;
