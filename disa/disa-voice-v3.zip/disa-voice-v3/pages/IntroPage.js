import {
  View,
  Text,
  Image,
  TouchableOpacity,
  Linking,
  Button,
} from "react-native";
import Keys from "../constants/Keys";
import styles from "../constants/IntroScreen.styles";
import welcomeImage from "../assets/images/welcome.png";
const welcome_image = Image.resolveAssetSource(welcomeImage).uri;

const IntroPage = ({ navigation }) => {
  const openLink = () => {
    Linking.openURL(Keys.urlDisaHome);
  };

  return (
    <View style={styles.container}>
      <Image source={{ uri: welcome_image }} style={styles.welcome} />
      <Text style={styles.headline}>Welcome to Disa</Text>
      <Text style={styles.description}>
        Read our{" "}
        <Text style={styles.link} onPress={openLink}>
          Privacy Policy
        </Text>
        . {'Tap "Agree & Continue" to accept the '}
        <Text style={styles.link} onPress={openLink}>
          Terms of Service
        </Text>
        .
      </Text>
      <TouchableOpacity style={styles.button}>
        <Text style={styles.buttonText}>
          {" "}
          <Button
            title="Agree & Continue"
            onPress={() =>
              navigation.navigate("SignUp", { name: "About Page" })
            }
          />
        </Text>
      </TouchableOpacity>
    </View>
  );
};

<Button
  title="Go to About Page"
  onPress={() => navigation.navigate("About")}
/>;

export default IntroPage;
