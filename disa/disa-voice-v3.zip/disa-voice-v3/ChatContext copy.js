// Create a new file: ChatContext.js
import React, { createContext, useState, useContext } from 'react';

const ChatContext = createContext();

export const ChatProvider = ({ children }) => {
  const [chatId, setChatId] = useState(null);

  const setChat = (id) => {
    setChatId(id);
  };

  return (
    <ChatContext.Provider value={{ chatId, setChat }}>
      {children}
    </ChatContext.Provider>
  );
};

export const useChat = () => useContext(ChatContext);
