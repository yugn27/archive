// AuthContext.js
import React, { createContext, useContext, useState, useEffect } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';

const AuthContext = createContext();

export const useAuth = () => useContext(AuthContext);

export const AuthProvider = ({ children }) => {
  const [accessToken, setAccessToken] = useState(null);

  useEffect(() => {
    // Load token from AsyncStorage when the app starts
    loadToken();
  }, []);

  const loadToken = async () => {
    try {
      const token = await AsyncStorage.getItem('accessToken');
      if (token) {
        setAccessToken(token);
      }
    } catch (error) {
      console.error('Error loading token:', error);
    }
  };

  const setToken = async (token) => {
    try {
      await AsyncStorage.setItem('accessToken', token);
      setAccessToken(token);
    } catch (error) {
      console.error('Error saving token:', error);
    }
  };

  const removeToken = async () => {
    try {
      await AsyncStorage.removeItem('accessToken');
      setAccessToken(null);
    } catch (error) {
      console.error('Error removing token:', error);
    }
  };

  return (
    <AuthContext.Provider value={{ accessToken, setToken, removeToken }}>
      {children}
    </AuthContext.Provider>
  );
};