import React, { useEffect, useState } from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { NavigationContainer } from "@react-navigation/native";
import { createStackNavigator } from "@react-navigation/stack";
import Colors from "./constants/Colors";
import { Avatar, Header } from "react-native-elements";
import { View, Text, TouchableOpacity } from "react-native";
import Ionicons from "react-native-vector-icons/Ionicons";
import Keys from "./constants/Keys";

//Pages
import IntroPage from "./pages/IntroPage";
import SignUp from "./pages/SignUp";
import SignIn from "./pages/SignIn";
import Home from "./pages/Home";
import Chat from "./pages/Chat";

//Auth
import { AuthProvider } from "./AuthContext";
import { useAuth } from "./AuthContext";

import { UserProvider } from "./UserContext";

import ContactInfo from "./pages/ContactInfo"; // Import ContactInfo component

const Stack = createStackNavigator();

function App() {
  const [isLoading, setIsLoading] = useState(true);
  const [initialRoute, setInitialRoute] = useState("IntroPage");

  useEffect(() => {
    checkToken();
  }, []);

  const checkToken = async () => {
    try {
      const token = await AsyncStorage.getItem("accessToken");
      if (token) {
        setInitialRoute("Home");
      }
    } catch (error) {
      console.error("Error checking token:", error);
    } finally {
      setIsLoading(false);
    }
  };

  if (isLoading) {
    return (
      <View>
        <Text>Loading...</Text>
      </View>
    ); // Or use a loading spinner
  }

  return (
    <UserProvider>
      <AuthProvider>
        <NavigationContainer>
          <Stack.Navigator initialRouteName={initialRoute}>
            <Stack.Screen
              name="IntroPage"
              component={IntroPage}
              options={{ headerShown: false }}
            />

            <Stack.Screen
              name="SignUp"
              component={SignUp}
              options={{
                headerTitle: "Create a New Account",
                headerLeft: null,
                headerStyle: { backgroundColor: Colors.white },
                headerTitleStyle: { color: "black" },
              }}
            />

            <Stack.Screen
              name="SignIn"
              component={SignIn}
              options={{
                headerTitle: "Welcome to Disa",
                headerLeft: null,
                headerStyle: { backgroundColor: Colors.white },
                headerTitleStyle: { color: "black" },
              }}
            />

            <Stack.Screen
              name="Home"
              component={Home}
              options={{
                headerTitle: "Welcome to Disa",
                headerShown: false,
                headerStyle: { backgroundColor: Colors.greenwa },
                headerTitleStyle: { color: "white" },
              }}
            />

            <Stack.Screen
              name="Chat"
              component={Chat}
              options={({ route, navigation }) => ({
                header: (props) => (
                  <Header
                    containerStyle={{ backgroundColor: Colors.white }}
                    leftComponent={
                      <TouchableOpacity
                        onPress={() => navigation.goBack()}
                        style={{ paddingLeft: 10 }}
                      >
                        <Ionicons
                          name="arrow-back-outline"
                          size={28}
                          color={Colors.black}
                        />
                      </TouchableOpacity>
                    }
                    centerComponent={
                      <TouchableOpacity
                        onPress={() =>
                          props.navigation.navigate("ContactInfo", {
                            userName: route.params.userName,
                            chatId: route.params.chatId,
                          })
                        }
                      >
                        <View
                          style={{ flexDirection: "row", alignItems: "center" }}
                        >
                          <Avatar
                            source={{
                              uri: "https://i.ibb.co/jMGm6Ck/Screenshot-2024-06-09-191108.png",
                            }}
                            size={28}
                            rounded
                          />
                          <Text
                            style={{
                              color: Colors.black,
                              marginLeft: 10,
                              fontSize: 16,
                              fontWeight: "500",
                            }}
                          >
                            {route.params.userName} ({route.params.chatId})
                          </Text>
                        </View>
                      </TouchableOpacity>
                    }
                    rightComponent={
                      <ChatActionButton
                        chatId={route.params.chatId}
                        fetchMessages={route.params.fetchMessages}
                      />
                    }
                  />
                ),
              })}
            />

            <Stack.Screen
              name="ContactInfo"
              component={ContactInfo}
              options={({ route }) => ({
                header: (props) => (
                  <Header
                    containerStyle={{ backgroundColor: Colors.white }}
                    leftComponent={
                      <TouchableOpacity
                        onPress={() => props.navigation.goBack()}
                        style={{ paddingLeft: 10 }}
                      >
                        <Ionicons
                          name="arrow-back-outline"
                          size={28}
                          color={Colors.black}
                        />
                      </TouchableOpacity>
                    }
                    centerComponent={
                      <TouchableOpacity>
                        <View
                          style={{ flexDirection: "row", alignItems: "center" }}
                        >
                          <Text
                            style={{
                              color: Colors.black,
                              marginLeft: 10,
                              fontSize: 16,
                              fontWeight: "500",
                            }}
                          >
                            Task Information
                          </Text>
                        </View>
                      </TouchableOpacity>
                    }
                  />
                ),
              })}
            />
          </Stack.Navigator>
        </NavigationContainer>
      </AuthProvider>
    </UserProvider>
  );
}

// Custom component for action button in the header
// In App.js
const ChatActionButton = ({ chatId, fetchMessages }) => {

const [templateText, setTemplateText] = useState('');


useEffect(() => {
    const fetchTemplateText = async () => {
      try {
        const userData = await AsyncStorage.getItem('userData');
        if (userData) {
          const parsedUserData = JSON.parse(userData);
          setTemplateText(parsedUserData.template_text || '');
        }
      } catch (error) {
        console.error('Error fetching template text:', error);
      }
    };

    fetchTemplateText();
  }, []);



  const { accessToken } = useAuth();
  const [loading, setLoading] = useState(false);

  const fetchChatMessages = async () => {
    setLoading(true);
    try {
      const response = await fetch(
        Keys.apiURLDisa + `/chats/${chatId}/messages`,
        {
          headers: {
            Accept: "application/json",
            Authorization: `Bearer ${accessToken}`,
          },
        }
      );
      const data = await response.json();

      // Check if there are no messages
      if (data.length === 0) {
        alert("No messages in this chat.");
        return;
      }

      console.log(JSON.stringify(data)); // Log the raw data received

      // Format the messages into a single human-readable string
      var formattedMessages = data
        .map((msg) => {
          return `${msg.sent_at} - ${msg.sender_name}: ${msg.message}`;
        })
        .join("\n");

      console.log( templateText + " " + formattedMessages); // Log the formatted messages



      const url = Keys.apiURLOpenai;
      //console.log("templateText yashnayak te : " +templateText)
      const openaiData = {
        model: "gpt-4o",
        messages: [
         
          {
            role: "user",
            content:
              templateText + " " + formattedMessages,
          },
        ],


        temperature: 0.7,
      };

      console.log(openaiData)

      // Perform OpenAI API request
      const openaiResponse = await fetch(url, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: "Bearer " + Keys.apiKeyOpenai,
        },
        body: JSON.stringify(openaiData),
      });

      const openaiDataResponse = await openaiResponse.json();

      console.log(openaiDataResponse.choices[0].message.content); // Log the content of the response

      // Send the generated response message to the chat
      const sendMessageResponse = await fetch(
        Keys.apiURLDisa + `/chats/${chatId}/send-message-bot`,
        {
          method: "POST",
          headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
            Authorization: `Bearer ${accessToken}`,
          },
          body: JSON.stringify({
            message: openaiDataResponse.choices[0].message.content,
          }),
        }
      );
      const sendMessageData = await sendMessageResponse.json();
      console.log(sendMessageData);
      handleFetchAndAnalyze();
    } catch (error) {
      console.error("Error:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleFetchAndAnalyze = async () => {
    setLoading(true);
    try {
      // Call fetchMessages to update the messages
      await fetchMessages();
      alert("Analysis Done!");
    } catch (error) {
      console.error("Error:", error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={{ flexDirection: "row", gap: 14 }}>
      <TouchableOpacity
        onPress={fetchChatMessages}
        disabled={loading}
        style={{
          opacity: loading ? 0.5 : 1,
        }}
      >
        <Ionicons name="sparkles-outline" color={Colors.greenwa} size={24} />
      </TouchableOpacity>
    </View>
  );
};

export default App;
