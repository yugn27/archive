export default {
  apiURLDisa:
    "https://fhzjvjrhkf.execute-api.eu-north-1.amazonaws.com",
  apiURLOpenai: "https://api.openai.com/v1/chat/completions",
  urlDisaHome: "http://ambiotics.com/disa",
  urlDisaPolicy: "http://ambiotics.com/disa/policy.html",
  apiKeyOpenai: "sk-proj-pCOjwdIyMzLooNQbiDBET3BlbkFJJJGRGLVK8OXeesNH0l6n",
};

//apiURLDisa: 'https://04d1d439-aa82-4245-858e-732db64bddc2-00-xfgvjquhwtgn.worf.replit.dev',
//apiURLDisa: 'http://13.48.218.234',
// https://fhzjvjrhkf.execute-api.eu-north-1.amazonaws.com/docs