import { StyleSheet } from "react-native";
import Colors from "./Colors";

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  chatBubbleContainer: {
    flex: 1,
    padding: 10,
  },
  bubble: {
    maxWidth: "80%",
    padding: 10,
    borderRadius: 10,
    marginVertical: 5,
  },
  received: {
    backgroundColor: "#fff",
    alignSelf: "flex-start",
    marginLeft: 10,
  },
  sent: {
    backgroundColor: Colors.lightGreen,
    alignSelf: "flex-end",
    marginRight: 10,
  },
  bubbleText: {
    fontSize: 16,
  },
  inputToolbar: {
    flexDirection: "row",
    alignItems: "center",
    padding: 10,
    paddingBottom: "8%",
    backgroundColor: "#ffffff",
  },
  inputContainer: {
    flex: 1,
    backgroundColor: "#fff",
    borderRadius: 18,
    borderWidth: 1,
    borderColor: Colors.lightGray,
    paddingHorizontal: 10,
    paddingVertical: 8,
    marginHorizontal: 10,
  },
  inputContainer2: {
    //paddingHorizontal: 15,
    paddingRight: 16,

    //marginHorizontal: 8,
  },
  bubbleTextName: {
    fontSize: 12,
    fontWeight: "bold",
    marginBottom: 4,
    color: Colors.greenwa,
  },
  timestamp: {
    color: "#888",
    marginTop: 4,
    alignSelf: "flex-end",
  },
  backgroundpattern: {
    flex: 1,
    resizeMode: "cover",
  },

  encryptionMessageInner: {
    flexDirection: "row",
    alignItems: "center",
  },
  encryptionIcon: {
    marginRight: 8,
  },
  encryptionMessage: {
    fontSize: 14,
    color: "#54656f",
    flex: 1,
  },

  starContainer: {
    flexDirection: "row",
  },
  star: {
    marginHorizontal: 2,
  },

  linefeeback: {
    borderBottomColor: "#ccc", // Adjust color as needed
    borderBottomWidth: 1, // Adjust thickness as needed
    marginVertical: 10, // Adjust vertical spacing as needed
  },


  copyButton: {
  position: 'absolute',
  top: 5,
  right: 5,
  padding: 5,
},


messageHeader: {
  flexDirection: 'row',
  justifyContent: 'space-between',
  alignItems: 'center',
  marginBottom: 5,
},



});

export default styles;
