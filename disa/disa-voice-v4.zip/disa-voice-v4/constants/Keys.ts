export default {
  apiURLDisa:
    "https://fhzjvjrhkf.execute-api.eu-north-1.amazonaws.com",
  apiURLOpenai: "https://api.openai.com/v1/chat/completions",
  urlDisaHome: "http://ambiotics.com/disa",
  urlDisaPolicy: "http://ambiotics.com/disa/policy.html",
  apiKeyOpenai: "sk-proj-pCOjwdIyMzLooNQbiDBET3BlbkFJJJGRGLVK8OXeesNH0l6n",
};

//apiURLDisa: 'https://04d1d439-aa82-4245-858e-732db64bddc2-00-xfgvjquhwtgn.worf.replit.dev',
//apiURLDisa: 'http://13.48.218.234',
// https://fhzjvjrhkf.execute-api.eu-north-1.amazonaws.com/docs

//https://d1864aa2-f43b-4f55-9315-1dac2f4aec3f-00-2c0azr23tmxxp.spock.replit.dev/docs#/default/get_user_chats_allchats_get

//  apiURLDisa: "https://fhzjvjrhkf.execute-api.eu-north-1.amazonaws.com",