import { useState } from "react";
import Colors from "../constants/Colors";
import {
  View,
  Text,
  Linking,
  TouchableOpacity,
  KeyboardAvoidingView,
  Platform,
  TextInput,
  Alert,
  ActivityIndicator,
} from "react-native";
import { useNavigation } from "@react-navigation/native";
import { useAuth } from "../AuthContext";
import Keys from "../constants/Keys";
import styles from "../constants/SignInScreen.styles";
import AsyncStorage from "@react-native-async-storage/async-storage";

const SignIn = () => {
  const { setToken } = useAuth();

  const [mobileNumber, setMobileNumber] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const navigation = useNavigation();
  const keyboardVerticalOffset = Platform.OS === "ios" ? 90 : 0;

  const [userData, setUserData] = useState(null); // State to hold user data
  const [valueTokenYash, setValueTokenYash] = useState('');


  const openLink = () => {
    Linking.openURL(Keys.urlDisaHome);
  };


 const fetchUserData = async () => {
      try {
        const storedData = await AsyncStorage.getItem("userData");
        //console.log("storedData " + storedData);
        if (storedData) {
          const parsedData = JSON.parse(storedData);
          if (parsedData.detail && parsedData.detail === "Invalid token") {
            // If stored data indicates token is invalid, fetch from API
            await fetchDataFromAPI();
          } else {
            // Use stored data
            setUserData(parsedData);
          }
        } else {
          // Fetch user data from API if not stored in AsyncStorage
          await fetchDataFromAPI();
        }
      } catch (error) {
        console.error("Error fetching user data:", error);
        if (storedData) {
          const parsedData = JSON.parse(storedData);
          if (parsedData.detail && parsedData.detail === "Invalid token") {
            // If stored data indicates token is invalid, fetch from API
            await fetchDataFromAPI();
          } else {
            // Use stored data
            setUserData(parsedData);
          }
        } else {
          // Fetch user data from API if not stored in AsyncStorage
          await fetchDataFromAPI();
        }
      }
    };

    const fetchDataFromAPI = async () => {
    try {
      const response = await fetch(Keys.apiURLDisa + "/users/me", {
        headers: {
          Accept: "application/json",
          Authorization: `Bearer ${valueTokenYash}`,
        },
      });
      if (response.ok) {
        const data = await response.json();
        setUserData(data); // Set user data in state
        await AsyncStorage.setItem("userData", JSON.stringify(data)); // Store user data in AsyncStorage
      } else {
        console.error("Failed to fetch user data:", response.status);
        // Optionally handle token expiration or other errors here
      }
    } catch (error) {
      console.error("Error fetching user data:", error);
    }
  };


  const handleSignIn = async () => {
    setLoading(true); // Set loading state to true on button press
    try {
      const formData = new URLSearchParams();
      formData.append("grant_type", "password");
      formData.append("username", mobileNumber);
      formData.append("password", password);
      formData.append("scope", "");
      formData.append("client_id", "string");
      formData.append("client_secret", "string");

      const response = await fetch(Keys.apiURLDisa + "/signin", {
        method: "POST",
        headers: {
          "Content-Type": "application/x-www-form-urlencoded",
          Accept: "application/json",
        },
        body: formData.toString(),
      });

      if (!response.ok) {
        if (response.status === 401) {
          throw new Error("Invalid mobile number or password");
        } else {
          throw new Error("Server connection failed");
        }
      }

      const data = await response.json();




     // setValueTokenYash(data.access_token);
      // fetchUserData(); // Fetch user data when component mounts
      console.log("Access Token:", data.access_token);

      // Use the setToken function from AuthContext
      await setToken(data.access_token);
      navigation.navigate("Home");
    } catch (error) {
      console.error("Sign in error:", error.message);
      if (error.message === "Invalid mobile number or password") {
        Alert.alert(
          "Sign In Failed",
          "Invalid username or password. Please try again."
        );
      } else {
        Alert.alert(
          "Sign In Failed",
          "Unable to connect. Please contact the Disa Team."
        );
      }
    } finally {
      setLoading(false); // Set loading state to false after request is complete
    }
  };

  const isFormValid = mobileNumber.trim() !== "" && password.trim() !== "";

  return (
    <KeyboardAvoidingView
      keyboardVerticalOffset={keyboardVerticalOffset}
      style={{ flex: 1 }}
      behavior="padding"
    >
      <View style={styles.container}>
        <Text style={styles.description}>
          Please enter your details to sign in.
        </Text>

        <View style={styles.list}>
          <TextInput
            style={styles.input}
            placeholder="Mobile Number"
            placeholderTextColor="#000000"
            value={mobileNumber}
            onChangeText={setMobileNumber}
            keyboardType="phone-pad"
          />

          <TextInput
            style={styles.input}
            placeholder="Password"
            placeholderTextColor="#000000"
            value={password}
            onChangeText={setPassword}
            secureTextEntry
          />
        </View>

        <Text style={styles.legal}>
          You must be{" "}
          <Text style={styles.link} onPress={openLink}>
            at least 16 years old
          </Text>{" "}
          to register. Learn how Disa works with the{" "}
          <Text style={styles.link} onPress={openLink}>
            Disa Solutions
          </Text>
          .
        </Text>

        <View style={{ flex: 1 }} />

        <TouchableOpacity
          style={[
            styles.button,
            {
              marginBottom: 20,
              backgroundColor:
                loading || !isFormValid ? "grey" : Colors.greenwa,
            },
          ]}
          onPress={handleSignIn}
          disabled={loading || !isFormValid} // Disable the button when loading is true or form is not valid
        >
          {loading ? (
            <ActivityIndicator color={Colors.white} size="large" />
          ) : (
            <Text style={[styles.buttonText, styles.enabled]}>Sign In</Text>
          )}
        </TouchableOpacity>
      </View>
    </KeyboardAvoidingView>
  );
};

export default SignIn;
