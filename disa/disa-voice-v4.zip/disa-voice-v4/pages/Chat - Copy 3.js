import React, { useEffect, useState, useCallback, useRef } from "react";
import {
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  TextInput,
  KeyboardAvoidingView,
  Platform,
  Alert,
   Clipboard, TouchableWithoutFeedback, ActionSheetIOS 
} from "react-native";



import { useNavigation, useRoute } from "@react-navigation/native";
import Ionicons from "react-native-vector-icons/Ionicons";
import AsyncStorage from "@react-native-async-storage/async-storage";
//import Voice from '@react-native-voice/voice';
import { useAuth } from "../AuthContext";
import Colors from "../constants/Colors";
import Keys from "../constants/Keys";
import styles from "../constants/ChatScreen.styles";

function ChatScreen({ navigation }) {
  const { accessToken } = useAuth();
  const route = useRoute();
  const { chatId, userName } = route.params;
  const [selectedMessageId, setSelectedMessageId] = useState(null);

  const [messages, setMessages] = useState([]);
  const [messageText, setMessageText] = useState("");
  const [isListening, setIsListening] = useState(false);
  const [loading, setLoading] = useState(true);

  const [rating, setRating] = useState(0); // State to hold the current rating

  const scrollViewRef = useRef(null);
  const inputScrollViewRef = useRef(null);

  const [templateChecklist, setTemplateChecklist] = useState("");

  useEffect(() => {
    const fetchTemplateChecklist = async () => {
      try {
        const userData = await AsyncStorage.getItem("userData");
        if (userData) {
          const parsedUserData = JSON.parse(userData);
          setTemplateChecklist(parsedUserData.checklist || "");
        }
      } catch (error) {
        console.error("Error fetching template text:", error);
      }
    };

    fetchTemplateChecklist();
  }, []);

  useEffect(() => {
    loadMessagesFromStorage();
    fetchMessages(chatId);
  }, [chatId]);

  //working for load disa chat
  useEffect(() => {
    if (navigation) {
      navigation.setParams({
        fetchMessages: () => fetchMessages(chatId),
      });
    }
  }, [navigation, fetchMessages, chatId]);

  const loadMessagesFromStorage = async () => {
    try {
      const messagesJson = await AsyncStorage.getItem(
        `@chat_messages_${chatId}`
      );
      if (messagesJson) {
        const storedMessages = JSON.parse(messagesJson);
        setMessages(storedMessages);
      }
    } catch (error) {
      console.error("Error loading messages from AsyncStorage:", error);
    } finally {
      setLoading(false); // Ensure loading state is set to false after attempt
    }
  };


  const copyToClipboard = (text) => {
  Clipboard.setString(text);
  Alert.alert("Copied", "Message copied to clipboard");
};




const handleLongPress = (message) => {
  if (Platform.OS === 'ios') {
    ActionSheetIOS.showActionSheetWithOptions(
      {
        options: ['Copy', 'Cancel'],
        cancelButtonIndex: 1,
      },
      (buttonIndex) => {
        if (buttonIndex === 0) {
          Clipboard.setString(message);
          Alert.alert('Copied', 'Message copied to clipboard');
        }
      }
    );
  } else {
    // For Android, we'll use a simple Alert
    Alert.alert(
      'Copy Message',
      'Do you want to copy this message?',
      [
        {
          text: 'Cancel',
          style: 'cancel'
        },
        {
          text: 'Copy',
          onPress: () => {
            Clipboard.setString(message);
            Alert.alert('Copied', 'Message copied to clipboard');
          }
        }
      ]
    );
  }
};

  const fetchMessages = useCallback(
    async (chatId) => {
      console.log("Called fetchMessages yash");
      try {
        const response = await fetch(
          Keys.apiURLDisa + `/chats/${chatId}/messages`,
          {
            headers: {
              Accept: "application/json",
              Authorization: `Bearer ${accessToken}`,
            },
          }
        );
        const data = await response.json();
        setMessages(data);
        await storeMessagesInStorage(data);
      } catch (error) {
        console.error("Error fetching messages:", error);
      }
    },
    [accessToken]
  );

  const storeMessagesInStorage = async (messages) => {
    try {
      await AsyncStorage.setItem(
        `@chat_messages_${chatId}`,
        JSON.stringify(messages)
      );
    } catch (error) {
      console.error("Error storing messages in AsyncStorage:", error);
    }
  };

  const sendMessageDummy = async () => {
    alert("Disabled for this build!");
  };

  const sendMessage = async () => {
    if (!messageText.trim()) {
      return;
    }

    const newMessage = {
      message_id: Date.now().toString(),
      sender_name: "You",
      //sender_name: userName,
      message: messageText,
      sent_at: new Date().toISOString(),
    };

    const updatedMessages = [...messages, newMessage];
    setMessages(updatedMessages);

    try {
      await AsyncStorage.setItem(
        `@chat_messages_${chatId}`,
        JSON.stringify(updatedMessages)
      );
      setMessageText("");
    } catch (error) {
      console.error("Error storing message in AsyncStorage:", error);
    }

    setMessageText("");
    scrollToEnd();

    try {
      const response = await fetch(
        Keys.apiURLDisa + `/chats/${chatId}/send-message`,
        {
          method: "POST",
          headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
            Authorization: `Bearer ${accessToken}`,
          },
          body: JSON.stringify({
            message: newMessage.message,
          }),
        }
      );

      if (!response.ok) {
        throw new Error("Network response was not ok");
      }

      const data = await response.json();
      //storeMessagesInStorage(data);
    } catch (error) {
      console.error("Error sending message:", error);
    }

    setMessageText("");
  };

  const renderMessages_old = () => {
    if (loading) {
      return <Text>Loading...</Text>; // You can replace this with a better loading indicator
    }

    if (!messages || !Array.isArray(messages)) {
      return null;
    }

    return messages.map((message) => (
      <View
        key={message.message_id}
        style={[
          styles.bubble,
          message.sender_name !== "Disa AI" ? styles.sent : styles.received,
        ]}
      >
        <Text style={styles.bubbleTextName}>{message.sender_name}</Text>
        <Text style={styles.bubbleText}>{message.message}</Text>
        <Text style={styles.timestamp}>
          {new Date(message.sent_at).toLocaleTimeString([], {
            hour: "2-digit",
            minute: "2-digit",
          })}
        </Text>

        {message.sender_name === "Disa AI" && (
          <View style={styles.linefeeback} />
        )}

        {message.sender_name === "Disa AI" && (
          <TouchableOpacity
            style={styles.feedbackMessageContainer}
            // onPress={() => handleFeedbackSelect(message.message_id)}
          >
            <View style={styles.encryptionMessageInner}>
              <Ionicons
                name="podium-outline"
                size={16}
                color={Colors.greenwa}
                style={styles.encryptionIcon}
              />
              <Text style={styles.encryptionMessage}>Feedback</Text>
              <View style={styles.starContainer}>
                {renderStars(message.message_id)}
              </View>
            </View>
          </TouchableOpacity>
        )}
      </View>
    ));
  };


const renderMessages = () => {
  if (loading) {
    return <Text>Loading...</Text>;
  }

  if (!messages || !Array.isArray(messages)) {
    return null;
  }

  return messages.map((message) => (
    <TouchableWithoutFeedback
      key={message.message_id}
      onLongPress={() => handleLongPress(message.message)}
    >
      <View
        style={[
          styles.bubble,
          message.sender_name !== "Disa AI" ? styles.sent : styles.received,
        ]}
      >
        <Text style={styles.bubbleTextName}>{message.sender_name}</Text>
        <Text style={styles.bubbleText} selectable={true}>{message.message}</Text>
        <Text style={styles.timestamp}>
          {new Date(message.sent_at).toLocaleTimeString([], {
            hour: "2-digit",
            minute: "2-digit",
          })}
        </Text>

        {message.sender_name === "Disa AI" && (
          <View style={styles.linefeeback} />
        )}

        {message.sender_name === "Disa AI" && (
          <TouchableOpacity
            style={styles.feedbackMessageContainer}
          >
            <View style={styles.encryptionMessageInner}>
              <Ionicons
                name="podium-outline"
                size={16}
                color={Colors.greenwa}
                style={styles.encryptionIcon}
              />
              <Text style={styles.encryptionMessage}>Feedback</Text>
              <View style={styles.starContainer}>
                {renderStars(message.message_id)}
              </View>
            </View>
          </TouchableOpacity>
        )}
      </View>
    </TouchableWithoutFeedback>
  ));
};

  const renderMessages_v2 = () => {
  if (loading) {
    return <Text>Loading...</Text>;
  }

  if (!messages || !Array.isArray(messages)) {
    return null;
  }

  return messages.map((message) => (
    <View
      key={message.message_id}
      style={[
        styles.bubble,
        message.sender_name !== "Disa AI" ? styles.sent : styles.received,
      ]}
    >
      <Text style={styles.bubbleTextName}>{message.sender_name}</Text>
      <Text style={styles.bubbleText}>{message.message}</Text>
      <Text style={styles.timestamp}>
        {new Date(message.sent_at).toLocaleTimeString([], {
          hour: "2-digit",
          minute: "2-digit",
        })}
      </Text>

      <TouchableOpacity
        style={styles.copyButton}
        onPress={() => copyToClipboard(message.message)}
      >
        <Ionicons name="copy-outline" size={20} color={Colors.gray} />
      </TouchableOpacity>

      {message.sender_name === "Disa AI" && (
        <View style={styles.linefeeback} />
      )}

      {message.sender_name === "Disa AI" && (
        <TouchableOpacity
          style={styles.feedbackMessageContainer}
        >
          <View style={styles.encryptionMessageInner}>
            <Ionicons
              name="podium-outline"
              size={16}
              color={Colors.greenwa}
              style={styles.encryptionIcon}
            />
            <Text style={styles.encryptionMessage}>Feedback</Text>
            <View style={styles.starContainer}>
              {renderStars(message.message_id)}
            </View>
          </View>
        </TouchableOpacity>
      )}
    </View>
  ));
};

  const scrollToEnd = (ref) => {
    if (ref && ref.current) {
      ref.current.scrollToEnd({ animated: true });
    }
  };

  // Function to render stars for rating
  const renderStars = (messageId) => {
    let stars = [];
    for (let i = 1; i <= 5; i++) {
      stars.push(
        <TouchableOpacity
          key={i}
          onPress={() => handleRatingSelect(messageId, i)}
          style={styles.star}
        >
          <Ionicons
            name={i <= rating ? "star" : "star-outline"}
            size={24}
            color={i <= rating ? Colors.gold : Colors.gray}
          />
        </TouchableOpacity>
      );
    }
    return stars;
  };

  const handleRatingSelect = async (messageId, selectedRating) => {
    console.log("Selected Message ID: " + messageId);
    console.log("Selected Rating: " + selectedRating);

    setSelectedMessageId(messageId);
    setRating(selectedRating);

    try {
      // setLoading(true); // Set loading state while sending feedback

      const response = await fetch(
        Keys.apiURLDisa + `/messages/${messageId}/feedback`,
        {
          method: "PUT",
          headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
            Authorization: `Bearer ${accessToken}`,
          },
          body: JSON.stringify({
            feedback: selectedRating,
          }),
        }
      );

      if (!response.ok) {
        throw new Error("Network response was not ok");
      }

      const data = await response.json();
      console.log("Feedback sent successfully:", data);

      // Optionally update UI or handle response data
    } catch (error) {
      console.error("Error sending feedback:", error);
    } finally {
      //setLoading(false); // Reset loading state after feedback sent
      Alert.alert("Success", "Thanks for your feedback!");
      setSelectedMessageId(null); // Reset selected message ID (if needed)
    }
  };

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === "ios" ? "padding" : "height"}
      keyboardVerticalOffset={Platform.OS === "ios" ? 64 : 0}
    >
      <ScrollView
        style={styles.chatBubbleContainer}
        contentContainerStyle={{ paddingBottom: 20 }}
        keyboardDismissMode="on-drag"
        ref={scrollViewRef}
        onContentSizeChange={() => scrollToEnd(scrollViewRef)}
      >
        <View style={[styles.bubble, styles.received]}>
          <Text style={styles.bubbleTextName}>Checklist</Text>
          <Text style={styles.bubbleText}>{templateChecklist}</Text>
          <Text style={styles.timestamp}>00:00 AM</Text>
        </View>
        {renderMessages()}
      </ScrollView>

      <View style={styles.inputToolbar}>
        <TouchableOpacity onPress={sendMessageDummy}>
          <Ionicons
            name="mic-circle-outline"
            color={isListening ? Colors.red : Colors.greenwa}
            size={32}
          />
        </TouchableOpacity>
        <ScrollView
          style={styles.inputContainer}
          horizontal
          ref={inputScrollViewRef}
          onContentSizeChange={() => scrollToEnd(inputScrollViewRef)}
        >
          <TextInput
            style={styles.inputContainer2}
            placeholder="Type a message...                    "
            placeholderTextColor={Colors.gray}
            value={messageText}
            onChangeText={(text) => {
              setMessageText(text);
              scrollToEnd(inputScrollViewRef);
            }}
            onSubmitEditing={sendMessage}
          />
        </ScrollView>

        <TouchableOpacity onPress={sendMessage}>
          <Ionicons
            name="arrow-up-circle-outline"
            color={Colors.greenwa}
            size={32}
          />
        </TouchableOpacity>
      </View>
    </KeyboardAvoidingView>
  );
}

export default ChatScreen;
