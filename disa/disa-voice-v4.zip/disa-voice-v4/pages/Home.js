//Home.js code
import React, { useContext, useEffect, useState } from "react";
import { useFocusEffect } from "@react-navigation/native";
import Colors from "../constants/Colors";
import { defaultStyles } from "../constants/Styles";
import BoxedIcon from "../components/BoxedIcon";
import Keys from "../constants/Keys";
import AsyncStorage from "@react-native-async-storage/async-storage";
import {
  Image,
  Text,
  TouchableOpacity,
  View,
  ScrollView,
  FlatList,
  ActivityIndicator,
  Modal,
} from "react-native";
import { useNavigation } from "@react-navigation/native";
import { useAuth } from "../AuthContext";
import { UserContext } from "../UserContext";
import Ionicons from "react-native-vector-icons/Ionicons";
import styles from "../constants/HomeScreen.styles";
import { SearchBar } from "@rneui/themed";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import { Linking } from "react-native"; // Import Linking API

import welcomeImage from "../assets/images/welcome.png";
const welcome_image = Image.resolveAssetSource(welcomeImage).uri;

import groupIcon from "../assets/images/group-icon.png";
const group_icon = Image.resolveAssetSource(groupIcon).uri;

import userIcon from "../assets/images/user-icon.png";
import newsData from "./newsData"; // Import the news data
import settingsPageLinksData from "./settingsPageLinksData"; // Import the setting page data

//const Stack = createStackNavigator();

function HomeScreen() {
  const navigation = useNavigation();
  const { accessToken } = useAuth();
  //const { removeToken } = useAuth();
  //const [users, setUsers] = useState([]);
  const { users, setUsers } = useContext(UserContext);
  const [filteredUsers, setFilteredUsers] = useState([]);
  const [loading, setLoading] = useState(false);
  const [search, setSearch] = useState("");

  //const [userData, setUserData] = useState(null); // State to hold user data
  //const { setUsers } = useContext(UserContext);

  useFocusEffect(
    React.useCallback(() => {
      //console.log("useFocusEffect called yash")
      fetchChatListFromStorageRe();
    }, [])
  );

  useEffect(() => {
    // Update navigation header options
    navigation.setOptions({
      headerRight: () => (
        <TouchableOpacity
          onPress={createNewChat} // Call the function to create a new chat
          style={{ paddingRight: 10 }}
          disabled={loading}
        >
          {loading ? (
            <ActivityIndicator color={Colors.greenwa} size="small" />
          ) : (
            <Ionicons name="add-circle" size={28} color={Colors.greenwa} />
          )}
        </TouchableOpacity>
      ),
      headerLeft: () => (
        <TouchableOpacity
          onPress={navigatetoArchived} // Call the function to create a new chat
          style={{ paddingLeft: 10 }}
          disabled={loading}
        >
          {loading ? (
            <ActivityIndicator color={Colors.greenwa} size="small" />
          ) : (
            <Ionicons name="archive" size={24} color={Colors.greenwa} />
          )}
        </TouchableOpacity>
      ),
    });

    fetchChatListFromStorage().then(async (storedUsers) => {
      const archivedChats =
        JSON.parse(await AsyncStorage.getItem("archivedChats")) || [];
      if (storedUsers && storedUsers.length > 0) {
        const activeUsers = storedUsers.filter(
          (user) => !archivedChats.includes(user.id)
        );
        setUsers(activeUsers);
        setFilteredUsers(activeUsers);
      } else {
        fetchChatList();
      }
    });
  }, [accessToken, navigation]);

  const fetchChatListFromStorage = async () => {
    try {
      const storedUsers = await AsyncStorage.getItem("users");
      return storedUsers ? JSON.parse(storedUsers) : [];
    } catch (e) {
      console.error("Failed to fetch users from storage:", e);
      return [];
    }
  };

  const navigatetoArchived = async () => {
    navigation.navigate("Archived");
  };

  const fetchChatListFromStorageRe = async () => {
    fetchChatListFromStorage().then(async (storedUsers) => {
      const archivedChats =
        JSON.parse(await AsyncStorage.getItem("archivedChats")) || [];
      if (storedUsers && storedUsers.length > 0) {
        const activeUsers = storedUsers.filter(
          (user) => !archivedChats.includes(user.id)
        );
        setUsers(activeUsers);
        setFilteredUsers(activeUsers);
      } else {
        //old fix
        //fetchChatList();
      }
    });
  };

  const archiveChat = async (chatId) => {
    try {
      const archivedChats =
        JSON.parse(await AsyncStorage.getItem("archivedChats")) || [];
      if (!archivedChats.includes(chatId)) {
        archivedChats.push(chatId);
        await AsyncStorage.setItem(
          "archivedChats",
          JSON.stringify(archivedChats)
        );
        // Update the UI
        const updatedFilteredUsers = filteredUsers.filter(
          (user) => user.id !== chatId
        );
        setFilteredUsers(updatedFilteredUsers);
      }
    } catch (error) {
      console.error("Error archiving chat:", error);
    }
  };

  const fetchChatList = async () => {
    setLoading(true);
    console.log("accessToken from Home.js : " + accessToken);

    try {
      const response = await fetch(Keys.apiURLDisa + "/allchats", {
        headers: {
          Accept: "application/json",
          Authorization: `Bearer ${accessToken}`,
        },
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();

      if (data && Array.isArray(data)) {
        const archivedChats =
          JSON.parse(await AsyncStorage.getItem("archivedChats")) || [];
        const storedUsers =
          JSON.parse(await AsyncStorage.getItem("users")) || [];

        // Keep the archived chats
        const archivedUsers = storedUsers.filter((user) =>
          archivedChats.includes(user.id)
        );

        // Process new chats
        const newUsers = data
          .filter((chat) => !archivedChats.includes(chat.chat_id))
          .map((chat) => ({
            id: chat.chat_id,
            name: chat.creator_name,
            avatar: group_icon,
            lastMessage: "Task ID ",
            timestamp: new Date(chat.created_at).toLocaleTimeString([], {
              hour: "2-digit",
              minute: "2-digit",
            }),
          }));

        // Combine archived and new users
        const allUsers = [...archivedUsers, ...newUsers];

        await storeUsersData(allUsers);
        setUsers(newUsers); // Only set active users for the main screen
        setFilteredUsers(newUsers);
      } else {
        console.log("Unexpected data format:", data);
      }
    } catch (error) {
      console.error("Error fetching data (fetchChatList):", error);
    } finally {
      setLoading(false);
    }
  };

  const storeUsersData = async (usersData) => {
    try {
      const jsonUsers = JSON.stringify(usersData);
      await AsyncStorage.setItem("users", jsonUsers);
      //console.log("Users data stored successfully!");
    } catch (e) {
      console.error("Failed to store users data:", e);
    }
  };

  const createNewChat = () => {
    setLoading(true);
    console.log("createNewChat status " + loading);

    fetch(Keys.apiURLDisa + "/chats", {
      method: "POST",
      headers: {
        Accept: "application/json",
        Authorization: `Bearer ${accessToken}`,
      },
    })
      .then((response) => response.json())
      .then((data) => {
        console.log("Chat created:", data);

        // Refresh chat list after creating a new chat
        fetchChatList().then(() => {
          navigation.navigate("Chat", {
            chatId: data.chat_id,
            userName: "New Chat",
          });
        });
      })
      .catch((error) => {
        console.error("Error creating chat:", error);
        alert("Error creating new chat!");
      })
      .finally(() => setLoading(false));
  };

  const updateSearch = (search) => {
    setSearch(search);
    if (search === "") {
      setFilteredUsers(users); // Reset to original list if search is empty
    } else {
      const filtered = users.filter(
        (user) =>
          user.name.toLowerCase().includes(search.toLowerCase()) ||
          user.lastMessage.toLowerCase().includes(search.toLowerCase())
      );
      setFilteredUsers(filtered);
    }
  };

  return (
    <View style={styles.container}>
      {loading ? (
        <View style={{ paddingTop: 5, paddingBottom: 5 }}>
          <ActivityIndicator color={Colors.greenwa} size="small" />
        </View>
      ) : (
        console.log("ActivityIndicator Mandate")
      )}
      <SearchBar
        platform="ios"
        containerStyle={{ height: 50 }}
        inputContainerStyle={{ height: 35, backgroundColor: Colors.searchHome }}
        placeholder="Search"
        placeholderTextColor="#888"
        round
        value={search}
        showCancel
        cancelButtonTitle="Cancel"
        searchIcon={
          <Ionicons name="search-outline" size={20} color={Colors.primary} />
        }
        onChangeText={updateSearch}
      />

      <ScrollView contentContainerStyle={styles.userList}>
        {filteredUsers.map((user) => (
          <TouchableOpacity
            key={user.id}
            style={styles.userRow}
            onPress={() =>
              navigation.navigate("Chat", {
                chatId: user.id,
                userName: user.name,
              })
            }
          >
            <Image source={{ uri: user.avatar }} style={styles.avatar} />
            <View style={styles.userInfo}>
              <Text style={styles.userName}>{user.name}</Text>
              <Text style={styles.lastMessage}>
                {user.lastMessage + user.id}
              </Text>
            </View>
            <Text style={styles.timestamp}>{user.timestamp}</Text>
            <TouchableOpacity onPress={() => archiveChat(user.id)}>
              <Ionicons name="archive" size={24} color={Colors.greenwa} />
            </TouchableOpacity>
          </TouchableOpacity>
        ))}
      </ScrollView>
    </View>
  );
}

const NewsItem = ({ item }) => (
  <TouchableOpacity style={styles.newsItem}>
    <Image source={{ uri: item.imageUrl }} style={styles.newsImage} />
    <View style={styles.newsTextContainer}>
      <Text style={styles.newsTitle}>{item.title}</Text>
      <Text style={styles.newsSummary}>{item.summary}</Text>
      <Text style={styles.newsDate}>{item.date}</Text>
    </View>
  </TouchableOpacity>
);

function UpdateScreen() {
  return (
    <View style={styles.container}>
      <FlatList
        data={newsData}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => <NewsItem item={item} />}
      />
    </View>
  );
}

const SettingsScreen = () => {
  const { accessToken, removeToken } = useAuth();
  const navigation = useNavigation();
  const [userData, setUserData] = useState(null); // State to hold user data
  const { setUsers } = useContext(UserContext);

  useEffect(() => {
    const fetchUserData = async () => {
      try {
        const storedData = await AsyncStorage.getItem("userData");
        //console.log("storedData " + storedData);
        if (storedData) {
          const parsedData = JSON.parse(storedData);
          if (parsedData.detail && parsedData.detail === "Invalid token") {
            // If stored data indicates token is invalid, fetch from API
            //await fetchDataFromAPI();
          } else {
            // Use stored data
            setUserData(parsedData);
          }
        } else {
          // Fetch user data from API if not stored in AsyncStorage
          // await fetchDataFromAPI();
        }
      } catch (error) {
        console.error("Error fetching user data:", error);
      }
    };

    fetchUserData(); // Fetch user data when component mounts

    return () => {
      // Cleanup if necessary
    };
  }, [accessToken]); // Dependency array ensures useEffect runs when accessToken changes

  const handleLogout = async () => {
    try {
      // Clear user data and users state
      setUserData(null);
      setUsers([]);

      // Clear AsyncStorage
      await AsyncStorage.removeItem("userData");
      await AsyncStorage.removeItem("users");

      // Remove token or perform other logout actions
      removeToken();

      // Navigate to IntroPage
      navigation.navigate("IntroPage");
    } catch (error) {
      console.error("Error logging out:", error);
    }
  };

  const handleSupportItemPress = (item) => {
    if (item.url) {
      Linking.openURL(item.url);
    }
  };

  return (
    <View style={{ flex: 1, backgroundColor: Colors.background }}>
      <ScrollView
        contentInsetAdjustmentBehavior="automatic"
        contentContainerStyle={{ paddingBottom: 40 }}
      >
        <View style={styles.headline}>
          {userData && (
            <>
              <Text style={styles.headlineName}>
                {" "}
                <Image source={userIcon} style={styles.avatar27} />
              </Text>

              <Text style={styles.headlineName}>{userData.name}</Text>
            </>
          )}
        </View>

        <View style={defaultStyles.block}>
          {userData && (
            <>
              <View style={defaultStyles.item}>
                <BoxedIcon
                  name="mail-outline"
                  backgroundColor={Colors.greenwa}
                />
                <Text style={{ fontSize: 18, flex: 1 }}>{userData.email}</Text>
              </View>

              <View style={defaultStyles.item}>
                <BoxedIcon
                  name="call-outline"
                  backgroundColor={Colors.greenwa}
                />
                <Text style={{ fontSize: 18, flex: 1 }}>
                  {userData.mobile_number}
                </Text>
              </View>
            </>
          )}
        </View>

        <View style={defaultStyles.block}>
          {userData && (
            <>
              <View style={defaultStyles.item}>
                <BoxedIcon
                  name="business-outline"
                  backgroundColor={Colors.greenwa}
                />
                <Text style={{ fontSize: 18, flex: 1 }}>
                  Industry : {userData.industry}
                </Text>
              </View>

              <View style={defaultStyles.item}>
                <BoxedIcon
                  name="business-outline"
                  backgroundColor={Colors.greenwa}
                />
                <Text style={{ fontSize: 18, flex: 1 }}>
                  Specialization : {userData.specialization}
                </Text>
              </View>
            </>
          )}
        </View>

        {Object.keys(settingsPageLinksData).map((key) => (
          <View style={defaultStyles.block} key={key}>
            <FlatList
              data={settingsPageLinksData[key]}
              scrollEnabled={false}
              ItemSeparatorComponent={() => (
                <View style={defaultStyles.separator} />
              )}
              renderItem={({ item }) => (
                <TouchableOpacity onPress={() => handleSupportItemPress(item)}>
                  <View style={defaultStyles.item}>
                    <BoxedIcon
                      name={item.icon}
                      backgroundColor={item.backgroundColor}
                    />
                    <Text style={{ fontSize: 18, flex: 1 }}>{item.name}</Text>
                  </View>
                </TouchableOpacity>
              )}
            />
          </View>
        ))}

        <TouchableOpacity onPress={handleLogout}>
          <View style={defaultStyles.block}>
            <>
              <View style={defaultStyles.item}>
                <BoxedIcon
                  name="log-out-outline"
                  backgroundColor={Colors.red}
                />
                <Text style={{ fontSize: 18, flex: 1 }}>Log Out</Text>
              </View>
            </>
          </View>
        </TouchableOpacity>
      </ScrollView>
    </View>
  );
};

function MoreScreen() {
  return (
    <ScrollView style={styles.container}>
      <Image source={{ uri: welcome_image }} style={styles.welcome} />
      <Text style={styles.headline}>About Disa</Text>
      <Text style={styles.description}>
        Discover the power of understanding your data with Disa App, your go-to
        AI tool that makes sense of complex information easily and quickly.{" "}
        {"\n"}
      </Text>
      <Text style={styles.description}>Version 2024.01.01 {"\n"}</Text>
      <Text style={styles.description}>ⓒ 2024 Disa</Text>
    </ScrollView>
  );
}

const Tab = createBottomTabNavigator();

export default function App() {
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        tabBarIcon: ({ focused, color, size }) => {
          let iconName;

          if (route.name === "Chats") {
            iconName = focused ? "chatbubbles" : "chatbubbles-outline";
          } else if (route.name === "Updates") {
            iconName = focused ? "disc" : "disc-outline";
          } else if (route.name === "Settings") {
            iconName = focused ? "settings" : "settings-outline";
          } else if (route.name === "More") {
            iconName = focused ? "help-circle" : "help-circle-outline";
          }

          // You can return any component that you like here!
          return <Ionicons name={iconName} size={size} color={color} />;
        },
        tabBarActiveTintColor: Colors.greenwa,
        tabBarInactiveTintColor: "gray",
      })}
    >
      <Tab.Screen
        name="Chats"
        component={HomeScreen}
        options={
          {
            // headerShown: false
          }
        }
      />

      <Tab.Screen name="Updates" component={UpdateScreen} />
      <Tab.Screen
        name="Settings"
        component={SettingsScreen}
        options={{
          tabBarBadge: 3,
          tabBarBadgeStyle: { backgroundColor: "green", color: "white" },
        }}
      />
      <Tab.Screen name="More" component={MoreScreen} />
    </Tab.Navigator>
  );
}
