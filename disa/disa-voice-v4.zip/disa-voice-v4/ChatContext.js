import React, { createContext, useContext, useState, useCallback } from "react";

const ChatContext = createContext();

export const useChat = () => {
  return useContext(ChatContext);
};

export const ChatProvider = ({ children }) => {
  const [fetchMessagesFunction, setFetchMessagesFunction] = useState(null);

  const setFetchMessages = useCallback((fetchMessages) => {
    setFetchMessagesFunction(() => fetchMessages);
  }, []);

  return (
    <ChatContext.Provider value={{ fetchMessagesFunction, setFetchMessages }}>
      {children}
    </ChatContext.Provider>
  );
};
