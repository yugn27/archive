import React, { useEffect, useState } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import Colors from './constants/Colors';
import { Avatar, Header } from 'react-native-elements';
import { View, Text, TouchableOpacity, ActivityIndicator } from 'react-native';
import Ionicons from 'react-native-vector-icons/Ionicons';
import Keys from './constants/Keys';

//Pages
import IntroPage from './pages/IntroPage';
import SignUp from './pages/SignUp';
import SignIn from './pages/SignIn';
import Password from './pages/Password';
import Skills from './pages/Skills';
import Delete from './pages/Delete';
import NewChat from './pages/NewChat';
import Home from './pages/Home';
import Chat from './pages/Chat';
import Archive from './pages/Archive';

//Auth
import { AuthProvider } from './AuthContext';
import { useAuth } from './AuthContext';
import { UserProvider } from './UserContext';
import ContactInfo from './pages/ContactInfo'; // Import ContactInfo component

const Stack = createStackNavigator();

function App() {
  const [isLoading, setIsLoading] = useState(true);
  const [initialRoute, setInitialRoute] = useState('IntroPage');

  useEffect(() => {
    checkToken();
  }, []);

  const checkToken = async () => {
    try {
      const token = await AsyncStorage.getItem('accessToken');
      if (token) {
        setInitialRoute('Home');
      }
    } catch (error) {
      console.error('Error checking token:', error);
    } finally {
      setIsLoading(false);
    }
  };

  if (isLoading) {
    return (
      <View>
        <Text>Loading...</Text>
      </View>
    ); // Or use a loading spinner
  }

  return (
    <UserProvider>
      <AuthProvider>
        <NavigationContainer>
          <Stack.Navigator initialRouteName={initialRoute}>
            <Stack.Screen
              name="IntroPage"
              component={IntroPage}
              options={{ headerShown: false }}
            />

            <Stack.Screen
              name="SignUp"
              component={SignUp}
              options={{
                headerTitle: 'Create a New Account',
                headerLeft: null,
                headerStyle: { backgroundColor: Colors.white },
                headerTitleStyle: { color: 'black' },
              }}
            />

            <Stack.Screen
              name="SignIn"
              component={SignIn}
              options={{
                headerTitle: 'Welcome to Disa',
                headerLeft: null,
                headerStyle: { backgroundColor: Colors.white },
                headerTitleStyle: { color: 'black' },
              }}
            />

            <Stack.Screen
              name="Password"
              component={Password}
              options={{
                headerTitle: 'Password Reset',
                headerLeft: null,
                headerStyle: { backgroundColor: Colors.white },
                headerTitleStyle: { color: 'black' },
              }}
            />

            <Stack.Screen
              name="Home"
              component={Home}
              options={{
                headerTitle: 'Welcome to Disa',
                headerShown: false,
                headerStyle: { backgroundColor: Colors.greenwa },
                headerTitleStyle: { color: 'white' },
              }}
            />

            <Stack.Screen
              name="Chat"
              component={Chat}
              options={({ route, navigation }) => ({
                header: (props) => (
                  <Header
                    containerStyle={{ backgroundColor: Colors.white }}
                    leftComponent={
                      <TouchableOpacity
                        /*onPress={() => navigation.goBack()}*/
                        onPress={() => navigation.navigate('Home')}
                        style={{ paddingLeft: 10 }}>
                        <Ionicons
                          name="arrow-back-outline"
                          size={28}
                          color={Colors.black}
                        />
                      </TouchableOpacity>
                    }
                    centerComponent={
                      <TouchableOpacity
                        onPress={() =>
                          props.navigation.navigate('ContactInfo', {
                            userName: route.params.userName,
                            chatId: route.params.chatId,
                            avatar: route.params.avatar,
                          })
                        }>
                        <View
                          style={{
                            flexDirection: 'row',
                            alignItems: 'center',
                          }}>
                          <Avatar
                            source={{
                              uri: route.params.avatar,
                            }}
                            size={28}
                            rounded
                          />
                          <Text
                            style={{
                              color: Colors.black,
                              marginLeft: 10,
                              fontSize: 16,
                              fontWeight: '500',
                            }}>
                            {route.params.userName}
                          </Text>
                        </View>
                      </TouchableOpacity>
                    }
                    rightComponent={
                      <ChatActionButton
                        chatId={route.params.chatId}
                        fetchMessages={route.params.fetchMessages}
                      />
                    }
                  />
                ),
              })}
            />

            <Stack.Screen
              name="Archived"
              component={Archive}
              options={{
                header: (props) => (
                  <Header
                    containerStyle={{ backgroundColor: Colors.white }}
                    leftComponent={
                      <TouchableOpacity
                        onPress={() => props.navigation.goBack()}
                        style={{ paddingLeft: 10 }}>
                        <Ionicons
                          name="arrow-back-outline"
                          size={28}
                          color={Colors.black}
                        />
                      </TouchableOpacity>
                    }
                    centerComponent={
                      <Text
                        style={{
                          color: Colors.black,
                          fontSize: 18,
                          fontWeight: '500',
                        }}>
                        Archived
                      </Text>
                    }
                  />
                ),
              }}
            />

            <Stack.Screen
              name="ContactInfo"
              component={ContactInfo}
              options={({ route }) => ({
                header: (props) => (
                  <Header
                    containerStyle={{ backgroundColor: Colors.white }}
                    leftComponent={
                      <TouchableOpacity
                        onPress={() => props.navigation.goBack()}
                        style={{ paddingLeft: 10 }}>
                        <Ionicons
                          name="arrow-back-outline"
                          size={28}
                          color={Colors.black}
                        />
                      </TouchableOpacity>
                    }
                    centerComponent={
                      <TouchableOpacity>
                        <View
                          style={{
                            flexDirection: 'row',
                            alignItems: 'center',
                          }}>
                          <Text
                            style={{
                              color: Colors.black,
                              marginLeft: 10,
                              fontSize: 16,
                              fontWeight: '500',
                            }}>
                            Conversation
                          </Text>
                        </View>
                      </TouchableOpacity>
                    }
                  />
                ),
              })}
            />

            <Stack.Screen
              name="Skills"
              component={Skills}
              /*
              options={{
                headerTitle: "Select Skills",
                headerLeft: null,
                headerStyle: { backgroundColor: Colors.white },
                headerTitleStyle: { color: "black" },
              }}

*/

              options={({ route }) => ({
                header: (props) => (
                  <Header
                    containerStyle={{ backgroundColor: Colors.white }}
                    leftComponent={
                      <TouchableOpacity
                        onPress={() => props.navigation.goBack()}
                        style={{ paddingLeft: 10 }}>
                        <Ionicons
                          name="arrow-back-outline"
                          size={28}
                          color={Colors.black}
                        />
                      </TouchableOpacity>
                    }
                    centerComponent={
                      <TouchableOpacity>
                        <View
                          style={{
                            flexDirection: 'row',
                            alignItems: 'center',
                          }}>
                          <Text
                            style={{
                              color: Colors.black,
                              marginLeft: 10,
                              fontSize: 16,
                              fontWeight: '500',
                            }}>
                            Select Skill
                          </Text>
                        </View>
                      </TouchableOpacity>
                    }
                  />
                ),
              })}
            />




            
            <Stack.Screen
              name="Delete"
              component={Delete}
              /*
              options={{
                headerTitle: "Select Skills",
                headerLeft: null,
                headerStyle: { backgroundColor: Colors.white },
                headerTitleStyle: { color: "black" },
              }}

*/

              options={({ route }) => ({
                header: (props) => (
                  <Header
                    containerStyle={{ backgroundColor: Colors.white }}
                    leftComponent={
                      <TouchableOpacity
                        onPress={() => props.navigation.goBack()}
                        style={{ paddingLeft: 10 }}>
                        <Ionicons
                          name="arrow-back-outline"
                          size={28}
                          color={Colors.black}
                        />
                      </TouchableOpacity>
                    }
                    centerComponent={
                      <TouchableOpacity>
                        <View
                          style={{
                            flexDirection: 'row',
                            alignItems: 'center',
                          }}>
                          <Text
                            style={{
                              color: Colors.black,
                              marginLeft: 10,
                              fontSize: 16,
                              fontWeight: '500',
                            }}>
                            Delete Account
                          </Text>
                        </View>
                      </TouchableOpacity>
                    }
                  />
                ),
              })}
            />

            <Stack.Screen
              name="NewChat"
              component={NewChat}
              /*
              options={{
                headerTitle: "New Chat",
                headerLeft: null,
                headerStyle: { backgroundColor: Colors.white },
                headerTitleStyle: { color: "black" },
              }}

*/

              options={({ route }) => ({
                header: (props) => (
                  <Header
                    containerStyle={{ backgroundColor: Colors.white }}
                    leftComponent={
                      <TouchableOpacity
                        onPress={() => props.navigation.goBack()}
                        style={{ paddingLeft: 10 }}>
                        <Ionicons
                          name="arrow-back-outline"
                          size={28}
                          color={Colors.black}
                        />
                      </TouchableOpacity>
                    }
                    centerComponent={
                      <TouchableOpacity>
                        <View
                          style={{
                            flexDirection: 'row',
                            alignItems: 'center',
                          }}>
                          <Text
                            style={{
                              color: Colors.black,
                              marginLeft: 10,
                              fontSize: 16,
                              fontWeight: '500',
                            }}>
                            New Chat
                          </Text>
                        </View>
                      </TouchableOpacity>
                    }
                  />
                ),
              })}
            />
          </Stack.Navigator>
        </NavigationContainer>
      </AuthProvider>
    </UserProvider>
  );
}

// Custom component for action button in the header
// In App.js
const ChatActionButton = ({ chatId, fetchMessages }) => {
  const [templateText, setTemplateText] = useState('');
  const [loading, setLoading] = useState(false);
  const { accessToken } = useAuth();

  useEffect(() => {
    const fetchTemplateText = async () => {
      try {
        const userData = await AsyncStorage.getItem('userData');
        if (userData) {
          const parsedUserData = JSON.parse(userData);
          setTemplateText(parsedUserData.template_text || '');
        }
      } catch (error) {
        console.error('Error fetching template text:', error);
      }
    };

    fetchTemplateText();
  }, []);

  const fetchChatMessages = async () => {
    setLoading(true);
    try {
      const response = await fetch(
        `${Keys.apiURLDisa}/chats/${chatId}/messages`,
        {
          headers: {
            Accept: 'application/json',
            Authorization: `Bearer ${accessToken}`,
          },
        }
      );
      const data = await response.json();

      if (data.length === 0) {
        alert('No messages in this chat.');
        return;
      }

      if (data[data.length - 1].sender_name === 'Disa AI') {
        alert('No new messages in this chat.');
        return;
      }

      var formattedMessages = data
        .map((msg) => `${msg.sent_at} - ${msg.sender_name}: ${msg.message}`)
        .join('\n');

      const url = Keys.apiURLOpenai;
      const openaiData = {
        model: 'gpt-4o',
        messages: [
          {
            role: 'user',
            content: `${templateText} ${formattedMessages}`,
          },
        ],
        temperature: 0.7,
      };

      const openaiResponse = await fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${Keys.apiKeyOpenai}`,
        },
        body: JSON.stringify(openaiData),
      });
      const openaiDataResponse = await openaiResponse.json();

      await fetch(`${Keys.apiURLDisa}/chats/${chatId}/send-message-bot`, {
        method: 'POST',
        headers: {
          Accept: 'application/json',
          'Content-Type': 'application/json',
          Authorization: `Bearer ${accessToken}`,
        },
        body: JSON.stringify({
          message: openaiDataResponse.choices[0].message.content,
        }),
      });

      handleFetchAndAnalyze();
    } catch (error) {
      console.error('Error:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleFetchAndAnalyze = async () => {
    setLoading(true);
    try {
      await fetchMessages();
    } catch (error) {
      console.error('Error:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={{ flexDirection: 'row', gap: 14 }}>
      <TouchableOpacity
        onPress={fetchChatMessages}
        disabled={loading}
        style={{
          opacity: loading ? 0.5 : 1,
        }}>
        {loading ? (
          <ActivityIndicator size="small" color="#0000ff" />
        ) : (
          <Ionicons name="infinite-outline" size={28} color={Colors.greenwa} />
        )}
      </TouchableOpacity>
    </View>
  );
};

export default App;
