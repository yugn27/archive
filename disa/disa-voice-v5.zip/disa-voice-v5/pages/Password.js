import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  Alert,
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import AsyncStorage from '@react-native-async-storage/async-storage';

import styles from '../constants/SignInScreen.styles';
import Colors from '../constants/Colors';
import Keys from '../constants/Keys';

const PasswordResetRequest = () => {
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const navigation = useNavigation();

  const keyboardVerticalOffset = Platform.OS === 'ios' ? 90 : 0;

  const handlePasswordResetRequest = async () => {
    setLoading(true);
    try {
      const response = await fetch(
        `${Keys.apiURLDisa}/password-reset-request`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ email }),
        }
      );

      if (!response.ok) {
        throw new Error('Password reset request failed');
      }

      const data = await response.json();
      Alert.alert('Success', data.message);
      navigation.goBack();
    } catch (error) {
      console.error('Password reset request error:', error.message);
      Alert.alert(
        'Error',
        'Failed to send password reset email. Please try again.'
      );
    } finally {
      setLoading(false);
    }
  };

  const isFormValid = email.trim() !== '';

  return (
    <KeyboardAvoidingView
      keyboardVerticalOffset={keyboardVerticalOffset}
      style={{ flex: 1 }}
      behavior="padding">
      <View style={styles.container}>
        <Text style={styles.description}>
          Please enter your details to reset password.
        </Text>

        <View style={styles.list}>
          <TextInput
            style={styles.input}
            placeholder="Email"
            placeholderTextColor="#000000"
            value={email}
            onChangeText={setEmail}
            keyboardType="email-address"
            autoCapitalize="none"
          />
        </View>

        <Text style={styles.legal}>
          You will receive an email with instructions.
        </Text>

        <View style={{ flex: 1 }} />

        <Text style={styles.legal}>
          <Text
            style={styles.link}
            onPress={() => navigation.navigate('SignIn')}>
            Back to Sign In
          </Text>
        </Text>

        <TouchableOpacity
          style={[
            styles.button,
            {
              marginBottom: 20,
              backgroundColor:
                loading || !isFormValid ? 'grey' : Colors.greenwa,
            },
          ]}
          onPress={handlePasswordResetRequest}
          disabled={loading || !isFormValid}>
          {loading ? (
            <ActivityIndicator color={Colors.white} size="large" />
          ) : (
            <Text style={styles.buttonText}>Reset Password</Text>
          )}
        </TouchableOpacity>
      </View>
    </KeyboardAvoidingView>
  );
};

export default PasswordResetRequest;
