import { Image } from 'react-native';
import vaccineImage from '../assets/images/welcome.png';
const vaccine_image = Image.resolveAssetSource(vaccineImage).uri;

const newsData = [
  {
    id: '1',
    title: 'Latest COVID-19 Vaccine Updates Approaches',
    summary:
      'A look at innovative treatment strategies for heart disease, featuring insights from leading cardiologists.',
    date: '2024-05-10',
    imageUrl: vaccine_image,
  },
  {
    id: '2',
    title: 'Heart Disease: New Treatment Approaches',
    summary:
      'A look at innovative treatment strategies for heart disease, featuring insights from leading cardiologists.',
    date: '2024-05-09',
    imageUrl: vaccine_image,
  },
  {
    id: '3',
    title: 'Advances in Neurological Disorders',
    summary:
      "Recent breakthroughs in the treatment of neurological disorders, including Alzheimer's and Parkinson's disease.",
    date: '2024-05-08',
    imageUrl: vaccine_image,
  },
  // Add more news items as needed
];

export default newsData;
