import { useState, useEffect } from 'react';
import Colors from '../constants/Colors';
import {
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  FlatList,
  Alert,
  ActivityIndicator,
  Modal,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { useAuth } from '../AuthContext';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { defaultStyles } from '../constants/Styles';
import BoxedIcon from '../components/BoxedIcon';
import Ionicons from 'react-native-vector-icons/Ionicons';
import Keys from '../constants/Keys';

const Skills = () => {
  const navigation = useNavigation();
  const { accessToken } = useAuth();
  const [templates, setTemplates] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedTemplateId, setSelectedTemplateId] = useState(null);
  const [fullScreenLoaderVisible, setFullScreenLoaderVisible] = useState(false);

  useEffect(() => {
    const fetchTemplates = async () => {
      try {
        const response = await fetch(Keys.apiURLDisa + '/templates-users', {
          method: 'GET',
          headers: {
            Accept: 'application/json',
            Authorization: `Bearer ${accessToken}`,
          },
        });
        const data = await response.json();
        setTemplates(data);
        setLoading(false);
      } catch (error) {
        console.error('Error fetching templates:', error);
        setLoading(false);
      }
    };

    fetchTemplates();
  }, [accessToken]);

  const handleTemplateSelect = async (templateId) => {
    setFullScreenLoaderVisible(true);

    try {
      const response = await fetch(Keys.apiURLDisa + '/user/update-template', {
        method: 'PUT',
        headers: {
          Accept: 'application/json',
          Authorization: `Bearer ${accessToken}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ template_id: templateId }),
      });

      if (!response.ok) {
        throw new Error('Failed to update Template ID');
      }

      const result = await response.json();

      // Check if the result contains user data
      if (result.id) {
        //Alert.alert("Success", "Template ID updated successfully");

        // Update user data in AsyncStorage
        await AsyncStorage.setItem('userData', JSON.stringify(result));
        setSelectedTemplateId(templateId);
        // Optionally navigate back to the previous screen or show a success message
      } else {
        Alert.alert('Error', 'Failed to update Template ID');
      }
    } catch (error) {
      console.error('Error updating template:', error);
      Alert.alert('Error', 'Failed to update Template ID');
    } finally {
      setFullScreenLoaderVisible(false);
      navigation.goBack();
    }
  };

  if (loading) {
    return (
      <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
        <ActivityIndicator size="large" color={Colors.greenwa} />
      </View>
    );
  }

  return (
    <View style={{ flex: 1, backgroundColor: Colors.background }}>
      <ScrollView
        contentInsetAdjustmentBehavior="automatic"
        contentContainerStyle={{ paddingBottom: 40 }}>
        <FlatList
          data={templates}
          keyExtractor={(item) => item.id.toString()}
          renderItem={({ item }) => (
            <TouchableOpacity
              onPress={() => handleTemplateSelect(item.id)}
              style={defaultStyles.block}>
              <View style={defaultStyles.item}>
                <BoxedIcon
                  name="bulb-outline"
                  backgroundColor={Colors.greenwa}
                />
                <Text style={{ fontSize: 18, flex: 1 }}>
                  {item.industry} - {item.specialization}
                </Text>
                {selectedTemplateId === item.id ? (
                  <Ionicons
                    name="radio-button-on-outline"
                    size={28}
                    color={Colors.black}
                  />
                ) : (
                  <Ionicons
                    name="radio-button-off-outline"
                    size={28}
                    color={Colors.black}
                  />
                )}
              </View>
            </TouchableOpacity>
          )}
        />
      </ScrollView>

      <Modal
        transparent={true}
        visible={fullScreenLoaderVisible}
        animationType="fade"
        onRequestClose={() => setFullScreenLoaderVisible(false)}>
        <View
          style={{
            flex: 1,
            justifyContent: 'center',
            alignItems: 'center',
            backgroundColor: 'rgba(0,0,0,0.5)',
          }}>
          <ActivityIndicator size="large" color={Colors.greenwa} />
        </View>
      </Modal>
    </View>
  );
};

export default Skills;
