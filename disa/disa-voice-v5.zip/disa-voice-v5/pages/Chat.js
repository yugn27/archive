import React, { useEffect, useState, useCallback, useRef } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  TextInput,
  KeyboardAvoidingView,
  Platform,
  Alert,
  Image,
  Clipboard,
  TouchableWithoutFeedback,
  ActionSheetIOS,
  ActivityIndicator,
} from 'react-native';

import { Avatar, Header } from 'react-native-elements';

import { Linking } from 'react-native';
import * as WebBrowser from 'expo-web-browser';

import { Share } from 'react-native';

import * as DocumentPicker from 'expo-document-picker';
import * as FileSystem from 'expo-file-system';

import { useNavigation, useRoute } from '@react-navigation/native';
import Ionicons from 'react-native-vector-icons/Ionicons';
import AsyncStorage from '@react-native-async-storage/async-storage';
//import Voice from '@react-native-voice/voice';
import { useAuth } from '../AuthContext';
import Colors from '../constants/Colors';
import Keys from '../constants/Keys';
import styles from '../constants/ChatScreen.styles';

import attachFileImage from '../assets/images/attachfile.png';
const attachFile_Image = Image.resolveAssetSource(attachFileImage).uri;

function ChatScreen({ navigation }) {
  const { accessToken } = useAuth();
  const route = useRoute();
  const { chatId, userName } = route.params;
  const [selectedMessageId, setSelectedMessageId] = useState(null);
  const [userData, setUserData] = useState(null); // State to hold user data

  const [messages, setMessages] = useState([]);
  const [messageText, setMessageText] = useState('');
  const [isListening, setIsListening] = useState(false);
  const [loading, setLoading] = useState(true);

  const [isUploading, setIsUploading] = useState(false);

  const [rating, setRating] = useState(0); // State to hold the current rating

  const scrollViewRef = useRef(null);
  const inputScrollViewRef = useRef(null);

  const [skill, setSkill] = useState('');

  const [templateChecklist, setTemplateChecklist] = useState('');

  const FullScreenLoader = () => (
    <View style={styles.fullScreenLoaderContainer}>
      <ActivityIndicator size="large" color={Colors.greenwa} />
      <Text style={styles.loaderText}>Uploading file...</Text>
    </View>
  );

  // Function to fetch skills by chatId
  const fetchSkillsByChatId = async (chatId) => {
    try {
      const storedUsers = await AsyncStorage.getItem('users');

      if (storedUsers) {
        const users = JSON.parse(storedUsers);
        const user = users.find((user) => user.id === chatId);
        return user ? user.lastMessage : null; // Return skills or null if not found
      }
      return null;
    } catch (error) {
      console.error('Failed to fetch users from storage:', error);
      return null;
    }
  };

  useEffect(() => {
    const loadSkill = async () => {
      const userSkill = await fetchSkillsByChatId(chatId);
      if (userSkill) {
        setSkill(userSkill);
      }
    };

    loadSkill();
  }, [chatId]);

  useEffect(() => {
    const fetchTemplateChecklist = async () => {
      try {
        const userData = await AsyncStorage.getItem('userData');
        if (userData) {
          const parsedUserData = JSON.parse(userData);
          setTemplateChecklist(parsedUserData.checklist || '');
        }
      } catch (error) {
        console.error('Error fetching template text:', error);
      }
    };

    fetchTemplateChecklist();

    const fetchUserData = async () => {
      try {
        const storedData = await AsyncStorage.getItem('userData');
        //console.log("storedData " + storedData);
        if (storedData) {
          const parsedData = JSON.parse(storedData);
          if (parsedData.detail && parsedData.detail === 'Invalid token') {
            // If stored data indicates token is invalid, fetch from API
            //await fetchDataFromAPI();
          } else {
            // Use stored data
            setUserData(parsedData);
          }
        } else {
          // Fetch user data from API if not stored in AsyncStorage
          // await fetchDataFromAPI();
        }
      } catch (error) {
        console.error('Error fetching user data:', error);
      }
    };

    fetchUserData(); // Fetch user data when component mounts
  }, []);

  useEffect(() => {
    loadMessagesFromStorage();
    fetchMessages(chatId);
  }, [chatId]);

  //working for load disa chat
  useEffect(() => {
    if (navigation) {
      navigation.setParams({
        fetchMessages: () => fetchMessages(chatId),
      });
    }
  }, [navigation, fetchMessages, chatId]);

  const handleShare = async (message) => {
    try {
      await Share.share({
        message: message,
        title: 'Chat Export',
      });
    } catch (error) {
      console.error('Error sharing message:', error);
    }
  };

  const loadMessagesFromStorage = async () => {
    try {
      const messagesJson = await AsyncStorage.getItem(
        `@chat_messages_${chatId}`
      );
      if (messagesJson) {
        const storedMessages = JSON.parse(messagesJson);

        // Load feedback for each message
        const messagesWithFeedback = await Promise.all(
          storedMessages.map(async (message) => {
            const feedbackKey = `@feedback_${chatId}_${message.message_id}`;
            const storedFeedback = await AsyncStorage.getItem(feedbackKey);
            return {
              ...message,
              feedback: storedFeedback
                ? JSON.parse(storedFeedback)
                : message.feedback,
            };
          })
        );

        setMessages(messagesWithFeedback);
      }
    } catch (error) {
      console.error('Error loading messages from AsyncStorage:', error);
    } finally {
      setLoading(false);
    }
  };

  const storeFeedbackLocally = async (messageId, rating) => {
    try {
      const feedbackKey = `@feedback_${chatId}_${messageId}`;
      await AsyncStorage.setItem(feedbackKey, JSON.stringify(rating));
    } catch (error) {
      console.error('Error storing feedback in AsyncStorage:', error);
    }
  };

  const copyToClipboard = (text) => {
    Clipboard.setString(text);
    Alert.alert('Copied', 'Message copied to clipboard');
  };

  const handleLongPress = (message) => {
    if (Platform.OS === 'ios') {
      ActionSheetIOS.showActionSheetWithOptions(
        {
          options: ['Copy', 'Cancel'],
          cancelButtonIndex: 1,
        },
        (buttonIndex) => {
          if (buttonIndex === 0) {
            Clipboard.setString(message);
            Alert.alert('Copied', 'Message copied to clipboard');
          }
        }
      );
    } else {
      // For Android, we'll use a simple Alert
      Alert.alert('Copy Message', 'Do you want to copy this message?', [
        {
          text: 'Cancel',
          style: 'cancel',
        },
        {
          text: 'Copy',
          onPress: () => {
            Clipboard.setString(message);
            Alert.alert('Copied', 'Message copied to clipboard');
          },
        },
      ]);
    }
  };

  const fetchMessages = useCallback(
    async (chatId) => {
      console.log('Called fetchMessages yash');
      try {
        const response = await fetch(
          Keys.apiURLDisa + `/chats/${chatId}/messages`,
          {
            headers: {
              Accept: 'application/json',
              Authorization: `Bearer ${accessToken}`,
            },
          }
        );
        const data = await response.json();
        setMessages(data);
        await storeMessagesInStorage(data);
      } catch (error) {
        console.error('Error fetching messages:', error);
      }
    },
    [accessToken]
  );

  const storeMessagesInStorage = async (messages) => {
    try {
      await AsyncStorage.setItem(
        `@chat_messages_${chatId}`,
        JSON.stringify(messages)
      );
    } catch (error) {
      console.error('Error storing messages in AsyncStorage:', error);
    }
  };

  const sendMessageDummy = async () => {
    alert('Disabled for this build!');
  };

  const fileUploadAttach = async () => {
    console.log('File upload initiated');
    setIsUploading(true);

    // Set loading state to true before starting the upload
    setIsUploading(true);

    try {
      const result = await DocumentPicker.getDocumentAsync({
        type: ['image/*', 'audio/*'], // Only allow image and audio files
        copyToCacheDirectory: false,
      });

      console.log('Document picker result:', result);

      if (!result.canceled && result.assets && result.assets.length > 0) {
        const { uri, mimeType, name, size } = result.assets[0];
        console.log('File selected:', { uri, mimeType, name, size });

        // Create FormData object
        const formData = new FormData();
        formData.append('file', {
          uri: uri,
          type: mimeType,
          name: name,
        });

        console.log('FormData created');

        // Send file to server
        console.log('Sending request to:', Keys.apiURLDisa + '/uploads/');
        const uploadResponse = await fetch(Keys.apiURLDisa + '/uploads/', {
          method: 'POST',
          headers: {
            accept: 'application/json',
            Authorization: `Bearer ${accessToken}`,
            'Content-Type': 'multipart/form-data',
          },
          body: formData,
        });

        console.log('Response status:', uploadResponse.status);

        if (!uploadResponse.ok) {
          const errorText = await uploadResponse.text();
          console.error('Upload failed. Server response:', errorText);
          throw new Error('Upload failed: ' + errorText);
        }

        const uploadData = await uploadResponse.json();
        console.log('Upload successful. Server response:', uploadData);

        const fileLink = uploadData.file_url; // Assuming the API returns the file URL

        // Send file link to /send-message endpoint
        const sendMessageResponse = await fetch(
          `${Keys.apiURLDisa}/chats/${chatId}/send-message`,
          {
            method: 'POST',
            headers: {
              Accept: 'application/json',
              'Content-Type': 'application/json',
              Authorization: `Bearer ${accessToken}`,
            },
            body: JSON.stringify({
              message: fileLink,
              //file_link: fileLink,
            }),
          }
        );

        if (!sendMessageResponse.ok) {
          throw new Error('Failed to send message with file link');
        }

        const sendMessageData = await sendMessageResponse.json();
        console.log(
          'Message with file link sent successfully:',
          sendMessageData
        );

        // Add file message to chat
        const newMessage = {
          message_id: Date.now().toString(),
          sender_name: userData.name,
          message: mimeType.startsWith('video/')
            ? 'Sent a video'
            : `Sent a file: ${name}`,
          file_link: fileLink,
          file_type: mimeType,
          sent_at: new Date().toISOString(),
        };

        const updatedMessages = [...messages, newMessage];
        setMessages(updatedMessages);
        await storeMessagesInStorage(updatedMessages);
        console.log('New message added to chat');
      } else {
        console.log('Document picker cancelled or failed');
      }
    } catch (error) {
      console.error('Error picking or uploading document:', error);
      Alert.alert('Error', 'Failed to upload file. Please try again.');
    } finally {
      // Clear loading state after upload is complete
      setIsUploading(false);
    }
  };

  const sendMessage = async () => {
    if (!messageText.trim()) {
      return;
    }

    const newMessage = {
      message_id: Date.now().toString(),
      sender_name: userData.name,
      message: messageText,
      sent_at: new Date().toISOString(),
    };

    const updatedMessages = [...messages, newMessage];
    setMessages(updatedMessages);

    try {
      await AsyncStorage.setItem(
        `@chat_messages_${chatId}`,
        JSON.stringify(updatedMessages)
      );
      setMessageText('');
    } catch (error) {
      console.error('Error storing message in AsyncStorage:', error);
    }

    setMessageText('');
    scrollToEnd();

    try {
      const response = await fetch(
        Keys.apiURLDisa + `/chats/${chatId}/send-message`,
        {
          method: 'POST',
          headers: {
            Accept: 'application/json',
            'Content-Type': 'application/json',
            Authorization: `Bearer ${accessToken}`,
          },
          body: JSON.stringify({
            message: newMessage.message,
          }),
        }
      );

      if (!response.ok) {
        throw new Error('Network response was not ok');
      }

      const data = await response.json();
      //storeMessagesInStorage(data);
    } catch (error) {
      console.error('Error sending message:', error);
    }

    setMessageText('');
  };

  const renderMessages = () => {
    if (loading) {
      return <Text>Loading...</Text>;
    }

    if (!messages || !Array.isArray(messages)) {
      return null;
    }

    const isImageURL = (url) => {
      return url.match(/\.(jpeg|jpg|gif|png)$/) != null;
    };

    const isAudioURL = (url) => {
      return url.match(/\.(mp3|wav|ogg|m4a)$/) != null;
    };

    const handleMagnetClick = () => {
      Alert.alert('Feature on its way');
    };

    const isValidURL = (string) => {
      try {
        new URL(string);
        return true;
      } catch (_) {
        return false;
      }
    };

    const renderLink = (text) => {
      const parts = text.split(/(https?:\/\/\S+)/g);
      return (
        <View style={styles.messageContainer}>
          {parts.map((part, index) =>
            isValidURL(part) ? (
              isImageURL(part) ? (
                <TouchableOpacity
                  key={index}
                  onPress={() => WebBrowser.openBrowserAsync(part)}>
                  <Image
                    source={{ uri: part }}
                    style={styles.imageAttachment}
                  />
                </TouchableOpacity>
              ) : (
                isAudioURL(part) || (
                  <TouchableOpacity
                    key={index}
                    onPress={() => WebBrowser.openBrowserAsync(part)}
                    style={styles.linkContainer}>
                    <Text style={styles.linkText}>{part}</Text>
                  </TouchableOpacity>
                )
              )
            ) : (
              <Text key={index} style={styles.bubbleText}>
                {part}
              </Text>
            )
          )}
        </View>
      );
    };

    return messages.map((message) => (
      <TouchableWithoutFeedback
        key={message.message_id}
        onLongPress={() => handleLongPress(message.message)}>
        <View
          style={[
            styles.bubble,
            message.sender_name !== 'Disa AI' ? styles.sent : styles.received,
          ]}>
          <View style={styles.messageHeader}>
            <Text style={styles.bubbleTextName}>
              {message.sender_name}
              {message.sender_name === 'Disa AI' ? ': ' + skill : ''}
            </Text>
            {(message.file_link &&
              (isImageURL(message.file_link) ||
                isAudioURL(message.file_link))) ||
            (isValidURL(message.message) &&
              (isImageURL(message.message) || isAudioURL(message.message))) ? (
              <TouchableOpacity onPress={handleMagnetClick}>
                <Ionicons name="magnet-outline" size={20} color={Colors.gray} />
              </TouchableOpacity>
            ) : (
              <TouchableOpacity onPress={() => handleShare(message.message)}>
                <Ionicons
                  name="share-social-sharp"
                  size={20}
                  color={Colors.gray}
                />
              </TouchableOpacity>
            )}
          </View>

          {isValidURL(message.message) ? (
            isImageURL(message.message) ? (
              <TouchableOpacity
                onPress={() => WebBrowser.openBrowserAsync(message.message)}>
                <Image
                  source={{ uri: message.message }}
                  style={styles.imageAttachment}
                />
              </TouchableOpacity>
            ) : isAudioURL(message.message) ? (
              <TouchableOpacity
                onPress={() => WebBrowser.openBrowserAsync(message.message)}>
                <Image
                  source={{ uri: attachFile_Image }}
                  style={styles.imageAttachment22}
                />
              </TouchableOpacity>
            ) : (
              <TouchableOpacity
                onPress={() => WebBrowser.openBrowserAsync(message.message)}
                style={styles.linkContainer}>
                <Text style={styles.linkText}>{message.message}</Text>
              </TouchableOpacity>
            )
          ) : (
            renderLink(message.message)
          )}

          <Text style={styles.timestamp}>
            {new Date(message.sent_at).toLocaleTimeString([], {
              hour: '2-digit',
              minute: '2-digit',
            })}
          </Text>

          {message.sender_name === 'Disa AI' &&
            !message.message.includes('Checklist') && (
              <View style={styles.linefeeback} />
            )}

          {message.sender_name === 'Disa AI' &&
            !message.message.includes('Checklist') && (
              <TouchableOpacity style={styles.feedbackMessageContainer}>
                <View style={styles.encryptionMessageInner}>
                  <Ionicons
                    name="podium-outline"
                    size={16}
                    color={Colors.greenwa}
                    style={styles.encryptionIcon}
                  />
                  <Text style={styles.encryptionMessage}>Feedback</Text>
                  <View style={styles.starContainer}>
                    {renderStars(message)}
                  </View>
                </View>
              </TouchableOpacity>
            )}
        </View>
      </TouchableWithoutFeedback>
    ));
  };

  const scrollToEnd = (ref) => {
    if (ref && ref.current) {
      ref.current.scrollToEnd({ animated: true });
    }
  };

  // Function to render stars for rating
  const renderStars = (message) => {
    let stars = [];
    for (let i = 1; i <= 5; i++) {
      stars.push(
        <TouchableOpacity
          key={i}
          onPress={() => handleRatingSelect(message.message_id, i)}
          style={styles.star}
          disabled={
            message.feedback !== undefined && message.feedback !== null
          }>
          <Ionicons
            name={i <= (message.feedback || 0) ? 'star' : 'star-outline'}
            size={24}
            color={i <= (message.feedback || 0) ? Colors.gold : Colors.gray}
          />
        </TouchableOpacity>
      );
    }
    return stars;
  };

  const handleRatingSelect = async (messageId, selectedRating) => {
    console.log('Selected Message ID: ' + messageId);
    console.log('Selected Rating: ' + selectedRating);

    // Check if feedback already exists
    const existingMessage = messages.find(
      (message) => message.message_id === messageId
    );
    if (
      existingMessage &&
      existingMessage.feedback !== undefined &&
      existingMessage.feedback !== null
    ) {
      Alert.alert(
        'Feedback Already Given',
        "You've already provided feedback for this message."
      );
      return;
    }

    // Immediately update UI
    setSelectedMessageId(messageId);
    setRating(selectedRating);

    // Update local state immediately
    setMessages((prevMessages) =>
      prevMessages.map((message) =>
        message.message_id === messageId
          ? { ...message, feedback: selectedRating }
          : message
      )
    );

    // Store feedback locally immediately
    await storeFeedbackLocally(messageId, selectedRating);

    // Then make the API call
    try {
      const response = await fetch(
        `${Keys.apiURLDisa}/messages/${messageId}/feedback`,
        {
          method: 'PUT',
          headers: {
            Accept: 'application/json',
            'Content-Type': 'application/json',
            Authorization: `Bearer ${accessToken}`,
          },
          body: JSON.stringify({
            feedback: selectedRating,
          }),
        }
      );

      if (!response.ok) {
        throw new Error('Network response was not ok');
      }

      const data = await response.json();
      console.log('Feedback sent successfully:', data);
    } catch (error) {
      console.error('Error sending feedback:', error);
      // Optionally, revert the UI change if the API call fails
      // This depends on your error handling strategy
      // You might want to show an error message to the user instead
    } finally {
      setSelectedMessageId(null);
    }
  };

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      keyboardVerticalOffset={Platform.OS === 'ios' ? 64 : 0}>
      {isUploading && <FullScreenLoader />}
      <ScrollView
        style={styles.chatBubbleContainer}
        contentContainerStyle={{ paddingBottom: 20 }}
        keyboardDismissMode="on-drag"
        ref={scrollViewRef}
        onContentSizeChange={() => scrollToEnd(scrollViewRef)}>
        {renderMessages()}
      </ScrollView>

      <View style={styles.inputToolbar}>
        <TouchableOpacity onPress={sendMessageDummy}>
          <Ionicons
            name="mic-circle-outline"
            color={isListening ? Colors.red : Colors.greenwa}
            size={32}
          />
        </TouchableOpacity>

        <TouchableOpacity onPress={fileUploadAttach}>
          <Ionicons
            name="add-circle-outline"
            color={Colors.greenwa}
            size={32}
          />
        </TouchableOpacity>

        <ScrollView
          style={styles.inputContainer}
          horizontal
          ref={inputScrollViewRef}
          onContentSizeChange={() => scrollToEnd(inputScrollViewRef)}>
          <TextInput
            style={styles.inputContainer2}
            placeholder="Type a message...                    "
            placeholderTextColor={Colors.gray}
            value={messageText}
            onChangeText={(text) => {
              setMessageText(text);
              scrollToEnd(inputScrollViewRef);
            }}
            onSubmitEditing={sendMessage}
          />
        </ScrollView>

        <TouchableOpacity onPress={sendMessage}>
          <Ionicons
            name="arrow-up-circle-outline"
            color={Colors.greenwa}
            size={32}
          />
        </TouchableOpacity>
      </View>
    </KeyboardAvoidingView>
  );
}

export default ChatScreen;
