import { useState } from 'react';
import Colors from '../constants/Colors';
import {
  View,
  Text,
  Linking,
  TouchableOpacity,
  KeyboardAvoidingView,
  Platform,
  TextInput,
  Alert,
  ActivityIndicator,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { useAuth } from '../AuthContext';
import Keys from '../constants/Keys';
import styles from '../constants/SignInScreen.styles';
import AsyncStorage from '@react-native-async-storage/async-storage';

const SignIn = () => {
  const { setToken } = useAuth();

  const [mobileNumber, setMobileNumber] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const navigation = useNavigation();
  const keyboardVerticalOffset = Platform.OS === 'ios' ? 90 : 0;

  const [userData, setUserData] = useState(null); // State to hold user data
  const [userDataToken, setUserDataToken] = useState(null); // State to hold user data

  const openLink = () => {
    Linking.openURL(Keys.urlDisaHome);
  };

  const handleSignIn = async () => {
    setLoading(true);
    try {
      const formData = new URLSearchParams();
      formData.append('grant_type', 'password');
      formData.append('username', mobileNumber);
      formData.append('password', password);
      formData.append('scope', '');
      formData.append('client_id', 'string');
      formData.append('client_secret', 'string');

      const response = await fetch(Keys.apiURLDisa + '/signin', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
          Accept: 'application/json',
        },
        body: formData.toString(),
      });

      if (!response.ok) {
        if (response.status === 401) {
          throw new Error('Invalid mobile number or password');
        } else {
          throw new Error('Server connection failed');
        }
      }

      const data = await response.json();

      setUserDataToken(data.access_token);
      await AsyncStorage.setItem('userData', JSON.stringify(data));
      console.log('Access Token:', data.access_token);

      // Use the setToken function from AuthContext
      await setToken(data.access_token);

      // Wait for 30 seconds and fetch user data before navigating
      //await new Promise(resolve => setTimeout(resolve, 5000));
      //await fetchDataFromAPI();

      // Navigate to Home screen after fetching user data
      navigation.navigate('Home');
    } catch (error) {
      console.error('Sign in error:', error.message);
      if (error.message === 'Invalid mobile number or password') {
        Alert.alert(
          'Sign In Failed',
          'Invalid username or password. Please try again.'
        );
      } else {
        Alert.alert(
          'Sign In Failed',
          'Unable to connect. Please contact the Disa Team.'
        );
      }
    } finally {
      setLoading(false);
    }
  };
  const isFormValid = mobileNumber.trim() !== '' && password.trim() !== '';

  return (
    <KeyboardAvoidingView
      keyboardVerticalOffset={keyboardVerticalOffset}
      style={{ flex: 1 }}
      behavior="padding">
      <View style={styles.container}>
        <Text style={styles.description}>
          Please enter your details to sign in.
        </Text>

        <View style={styles.list}>
          <TextInput
            style={styles.input}
            placeholder="Mobile Number"
            placeholderTextColor="#000000"
            value={mobileNumber}
            onChangeText={setMobileNumber}
            keyboardType="phone-pad"
          />

          <TextInput
            style={styles.input}
            placeholder="Password"
            placeholderTextColor="#000000"
            value={password}
            onChangeText={setPassword}
            secureTextEntry
          />
        </View>

        <Text style={styles.legal}>
          Learn how{' '}
          <Text style={styles.link} onPress={openLink}>
            Disa works
          </Text>
          .
        </Text>

        <View style={{ flex: 1 }} />

        <Text style={styles.legal}>
          <Text
            style={styles.link}
            onPress={() =>
              navigation.navigate('Password', { name: 'Password' })
            }>
            Forgotten password?
          </Text>
        </Text>

        <TouchableOpacity
          style={[
            styles.button,
            {
              marginBottom: 20,
              backgroundColor:
                loading || !isFormValid ? 'grey' : Colors.greenwa,
            },
          ]}
          onPress={handleSignIn}
          disabled={loading || !isFormValid} // Disable the button when loading is true or form is not valid
        >
          {loading ? (
            <ActivityIndicator color={Colors.white} size="large" />
          ) : (
            <Text style={[styles.buttonText, styles.enabled]}>Sign In</Text>
          )}
        </TouchableOpacity>
      </View>
    </KeyboardAvoidingView>
  );
};

export default SignIn;
