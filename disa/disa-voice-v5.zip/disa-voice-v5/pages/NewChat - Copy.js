import React, { useContext, useEffect, useState } from 'react';
import Colors from '../constants/Colors';
import { useFocusEffect } from '@react-navigation/native';
import {
  View,
  Text,
  TouchableOpacity,
  ActivityIndicator,
  ScrollView,
  TextInput,
  Platform,
  Image,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { useAuth } from '../AuthContext';
import Keys from '../constants/Keys';
import BoxedIcon from '../components/BoxedIcon';
import styles from '../constants/SignInScreen.styles';
import { defaultStyles } from '../constants/Styles';
import Ionicons from 'react-native-vector-icons/Ionicons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { UserContext } from '../UserContext';
import * as ImagePicker from 'expo-image-picker';

import groupIcon from '../assets/images/group-icon.png';
const group_icon = Image.resolveAssetSource(groupIcon).uri;

import cameraIcon from '../assets/images/camera-icon.png';
const camera_icon = Image.resolveAssetSource(cameraIcon).uri;

const Skills = () => {
  const { setToken } = useAuth();
  const navigation = useNavigation();
  const { accessToken } = useAuth();
  const { users, setUsers } = useContext(UserContext);
  const keyboardVerticalOffset = Platform.OS === 'ios' ? 90 : 0;
  const [userData, setUserData] = useState(null); // State to hold user data

  const [chatName, setChatName] = useState(''); // State for chat name
  const [additionalInfo, setAdditionalInfo] = useState(''); // State for additional information
  const [loading, setLoading] = useState(false);
  const [image, setImage] = useState(null);

  const [templateChecklist, setTemplateChecklist] = useState('');
  //const DEFAULT_MESSAGE = "Welcome to the new chat!";

  useEffect(() => {
    const fetchUserData = async () => {
      try {
        const storedData = await AsyncStorage.getItem('userData');
        //console.log("storedData " + storedData);
        if (storedData) {
          const parsedData = JSON.parse(storedData);
          if (parsedData.detail && parsedData.detail === 'Invalid token') {
            // If stored data indicates token is invalid, fetch from API
            //await fetchDataFromAPI();
          } else {
            // Use stored data
            setUserData(parsedData);
          }
        } else {
          // Fetch user data from API if not stored in AsyncStorage
          // await fetchDataFromAPI();
        }
      } catch (error) {
        console.error('Error fetching user data:', error);
      }
    };

    fetchUserData(); // Fetch user data when component mounts

    const fetchTemplateChecklist = async () => {
      try {
        const userData = await AsyncStorage.getItem('userData');
        if (userData) {
          const parsedUserData = JSON.parse(userData);
          setTemplateChecklist(parsedUserData.checklist || '');
        }
      } catch (error) {
        console.error('Error fetching template text:', error);
      }
    };

    fetchTemplateChecklist();

    return () => {
      // Cleanup if necessary
    };
  }, [accessToken]); // Dependency array ensures useEffect runs when accessToken changes

  useFocusEffect(
    React.useCallback(() => {
      const fetchUserData = async () => {
        try {
          const storedData = await AsyncStorage.getItem('userData');
          //console.log("storedData " + storedData);
          if (storedData) {
            const parsedData = JSON.parse(storedData);
            if (parsedData.detail && parsedData.detail === 'Invalid token') {
              // If stored data indicates token is invalid, fetch from API
              //await fetchDataFromAPI();
            } else {
              // Use stored data
              setUserData(parsedData);
            }
          } else {
            // Fetch user data from API if not stored in AsyncStorage
            // await fetchDataFromAPI();
          }
        } catch (error) {
          console.error('Error fetching user data:', error);
        }
      };

      fetchUserData(); // Fetch user data when component mounts
    }, [accessToken])
  );

  const pickImage = async () => {
    let result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      aspect: [1, 1],
      quality: 1,
    });

    if (!result.canceled) {
      setImage(result.assets[0].uri);
    }
  };

  const createNewChat = async () => {
    // Validate chat name
    if (!chatName.trim()) {
      alert('Chat name is required');
      return; // Stop execution if chat name is empty
    }

    setLoading(true);

    const formData = new FormData();

    // Ensure required fields are included and have values
    if (!chatName.trim()) {
      throw new Error('Chat name is required');
    }
    formData.append('name', chatName.trim());

    // Description is now optional
    if (additionalInfo.trim()) {
      formData.append('description', additionalInfo.trim());
    }

    const welcomeMessage = 'Checklist \n' + templateChecklist;
    if (!welcomeMessage.trim()) {
      throw new Error('Welcome message is required');
    }
    formData.append('welcome_message', welcomeMessage.trim());

    if (image) {
      const imageUriParts = image.split('.');
      const imageExtension = imageUriParts[imageUriParts.length - 1];

      formData.append('image', {
        uri: image,
        name: `chat_image.${imageExtension}`,
        type: `image/${imageExtension}`,
      });
    }

    try {
      console.log('Sending formData:', formData);
      const response = await fetch(Keys.apiURLDisa + '/chats', {
        method: 'POST',
        headers: {
          Accept: 'application/json',
          Authorization: `Bearer ${accessToken}`,
        },
        body: formData,
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(
          `HTTP error! status: ${response.status}, message: ${JSON.stringify(
            errorData
          )}`
        );
      }

      const data = await response.json();
      console.log('Chat created 22:', data);

      if (data.chat_id) {
        await sendDefaultMessage(data.chat_id);
        await fetchChatList();

        navigation.navigate('Chat', {
          chatId: data.chat_id,
          userName: chatName,
          groupIconUrl: data.group_icon_url,
        });
      } else {
        throw new Error('Chat creation response did not include a chat_id');
      }
    } catch (error) {
      console.log('Error creating chat:', error);
      alert('Error creating new chat: ' + error.message);
    } finally {
      setLoading(false);
    }
  };

  const fetchTemplateChecklist = async () => {
    try {
      const userData = await AsyncStorage.getItem('userData');
      if (userData) {
        const parsedUserData = JSON.parse(userData);
        setTemplateChecklist(parsedUserData.checklist || '');
      }
    } catch (error) {
      console.error('Error fetching template text:', error);
    }
  };

  fetchTemplateChecklist();

  const sendDefaultMessage = async (chatId) => {
    const newMessage = {
      message_id: Date.now().toString(),
      sender_name: 'Disa AI',
      message: 'Checklist \n' + templateChecklist,
      sent_at: new Date().toISOString(),
    };

    try {
      // Store the message locally
      const storedMessages = await AsyncStorage.getItem(
        `@chat_messages_${chatId}`
      );
      const updatedMessages = storedMessages
        ? [...JSON.parse(storedMessages), newMessage]
        : [newMessage];
      await AsyncStorage.setItem(
        `@chat_messages_${chatId}`,
        JSON.stringify(updatedMessages)
      );
    } catch (error) {
      console.error('Error sending default message:', error);
    }
  };

  const fetchChatList = async () => {
    setLoading(true);

    try {
      const response = await fetch(Keys.apiURLDisa + '/allchats', {
        headers: {
          Accept: 'application/json',
          Authorization: `Bearer ${accessToken}`,
        },
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();

      if (data && Array.isArray(data)) {
        const archivedChats =
          JSON.parse(await AsyncStorage.getItem('archivedChats')) || [];
        const storedUsers =
          JSON.parse(await AsyncStorage.getItem('users')) || [];

        // Keep the archived chats
        const archivedUsers = storedUsers.filter((user) =>
          archivedChats.includes(user.id)
        );

        // Process new chats
        const newUsers = data
          .filter((chat) => !archivedChats.includes(chat.chat_id))
          .map((chat) => ({
            id: chat.chat_id,
            name: chat.creator_name,

            avatar: chat.group_icon_url ? chat.group_icon_url : group_icon,
            lastMessage: 'Task ID ',
            timestamp: new Date(chat.created_at).toLocaleTimeString([], {
              hour: '2-digit',
              minute: '2-digit',
            }),
          }));

        // Combine archived and new users
        const allUsers = [...archivedUsers, ...newUsers];

        await storeUsersData(allUsers);
        setUsers(newUsers); // Only set active users for the main screen
        //setFilteredUsers(newUsers);
      } else {
        console.log('Unexpected data format:', data);
      }
    } catch (error) {
      console.error('Error fetching data (fetchChatList):', error);
    } finally {
      setLoading(true);
    }
  };

  const storeUsersData = async (usersData) => {
    try {
      const jsonUsers = JSON.stringify(usersData);
      await AsyncStorage.setItem('users', jsonUsers);
      //console.log("Users data stored successfully!");
    } catch (e) {
      console.error('Failed to store users data:', e);
    }
  };

  return (
    <View style={{ flex: 1, backgroundColor: Colors.background }}>
      <ScrollView
        contentInsetAdjustmentBehavior="automatic"
        contentContainerStyle={{ paddingBottom: 40 }}>
        <View style={styles.container}>
          <TouchableOpacity
            onPress={pickImage}
            style={styles.imagePickerContainer}>
            {image ? (
              <Image source={{ uri: image }} style={styles.previewImage} />
            ) : (
              <Image
                source={{
                  uri: camera_icon,
                }}
                style={styles.previewImage}
              />
            )}
          </TouchableOpacity>

          <View style={styles.list}>
            <TextInput
              style={styles.input}
              placeholder="Chat Name"
              placeholderTextColor="#000000"
              value={chatName}
              onChangeText={setChatName}
            />

            <TextInput
              style={styles.input}
              placeholder="Additional Information (optional)"
              placeholderTextColor="#000000"
              keyboardType="email-address"
              value={additionalInfo}
              onChangeText={setAdditionalInfo}
            />
            <Text style={defaultStyles.item28}>
              You can include extra details such as a phone number or other
              contact information if needed.
            </Text>
          </View>

          <View style={styles.list}>
            <TouchableOpacity
              onPress={() => navigation.navigate('Skills', { name: 'Skills' })}>
              <View style={defaultStyles.item27}>
                {userData && (
                  <>
                    <BoxedIcon
                      name="bulb-outline"
                      backgroundColor={Colors.greenwa}
                    />
                    <Text style={{ fontSize: 18, flex: 1 }}>
                      {userData.industry}
                    </Text>
                    <Ionicons
                      name="chevron-forward-outline"
                      size={28}
                      color={Colors.black}
                    />
                  </>
                )}
              </View>
            </TouchableOpacity>
          </View>

          <View style={{ flex: 1 }} />

          <TouchableOpacity
            style={[
              styles.button,
              { marginBottom: 20 },
              {
                backgroundColor: Colors.greenwa,
              },
            ]}
            onPress={createNewChat}>
            {loading ? (
              <ActivityIndicator color={Colors.white} size="large" />
            ) : (
              <Text style={[styles.buttonText, styles.enabled]}>
                Create Chat
              </Text>
            )}
          </TouchableOpacity>
        </View>
      </ScrollView>
    </View>
  );
};

export default Skills;
