//Archive.js
import React, { useContext, useEffect, useState } from 'react';
import { useFocusEffect } from '@react-navigation/native';
import Colors from '../constants/Colors';
import { defaultStyles } from '../constants/Styles';
import BoxedIcon from '../components/BoxedIcon';
import Keys from '../constants/Keys';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {
  Image,
  Text,
  TouchableOpacity,
  View,
  ScrollView,
  FlatList,
  ActivityIndicator,
  Modal,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';

import { useAuth } from '../AuthContext';

import { UserContext } from '../UserContext';

import Ionicons from 'react-native-vector-icons/Ionicons';
import styles from '../constants/HomeScreen.styles';
import { SearchBar } from '@rneui/themed';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Linking } from 'react-native'; // Import Linking API

import welcomeImage from '../assets/images/welcome.png';
const welcome_image = Image.resolveAssetSource(welcomeImage).uri;

import groupIcon from '../assets/images/group-icon.png';
const group_icon = Image.resolveAssetSource(groupIcon).uri;

import userIcon from '../assets/images/user-icon.png';

import newsData from './newsData'; // Import the news data
import settingsPageLinksData from './settingsPageLinksData'; // Import the setting page data

//const Stack = createStackNavigator();

function ArchivedChatsScreen() {
  const [archivedChats, setArchivedChats] = useState([]);
  const navigation = useNavigation();

  useFocusEffect(
    React.useCallback(() => {
      loadArchivedChats();
    }, [])
  );

  useEffect(() => {
    loadArchivedChats();
  }, []);

  const loadArchivedChats = async () => {
    try {
      const archivedChatIds =
        JSON.parse(await AsyncStorage.getItem('archivedChats')) || [];
      const allUsers = JSON.parse(await AsyncStorage.getItem('users')) || [];
      const archivedUsers = allUsers.filter((user) =>
        archivedChatIds.includes(user.id)
      );
      setArchivedChats(archivedUsers);
    } catch (error) {
      console.error('Error loading archived chats:', error);
    }
  };

  const unarchiveChat = async (chatId) => {
    try {
      const archivedChatIds =
        JSON.parse(await AsyncStorage.getItem('archivedChats')) || [];
      const updatedArchivedChatIds = archivedChatIds.filter(
        (id) => id !== chatId
      );
      await AsyncStorage.setItem(
        'archivedChats',
        JSON.stringify(updatedArchivedChatIds)
      );
      await loadArchivedChats();
    } catch (error) {
      console.error('Error unarchiving chat:', error);
    }
  };

  const renderItem = ({ item }) => (
    <TouchableOpacity
      style={styles.userRow}
      onPress={() =>
        navigation.navigate('Chat', { chatId: item.id, userName: item.name })
      }>
      <Image source={{ uri: item.avatar }} style={styles.avatar} />
      <View style={styles.userInfo}>
        <Text style={styles.userName}>{item.name}</Text>
        <Text style={styles.lastMessage}>{item.lastMessage + item.id}</Text>
      </View>
      <Text style={styles.timestamp}>{item.timestamp}</Text>
      <TouchableOpacity onPress={() => unarchiveChat(item.id)}>
        <Ionicons name="albums-outline" size={24} color={Colors.greenwa} />
      </TouchableOpacity>
    </TouchableOpacity>
  );

  return (
    <View style={styles.container}>
      <FlatList
        data={archivedChats}
        renderItem={renderItem}
        keyExtractor={(item) => item.id.toString()}
      />
    </View>
  );
}

export default ArchivedChatsScreen;
