import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Image,
  Button,
  TouchableOpacity,
  ScrollView,
  FlatList,
  Alert,
  ActivityIndicator,
  Share,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import Colors from '../constants/Colors';
import { defaultStyles } from '../constants/Styles';
import BoxedIcon from '../components/BoxedIcon';
import styles from '../constants/HomeScreen.styles';
import { useAuth } from '../AuthContext';
import Keys from '../constants/Keys';
import Ionicons from 'react-native-vector-icons/Ionicons';
import * as Clipboard from 'expo-clipboard';



import groupIcon from '../assets/images/group-icon.png';
const group_icon = Image.resolveAssetSource(groupIcon).uri;

const ContactInfo = ({ route }) => {
  const { userName, chatId, avatar } = route.params;
  const { accessToken } = useAuth();
  const navigation = useNavigation();

  const [companyUsers, setCompanyUsers] = useState([]);
  const [loading, setLoading] = useState(false);
  const [showUserList, setShowUserList] = useState(false);
  const [skill, setSkill] = useState('');

  // Function to fetch skills by chatId
  const fetchSkillsByChatId = async (chatId) => {
    try {
      const storedUsers = await AsyncStorage.getItem('users');

      if (storedUsers) {
        const users = JSON.parse(storedUsers);
        const user = users.find((user) => user.id === chatId);
        return user ? user.lastMessage : null; // Return skills or null if not found
      }
      return null;
    } catch (error) {
      console.error('Failed to fetch users from storage:', error);
      return null;
    }
  };

  useEffect(() => {
    const loadSkill = async () => {
      const userSkill = await fetchSkillsByChatId(chatId);
      if (userSkill) {
        setSkill(userSkill);
      }
    };

    loadSkill();
  }, [chatId]);

  const fetchCompanyUsers = async () => {
    setLoading(true);
    try {
      const response = await fetch(`${Keys.apiURLDisa}/chats/${chatId}/users`, {
        headers: {
          Accept: 'application/json',
          Authorization: `Bearer ${accessToken}`,
        },
      });
      const data = await response.json();
      setCompanyUsers(data);
      setLoading(false);
    } catch (error) {
      console.error('Error fetching company users:', error);
      Alert.alert('Error', 'Failed to fetch company users');
      setLoading(false);
    }
  };

  const handleAddRemoveMembers = () => {
    setShowUserList(true);
    fetchCompanyUsers();
  };

  const removeUserFromChat = async (userId) => {
    setLoading(true);
    try {
      const response = await fetch(
        `${Keys.apiURLDisa}/chats/${chatId}/remove-user/${userId}`,
        {
          method: 'DELETE',
          headers: {
            Accept: 'application/json',
            Authorization: `Bearer ${accessToken}`,
          },
        }
      );
      const data = await response.json();
      Alert.alert('Success', data.message);
      setLoading(false);
      fetchCompanyUsers();
    } catch (error) {
      console.error('Error removing user from chat:', error);
      Alert.alert('Error', 'Failed to remove user from chat');
      setLoading(false);
    }
  };

  const addUserToChat = async (userId) => {
    setLoading(true);
    try {
      const isInChat = companyUsers.some(
        (user) => user.id === userId && user.member_status
      );
      if (isInChat) {
        Alert.alert('Info', 'User is already a member of the chat.');
        setLoading(false);
        return;
      }

      const response = await fetch(
        `${Keys.apiURLDisa}/chats/${chatId}/add-user/${userId}`,
        {
          method: 'POST',
          headers: {
            Accept: 'application/json',
            Authorization: `Bearer ${accessToken}`,
          },
        }
      );
      const data = await response.json();
      Alert.alert('Success', data.message);
      setLoading(false);
      fetchCompanyUsers();
    } catch (error) {
      console.error('Error adding user to chat:', error);
      Alert.alert('Error', 'Failed to add user to chat');
      setLoading(false);
    }
  };

  const deleteChat = async () => {
    setLoading(true);
    try {
      const response = await fetch(`${Keys.apiURLDisa}/chats/${chatId}`, {
        method: 'DELETE',
        headers: {
          accept: 'application/json',
          Authorization: `Bearer ${accessToken}`,
        },
      });
      const data = await response.json();
      setLoading(false);
      Alert.alert('Success', data.message);
      navigation.navigate('Home');
    } catch (error) {
      console.error('Error deleting chat:', error);
      setLoading(false);
      Alert.alert('Error', 'Failed to delete chat');
    }
  };

  const exportChat = async () => {
    try {
      const messagesJson = await AsyncStorage.getItem(
        `@chat_messages_${chatId}`
      );
      if (messagesJson) {
        const messages = JSON.parse(messagesJson);
        const chatText = messages
          .map((message) => `${message.sender_name}: ${message.message}\n`)
          .join('\n');
        await Share.share({
          message: chatText,
          title: 'Chat Export',
        });
      } else {
        Alert.alert('No Messages', 'There are no messages to export.');
      }
    } catch (error) {
      console.error('Error exporting chat:', error);
      Alert.alert('Error', 'Failed to export chat.');
    }
  };

  const copyChatToClipboard = async () => {
    try {
      const messagesJson = await AsyncStorage.getItem(
        `@chat_messages_${chatId}`
      );
      if (messagesJson) {
        const messages = JSON.parse(messagesJson);
        const chatText = messages
          .map((message) => `${message.sender_name}: ${message.message}\n`)
          .join('\n');
        await Clipboard.setStringAsync(chatText);
        Alert.alert('Success', 'Conversation copied to clipboard.');
      } else {
        Alert.alert('No Messages', 'There are no messages to copy.');
      }
    } catch (error) {
      console.error('Error copying conversation:', error);
      Alert.alert('Error', 'Failed to copy conversation.');
    }
  };

  const renderCompanyUser = ({ item }) => {
    const isInChat = item.member_status;
    const disableTouch = loading;

    const handlePress = () => {
      if (!disableTouch) {
        if (!isInChat) {
          addUserToChat(item.id);
        } else {
          removeUserFromChat(item.id);
        }
      }
    };

    return (
      <TouchableOpacity disabled={disableTouch} onPress={handlePress}>
        <View style={defaultStyles.item}>
          <BoxedIcon
            name={isInChat ? 'person-remove-outline' : 'person-add-outline'}
            backgroundColor={isInChat ? Colors.gray : Colors.greenwa}
          />
          
          <Text style={{ fontSize: 18, flex: 1 }}>{item.name}</Text>
          <Ionicons
            name={isInChat ? 'remove-circle-outline' : 'add-circle-outline'}
            size={28}
            color={Colors.black}
          />
        </View>
      </TouchableOpacity>
    );
  };

  return (
    <View style={{ flex: 1, backgroundColor: Colors.background }}>
      <ScrollView
        contentInsetAdjustmentBehavior="automatic"
        contentContainerStyle={{ paddingBottom: 40 }}>
        <View style={styles.headline}>
          <Text style={styles.headlineName}>
            {' '}
            <Image source={{ uri: avatar }} style={styles.avatar27} />
          </Text>
          <Text style={styles.headlineName}>{userName}</Text>
        </View>

        <View style={defaultStyles.block}>
          <>
            <View style={defaultStyles.item}>
            
               <Ionicons name="information-outline" size={20} color={Colors.black} />
              <Text style={{ fontSize: 18, flex: 1 }}>
                Reference ID : {chatId}
              </Text>
            </View>
          </>
        </View>

        <View style={defaultStyles.block}>
          <>
            <View style={defaultStyles.item}>
             <Ionicons name="bulb-outline" size={20} color={Colors.black} />
             
              <Text style={{ fontSize: 18, flex: 1 }}>{skill}</Text>
            </View>
          </>
        </View>

        <View style={defaultStyles.block}>
          <TouchableOpacity onPress={handleAddRemoveMembers}>
            <View style={defaultStyles.item}>
              <BoxedIcon
                name="people-outline"
                backgroundColor={Colors.greenwa}
              />
              <Text style={{ fontSize: 18, flex: 1 }}>
                Add / Remove Members
              </Text>
              <Ionicons
                name="chevron-forward-outline"
                size={28}
                color={Colors.black}
              />
            </View>
          </TouchableOpacity>
        </View>

        {showUserList && (
          <View style={defaultStyles.block}>
            {loading ? (
              <View style={{ paddingTop: 5, paddingBottom: 5 }}>
                <ActivityIndicator color={Colors.greenwa} size="small" />
              </View>
            ) : null}

            <FlatList
              data={companyUsers}
              renderItem={renderCompanyUser}
              keyExtractor={(item) => item.id.toString()}
              scrollEnabled={false}
              ItemSeparatorComponent={() => (
                <View style={defaultStyles.separator} />
              )}
            />
          </View>
        )}

        <TouchableOpacity onPress={copyChatToClipboard}>
          <View style={defaultStyles.block}>
            <View style={defaultStyles.item}>
              <BoxedIcon name="copy-outline" backgroundColor={Colors.greenwa} />
              <Text style={{ fontSize: 18, flex: 1 }}>Copy Conversation</Text>
              <Ionicons
                name="chevron-forward-outline"
                size={28}
                color={Colors.black}
              />
            </View>
          </View>
        </TouchableOpacity>

        <TouchableOpacity onPress={exportChat}>
          <View style={defaultStyles.block}>
            <>
              <View style={defaultStyles.item}>
                <BoxedIcon
                  name="share-social-outline"
                  backgroundColor={Colors.greenwa}
                />
                <Text style={{ fontSize: 18, flex: 1 }}>
                  Export Conversation
                </Text>
                <Ionicons
                  name="chevron-forward-outline"
                  size={28}
                  color={Colors.black}
                />
              </View>
            </>
          </View>
        </TouchableOpacity>

        <TouchableOpacity onPress={deleteChat}>
          <View style={defaultStyles.block}>
            <>
              <View style={defaultStyles.item}>
                <BoxedIcon name="trash-outline" backgroundColor={Colors.red} />
                <Text style={{ fontSize: 18, flex: 1 }}>
                  Delete Conversation
                </Text>
                <Ionicons
                  name="chevron-forward-outline"
                  size={28}
                  color={Colors.black}
                />
              </View>
            </>
          </View>
        </TouchableOpacity>
      </ScrollView>
    </View>
  );
};

export default ContactInfo;
