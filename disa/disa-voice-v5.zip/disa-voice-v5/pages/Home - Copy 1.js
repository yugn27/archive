//Home.js code
import React, { useContext, useEffect, useState } from 'react';
import { useFocusEffect } from '@react-navigation/native';
import Colors from '../constants/Colors';
import { defaultStyles } from '../constants/Styles';
import BoxedIcon from '../components/BoxedIcon';
import Keys from '../constants/Keys';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {
  Image,
  Text,
  TouchableOpacity,
  View,
  ScrollView,
  FlatList,
  ActivityIndicator,
  RefreshControl,
  Modal,
  Alert, // Add this line
  Platform // And this line
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { useAuth } from '../AuthContext';
import { UserContext } from '../UserContext';
import Ionicons from 'react-native-vector-icons/Ionicons';
import styles from '../constants/HomeScreen.styles';
import { SearchBar } from '@rneui/themed';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Linking } from 'react-native'; // Import Linking API

import * as FileSystem from 'expo-file-system';

import * as ImagePicker from 'expo-image-picker';

import welcomeImage from '../assets/images/welcome.png';
const welcome_image = Image.resolveAssetSource(welcomeImage).uri;

import groupIcon from '../assets/images/group-icon.png';
const group_icon = Image.resolveAssetSource(groupIcon).uri;

import userIcon from '../assets/images/user-icon.png';
import newsData from './newsData'; // Import the news data
import settingsPageLinksData from './settingsPageLinksData'; // Import the setting page data

import styles_chat from '../constants/UpdateScreen.styles';

//const Stack = createStackNavigator();

function HomeScreen() {
  const navigation = useNavigation();
  const { accessToken } = useAuth();
  const { users, setUsers } = useContext(UserContext);
  const [filteredUsers, setFilteredUsers] = useState([]);
  const [loading, setLoading] = useState(false);
  const [search, setSearch] = useState('');
  const [refreshing, setRefreshing] = useState(false); // State for refreshing
  

  useFocusEffect(
    React.useCallback(() => {
      fetchChatListFromStorageRe();
    }, [])
  );

  useEffect(() => {
    navigation.setOptions({
      headerRight: () => (
        <TouchableOpacity
          onPress={navigatetoNewChat}
          style={{ paddingRight: 10 }}
          disabled={loading}>
          {loading ? (
            <ActivityIndicator color={Colors.greenwa} size="small" />
          ) : (
            <Ionicons name="add-circle" size={28} color={Colors.greenwa} />
          )}
        </TouchableOpacity>
      ),
      headerLeft: () => (
        <TouchableOpacity
          onPress={navigatetoArchived}
          style={{ paddingLeft: 10 }}
          disabled={loading}>
          {loading ? (
            <ActivityIndicator color={Colors.greenwa} size="small" />
          ) : (
            <Ionicons name="archive" size={24} color={Colors.greenwa} />
          )}
        </TouchableOpacity>
      ),
    });

    fetchChatListFromStorage().then(async (storedUsers) => {
      const archivedChats =
        JSON.parse(await AsyncStorage.getItem('archivedChats')) || [];
      if (storedUsers && storedUsers.length > 0) {
        const activeUsers = storedUsers.filter(
          (user) => !archivedChats.includes(user.id)
        );
        setUsers(activeUsers);
        setFilteredUsers(activeUsers);
      } else {
        fetchChatList();
      }
    });
  }, [accessToken, navigation]);

  const fetchChatListFromStorage = async () => {
    try {
      const storedUsers = await AsyncStorage.getItem('users');
      return storedUsers ? JSON.parse(storedUsers) : [];
    } catch (e) {
      console.error('Failed to fetch users from storage:', e);
      return [];
    }
  };

  const navigatetoArchived = async () => {
    navigation.navigate('Archived');
  };

  const navigatetoNewChat = async () => {
    navigation.navigate('NewChat');
  };

  const fetchChatListFromStorageRe = async () => {
    fetchChatListFromStorage().then(async (storedUsers) => {
      const archivedChats =
        JSON.parse(await AsyncStorage.getItem('archivedChats')) || [];
      if (storedUsers && storedUsers.length > 0) {
        const activeUsers = storedUsers.filter(
          (user) => !archivedChats.includes(user.id)
        );
        setUsers(activeUsers);
        setFilteredUsers(activeUsers);
      }
    });
  };

  const archiveChat = async (chatId) => {
    try {
      const archivedChats =
        JSON.parse(await AsyncStorage.getItem('archivedChats')) || [];
      if (!archivedChats.includes(chatId)) {
        archivedChats.push(chatId);
        await AsyncStorage.setItem(
          'archivedChats',
          JSON.stringify(archivedChats)
        );
        const updatedFilteredUsers = filteredUsers.filter(
          (user) => user.id !== chatId
        );
        setFilteredUsers(updatedFilteredUsers);
      }
    } catch (error) {
      console.error('Error archiving chat:', error);
    }
  };

  const fetchChatList = async () => {
    setLoading(true);
    console.log('accessToken from Home.js : ' + accessToken);

    try {
      const response = await fetch(Keys.apiURLDisa + '/allchats', {
        headers: {
          Accept: 'application/json',
          Authorization: `Bearer ${accessToken}`,
        },
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();

      if (data && Array.isArray(data)) {
        const archivedChats =
          JSON.parse(await AsyncStorage.getItem('archivedChats')) || [];
        const storedUsers =
          JSON.parse(await AsyncStorage.getItem('users')) || [];

        // Keep the archived chats
        const archivedUsers = storedUsers.filter((user) =>
          archivedChats.includes(user.id)
        );

        // Process new chats
        const newUsers = data
          .filter((chat) => !archivedChats.includes(chat.chat_id))
          .map((chat) => ({
            id: chat.chat_id,
            name: chat.creator_name,

            avatar: chat.group_icon_url ? chat.group_icon_url : group_icon,

            lastMessage: 'Task ID ',
            timestamp: new Date(chat.created_at).toLocaleTimeString([], {
              hour: '2-digit',
              minute: '2-digit',
            }),
          }));

        // Combine archived and new users
        const allUsers = [...archivedUsers, ...newUsers];

        await storeUsersData(allUsers);
        setUsers(newUsers); // Only set active users for the main screen
        setFilteredUsers(newUsers);
      } else {
        console.log('Unexpected data format:', data);
      }
    } catch (error) {
      console.error('Error fetching data (fetchChatList):', error);
    } finally {
      setLoading(false);
    }
  };

  const storeUsersData = async (usersData) => {
    try {
      const jsonUsers = JSON.stringify(usersData);
      await AsyncStorage.setItem('users', jsonUsers);
      console.log('Users data stored successfully!');
    } catch (e) {
      console.error('Failed to store users data:', e);
    }
  };

  const updateSearch = (search) => {
    setSearch(search);
    if (search === '') {
      setFilteredUsers(users);
    } else {
      const filtered = users.filter(
        (user) =>
          user.name.toLowerCase().includes(search.toLowerCase()) ||
          user.lastMessage.toLowerCase().includes(search.toLowerCase())
      );
      setFilteredUsers(filtered);
    }
  };

  // Handler for pull-to-refresh
  const onRefresh = async () => {
    setRefreshing(true);
    await fetchChatList();
    setRefreshing(false);
  };

  return (
    <View style={styles.container}>
      {loading && (
        <View style={{ paddingTop: 5, paddingBottom: 5 }}>
          <ActivityIndicator color={Colors.greenwa} size="small" />
        </View>
      )}
      <SearchBar
        platform="ios"
        containerStyle={{ height: 50 }}
        inputContainerStyle={{ height: 35, backgroundColor: Colors.searchHome }}
        placeholder="Search"
        placeholderTextColor="#888"
        round
        value={search}
        showCancel
        cancelButtonTitle="Cancel"
        searchIcon={
          <Ionicons name="search-outline" size={20} color={Colors.primary} />
        }
        onChangeText={updateSearch}
      />
      <ScrollView
        contentContainerStyle={styles.userList}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={onRefresh}
            colors={[Colors.primary]} // Customize the refresh control spinner color
          />
        }>
        {filteredUsers.map((user) => (
          <TouchableOpacity
            key={user.id}
            style={styles.userRow}
            onPress={() =>
              navigation.navigate('Chat', {
                chatId: user.id,
                userName: user.name,
                avatar: user.avatar,
              })
            }>
            <Image
              source={{ uri: user.avatar }}
              style={styles.avatar}
              key={user.avatar} // Add key to force re-render of Image component
            />
            <View style={styles.userInfo}>
              <Text style={styles.userName}>{user.name}</Text>
              <Text style={styles.lastMessage}>
                {user.lastMessage + user.id}
              </Text>
            </View>
            <Text style={styles.timestamp}>{user.timestamp}</Text>
            <TouchableOpacity onPress={() => archiveChat(user.id)}>
              <Ionicons name="archive" size={24} color={Colors.greenwa} />
            </TouchableOpacity>
          </TouchableOpacity>
        ))}
      </ScrollView>
    </View>
  );
}

// Component to render each news item
const NewsItem = ({ item }) => {
  const formattedDate = new Intl.DateTimeFormat('en-GB', {
    day: '2-digit',
    month: 'long',
    year: 'numeric',
  }).format(new Date(item.created_at));

  return (
    <TouchableOpacity style={styles_chat.newsItem}>
      <Image source={{ uri: item.image_url }} style={styles_chat.newsImage} />
      <View style={styles_chat.newsTextContainer}>
        <Text style={styles_chat.newsTitle}>{item.title}</Text>
        <Text style={styles_chat.newsSummary}>{item.content}</Text>
        <Text style={styles_chat.newsDate}>{formattedDate}</Text>
      </View>
    </TouchableOpacity>
  );
};

const UpdateScreen = () => {
  const [newsData, setNewsData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [corporateCode, setCorporateCode] = useState('DISA'); // Default corporate code

  useEffect(() => {
    const fetchCorporateCode = async () => {
      try {
        const storedData = await AsyncStorage.getItem('userData');
        if (storedData) {
          const parsedData = JSON.parse(storedData);
          if (parsedData.corporate_code) {
            setCorporateCode(parsedData.corporate_code);
          }
        }
      } catch (error) {
        console.error('Error fetching corporate code from userData:', error);
      }
    };

    const fetchNewsData = async () => {
      try {
        await fetchCorporateCode(); // Fetch the corporate code first

        // Wait for corporateCode state to be updated
        const response = await fetch(
          `${Keys.apiURLDisaStatic}/fetch_posts.php?company_id=${corporateCode}`
        );
        console.log(corporateCode);

        if (!response.ok) {
          throw new Error('Network response was not ok');
        }
        const data = await response.json();
        setNewsData(data);
      } catch (error) {
        setError(error.message);
      } finally {
        setLoading(false);
      }
    };

    fetchNewsData();
  }, [corporateCode]); // Add corporateCode as a dependency

  if (loading) {
    return (
      <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
        <ActivityIndicator size="large" color={Colors.greenwa} />
      </View>
    );
  }

  if (error) {
    return (
      <View style={styles_chat.container}>
        <Text>Error: {error}</Text>
      </View>
    );
  }

  return (
    <ScrollView style={styles_chat.container}>
      <FlatList
        data={newsData}
        keyExtractor={(item) => item.id.toString()}
        renderItem={({ item }) => <NewsItem item={item} />}
        showsVerticalScrollIndicator={false} // Hide the scroll bar
      />
    </ScrollView>
  );
};

const SettingsScreen_DNU = () => {
  const { accessToken, removeToken } = useAuth();
  const navigation = useNavigation();
  const [userData, setUserData] = useState(null); // State to hold user data
  const { setUsers } = useContext(UserContext);

  const [loading, setLoading] = useState(false); // State to manage loading status

  useEffect(() => {
    const fetchUserData = async () => {
      try {
        const storedData = await AsyncStorage.getItem('userData');
        if (storedData) {
          const parsedData = JSON.parse(storedData);
          if (parsedData.detail && parsedData.detail === 'Invalid token') {
            // await fetchDataFromAPI();
          } else {
            if (parsedData.profile_image) {
              const localImageUri = await downloadAndSaveImage(
                parsedData.profile_image
              );
              if (localImageUri) {
                parsedData.local_profile_image = localImageUri;
              }
            }
            setUserData(parsedData);
            await AsyncStorage.setItem('userData', JSON.stringify(parsedData));
          }
        } else {
          // await fetchDataFromAPI();
        }
      } catch (error) {
        console.error('Error fetching user data:', error);
      }
    };

    fetchUserData();
  }, [accessToken]);

  useFocusEffect(
    React.useCallback(() => {
      const fetchUserData = async () => {
        try {
          const storedData = await AsyncStorage.getItem('userData');
          if (storedData) {
            const parsedData = JSON.parse(storedData);
            if (parsedData.detail && parsedData.detail === 'Invalid token') {
              // await fetchDataFromAPI();
            } else {
              if (parsedData.profile_image) {
                const localImageUri = await downloadAndSaveImage(
                  parsedData.profile_image
                );
                if (localImageUri) {
                  parsedData.local_profile_image = localImageUri;
                }
              }
              setUserData(parsedData);
              await AsyncStorage.setItem(
                'userData',
                JSON.stringify(parsedData)
              );
            }
          } else {
            // await fetchDataFromAPI();
          }
        } catch (error) {
          console.error('Error fetching user data:', error);
        }
      };

      fetchUserData();
    }, [accessToken])
  );

  const downloadAndSaveImage = async (imageUrl) => {
    try {
      const fileName = imageUrl.split('/').pop();
      const fileUri = `${FileSystem.documentDirectory}${fileName}`;

      const downloadResult = await FileSystem.downloadAsync(imageUrl, fileUri);

      if (downloadResult.status === 200) {
        console.log('Image downloaded successfully');
        return fileUri;
      } else {
        console.log('Image download failed');
        return null;
      }
    } catch (error) {
      console.error('Error downloading image:', error);
      return null;
    }
  };

  const handleLogout = async () => {
    try {
      setUserData(null);
      setUsers([]);

      await AsyncStorage.removeItem('userData');
      await AsyncStorage.removeItem('users');

      removeToken();

      navigation.navigate('IntroPage');
    } catch (error) {
      console.error('Error logging out:', error);
    }
  };

  const handleSupportItemPress = (item) => {
    if (item.url) {
      Linking.openURL(item.url);
    }
  };

  const handleImagePicker = async () => {
    console.log('Starting image picker');
    setLoading(true); // Set loading to true

    // Request permission to access media library
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    console.log('Media library permissions status:', status);

    if (status !== 'granted') {
      Alert.alert(
        'Permission required',
        'We need permission to access your media library.'
      );
      setLoading(false); // Set loading to false
      return;
    }

    console.log('Launching image library');
    // Launch image picker
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      quality: 1,
    });

    console.log('Image picker result:', result);

    if (!result.canceled) {
      const { uri } = result.assets[0];
      console.log('Selected image URI:', uri);

      const formData = new FormData();
      formData.append('file', {
        uri,
        type: 'image/jpeg', // Adjust if necessary
        name: 'profile-pic.jpg', // Adjust if necessary
      });

      console.log('Form data created');

      try {
        console.log('Starting image upload');

        const uploadResponse = await fetch(Keys.apiURLDisa + '/userpics/', {
          method: 'POST',
          headers: {
            Accept: 'application/json',
            Authorization: `Bearer ${accessToken}`,
            'Content-Type': 'multipart/form-data',
          },
          body: formData,
        });

        const responseText = await uploadResponse.text(); // Get raw response text
        console.log('Raw upload response:', responseText);

        let result;
        try {
          result = JSON.parse(responseText); // Attempt to parse JSON
        } catch (error) {
          console.error('Error parsing JSON response:', error);
          return;
        }

        console.log('Upload result:', result);

        if (result.file_url) {
          const localImageUri = await downloadAndSaveImage(result.file_url);
          const updatedUserData = {
            ...userData,
            profile_image: result.file_url,
            local_profile_image: localImageUri,
          };
          setUserData(updatedUserData);
          await AsyncStorage.setItem(
            'userData',
            JSON.stringify(updatedUserData)
          );
          console.log('User data updated and stored in AsyncStorage');
        } else {
          Alert.alert(
            'Upload failed',
            result.message || 'Something went wrong'
          );
          console.log('Upload failed message:', result.message);
        }
      } catch (error) {
        console.error('Error uploading image:', error);
      }

      setLoading(false); // Set loading to false after the operation
    } else {
      console.log('Image picker was cancelled');
      setLoading(false); // Set loading to false if the picker was cancelled
    }
  };

  return (
    <View style={{ flex: 1, backgroundColor: Colors.background }}>
      <ScrollView
        contentInsetAdjustmentBehavior="automatic"
        contentContainerStyle={{ paddingBottom: 40 }}>
        <View style={styles.headline}>
          {userData && (
            <>
              <TouchableOpacity onPress={handleImagePicker}>
                <Text style={styles.headlineName}>
                  {' '}
                  {loading ? (
                    <ActivityIndicator
                      size="large"
                      color={Colors.greenwa}
                      style={styles.avatar27}
                    />
                  ) : (
                    <Image
                      source={{
                        uri:userIcon
                          //userData.local_profile_image ||
                          //userData.profile_image ||
                         // userIcon,
                      }}
                      style={styles.avatar27}
                    />
                  )}
                </Text>
              </TouchableOpacity>
              <Text style={styles.headlineName}>{userData.name}</Text>
            </>
          )}
        </View>

        <View style={defaultStyles.block}>
          {userData && (
            <>
              <View style={defaultStyles.item}>
                <BoxedIcon
                  name="mail-outline"
                  backgroundColor={Colors.greenwa}
                />
                <Text style={{ fontSize: 18, flex: 1 }}>{userData.email}</Text>
              </View>

              <View style={defaultStyles.item}>
                <BoxedIcon
                  name="call-outline"
                  backgroundColor={Colors.greenwa}
                />
                <Text style={{ fontSize: 18, flex: 1 }}>
                  {userData.mobile_number}
                </Text>
              </View>

              <View style={defaultStyles.item}>
                <BoxedIcon
                  name="business-outline"
                  backgroundColor={Colors.greenwa}
                />
                <Text style={{ fontSize: 18, flex: 1 }}>
                  {userData.corporate_code}
                </Text>
              </View>
            </>
          )}
        </View>

        <TouchableOpacity
          onPress={() => navigation.navigate('Skills', { name: 'Skills' })}>
          <View style={defaultStyles.block}>
            {userData && (
              <>
                <View style={defaultStyles.item}>
                  <BoxedIcon
                    name="bulb-outline"
                    backgroundColor={Colors.greenwa}
                  />
                  <Text style={{ fontSize: 18, flex: 1 }}>
                    {userData.industry} - {userData.specialization}
                  </Text>

                  <Ionicons
                    name="chevron-forward-outline"
                    size={28}
                    color={Colors.black}
                  />
                </View>
              </>
            )}
          </View>
        </TouchableOpacity>

        {Object.keys(settingsPageLinksData).map((key) => (
          <View style={defaultStyles.block} key={key}>
            <FlatList
              data={settingsPageLinksData[key]}
              scrollEnabled={false}
              ItemSeparatorComponent={() => (
                <View style={defaultStyles.separator} />
              )}
              renderItem={({ item }) => (
                <TouchableOpacity onPress={() => handleSupportItemPress(item)}>
                  <View style={defaultStyles.item}>
                    <BoxedIcon
                      name={item.icon}
                      backgroundColor={item.backgroundColor}
                    />
                    <Text style={{ fontSize: 18, flex: 1 }}>{item.name}</Text>
                    <Ionicons
                      name="chevron-forward-outline"
                      size={28}
                      color={Colors.black}
                    />
                  </View>
                </TouchableOpacity>
              )}
            />
          </View>
        ))}

        <TouchableOpacity onPress={handleLogout}>
          <View style={defaultStyles.block}>
            <>
              <View style={defaultStyles.item}>
                <BoxedIcon
                  name="log-out-outline"
                  backgroundColor={Colors.red}
                />
                <Text style={{ fontSize: 18, flex: 1 }}>Log Out</Text>
                <Ionicons
                  name="chevron-forward-outline"
                  size={28}
                  color={Colors.black}
                />
              </View>
            </>
          </View>
        </TouchableOpacity>
      </ScrollView>
    </View>
  );
};


const SettingsScreen = () => {
  const { accessToken, removeToken } = useAuth();
  const navigation = useNavigation();
  const [userData, setUserData] = useState(null);
  const { setUsers } = useContext(UserContext);
  const [loading, setLoading] = useState(false);
  const [imageLoading, setImageLoading] = useState(true);

  const handleImageLoad = () => {
    setImageLoading(false);
  };


  const fetchUserData = async () => {
    try {
      const storedData = await AsyncStorage.getItem('userData');
      if (storedData) {
        const parsedData = JSON.parse(storedData);
        if (parsedData.detail && parsedData.detail === 'Invalid token') {
          // Handle invalid token case
        } else {
          if (parsedData.profile_image) {
            //const localImageUri = await downloadAndSaveImage(parsedData.profile_image);
            /*
            if (localImageUri) {
              parsedData.local_profile_image = localImageUri;
            }
            */
          }
          setUserData(parsedData);
          await AsyncStorage.setItem('userData', JSON.stringify(parsedData));
        }
      } else {
        // Handle case when no user data is stored
      }
    } catch (error) {
      console.error('Error fetching user data:', error);
    }
  };

  useEffect(() => {
    fetchUserData();
  }, [accessToken]);

  useFocusEffect(
    React.useCallback(() => {
      fetchUserData();
    }, [accessToken])
  );

  const downloadAndSaveImage = async (imageUrl) => {
    try {
      const fileName = imageUrl.split('/').pop();
      const fileUri = `${FileSystem.documentDirectory}${fileName}`;
      const downloadResult = await FileSystem.downloadAsync(imageUrl, fileUri);
      if (downloadResult.status === 200) {
        console.log('Image downloaded successfully');
        return fileUri;
      } else {
        console.log('Image download failed');
        return null;
      }
    } catch (error) {
      console.error('Error downloading image:', error);
      return null;
    }
  };

  const handleLogout = async () => {
    try {
      setUserData(null);
      setUsers([]);
      await AsyncStorage.removeItem('userData');
      await AsyncStorage.removeItem('users');
      removeToken();
      navigation.navigate('IntroPage');
    } catch (error) {
      console.error('Error logging out:', error);
    }
  };

  const handleSupportItemPress = (item) => {
    if (item.url) {
      Linking.openURL(item.url);
    }
  };

  const handleImagePickerDNU = async () => {
    setLoading(true);
    try {
      const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (status !== 'granted') {
        Alert.alert('Permission required', 'We need permission to access your media library.');
        return;
      }

      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        quality: 1,
      });

      if (!result.canceled) {
        const { uri } = result.assets[0];
        const formData = new FormData();
        formData.append('file', {
          uri,
          type: 'image/jpeg',
          name: 'profile-pic.jpg',
        });

        const uploadResponse = await fetch(`${Keys.apiURLDisa}/userpics/`, {
          method: 'POST',
          headers: {
            Accept: 'application/json',
            Authorization: `Bearer ${accessToken}`,
            'Content-Type': 'multipart/form-data',
          },
          body: formData,
        });

        const responseText = await uploadResponse.text();
        const result = JSON.parse(responseText);

        if (result.file_url) {
          const localImageUri = await downloadAndSaveImage(result.file_url);
          const updatedUserData = {
            ...userData,
            profile_image: result.file_url,
            local_profile_image: localImageUri,
          };
          setUserData(updatedUserData);
          await AsyncStorage.setItem('userData', JSON.stringify(updatedUserData));
        } else {
          Alert.alert('Upload failed', result.message || 'Something went wrong');
        }
      }
    } catch (error) {
      console.error('Error in image picker:', error);
      Alert.alert('Error', 'An error occurred while processing the image.');
    } finally {
      setLoading(false);
    }
  };


  const handleImagePicker = async () => {
    setLoading(true);
    try {
      let permissionResult;
      if (Platform.OS !== 'web') {
        permissionResult = await ImagePicker.requestMediaLibraryPermissionsAsync();
      }

      if (permissionResult && permissionResult.status !== 'granted') {
        Alert.alert('Permission required', 'We need permission to access your media library.');
        setLoading(false);
        return;
      }

      let result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsEditing: true,
        aspect: [4, 3],
        quality: 1,
      });

      if (!result.canceled && result.assets && result.assets.length > 0) {
        const { uri } = result.assets[0];
        const formData = new FormData();
        formData.append('file', {
          uri,
          type: 'image/jpeg',
          name: 'profile-pic.jpg',
        });

        const uploadResponse = await fetch(`${Keys.apiURLDisa}/userpics/`, {
          method: 'POST',
          headers: {
            Accept: 'application/json',
            Authorization: `Bearer ${accessToken}`,
            'Content-Type': 'multipart/form-data',
          },
          body: formData,
        });

        const responseText = await uploadResponse.text();
        const uploadResult = JSON.parse(responseText);

        if (uploadResult.file_url) {
          const localImageUri = await downloadAndSaveImage(uploadResult.file_url);
          const updatedUserData = {
            ...userData,
            profile_image: uploadResult.file_url,
            local_profile_image: localImageUri,
          };
          setUserData(updatedUserData);
          await AsyncStorage.setItem('userData', JSON.stringify(updatedUserData));
        } else {
          Alert.alert('Upload failed', uploadResult.message || 'Something went wrong');
        }
      }
    } catch (error) {
      console.error('Error in image picker:', error);
      Alert.alert('Error', 'An error occurred while processing the image.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={{ flex: 1, backgroundColor: Colors.background }}>
      <ScrollView
        contentInsetAdjustmentBehavior="automatic"
        contentContainerStyle={{ paddingBottom: 40 }}>
        <View style={styles.headline}>
          {userData && (
            <>
              <TouchableOpacity onPress={handleImagePicker}>
                {loading ? (
                  <ActivityIndicator size="large" color={Colors.greenwa} style={styles.avatar27} />
                ) : (
                  <>
                    <Image
                      source={userIcon}
                      style={[styles.avatar27, { position: 'absolute' }]}
                    />
                    <Image
                      source={{
                        uri: userData.local_profile_image || userData.profile_image,
                      }}
                      style={[styles.avatar27, { opacity: imageLoading ? 0 : 1 }]}
                      onLoad={handleImageLoad}
                    />
                  </>
                )}
              </TouchableOpacity>
              <Text style={styles.headlineName}>{userData.name}</Text>
            </>
          )}
        </View>

        <View style={defaultStyles.block}>
          {userData && (
            <>
              <View style={defaultStyles.item}>
                <BoxedIcon
                  name="mail-outline"
                  backgroundColor={Colors.greenwa}
                />
                <Text style={{ fontSize: 18, flex: 1 }}>{userData.email}</Text>
              </View>

              <View style={defaultStyles.item}>
                <BoxedIcon
                  name="call-outline"
                  backgroundColor={Colors.greenwa}
                />
                <Text style={{ fontSize: 18, flex: 1 }}>
                  {userData.mobile_number}
                </Text>
              </View>

              <View style={defaultStyles.item}>
                <BoxedIcon
                  name="business-outline"
                  backgroundColor={Colors.greenwa}
                />
                <Text style={{ fontSize: 18, flex: 1 }}>
                  {userData.corporate_code}
                </Text>
              </View>
            </>
          )}
        </View>

        <TouchableOpacity
          onPress={() => navigation.navigate('Skills', { name: 'Skills' })}>
          <View style={defaultStyles.block}>
            {userData && (
              <>
                <View style={defaultStyles.item}>
                  <BoxedIcon
                    name="bulb-outline"
                    backgroundColor={Colors.greenwa}
                  />
                  <Text style={{ fontSize: 18, flex: 1 }}>
                    {userData.industry} - {userData.specialization}
                  </Text>

                  <Ionicons
                    name="chevron-forward-outline"
                    size={28}
                    color={Colors.black}
                  />
                </View>
              </>
            )}
          </View>
        </TouchableOpacity>

        {Object.keys(settingsPageLinksData).map((key) => (
          <View style={defaultStyles.block} key={key}>
            <FlatList
              data={settingsPageLinksData[key]}
              scrollEnabled={false}
              ItemSeparatorComponent={() => (
                <View style={defaultStyles.separator} />
              )}
              renderItem={({ item }) => (
                <TouchableOpacity onPress={() => handleSupportItemPress(item)}>
                  <View style={defaultStyles.item}>
                    <BoxedIcon
                      name={item.icon}
                      backgroundColor={item.backgroundColor}
                    />
                    <Text style={{ fontSize: 18, flex: 1 }}>{item.name}</Text>
                    <Ionicons
                      name="chevron-forward-outline"
                      size={28}
                      color={Colors.black}
                    />
                  </View>
                </TouchableOpacity>
              )}
            />
          </View>
        ))}

        <TouchableOpacity onPress={handleLogout}>
          <View style={defaultStyles.block}>
            <>
              <View style={defaultStyles.item}>
                <BoxedIcon
                  name="log-out-outline"
                  backgroundColor={Colors.red}
                />
                <Text style={{ fontSize: 18, flex: 1 }}>Log Out</Text>
                <Ionicons
                  name="chevron-forward-outline"
                  size={28}
                  color={Colors.black}
                />
              </View>
            </>
          </View>
        </TouchableOpacity>
      </ScrollView>
    </View>
  );
};



function MoreScreen() {
  return (
    <ScrollView style={styles.container}>
      <Image source={{ uri: welcome_image }} style={styles.welcome} />
      <Text style={styles.headline}>About Disa</Text>

      <Text style={styles.headlineh2}>
        Revolutionizing Conversations{'\n'}with AI
      </Text>

      <Text style={styles.description}>
        Welcome to disa, where cutting-edge technology meets seamless
        interaction. Our platform leverages the power of advanced conversational
        AI, transforming the way you engage with your customers.
        {'\n'}
      </Text>

      <Text style={styles.headlineh2}>Our Mission</Text>

      <Text style={styles.description}>
        Our mission is to make intelligent conversations accessible to everyone.
        We aim to enhance user experiences by providing instant, accurate, and
        meaningful responses through our AI-powered platform.
        {'\n'}
      </Text>

      <Text style={styles.headlineh2}>What We Offer</Text>
      <Text style={styles.headlineh2}>Intelligent Assistance</Text>

      <Text style={styles.description}>
        Our app is built on OpenAI's ChatGPT, a state-of-the-art conversational
        AI model. Whether you need answers to questions, support with tasks, or
        just someone to talk to, our AI is here to help, 24/7.
        {'\n'}
      </Text>

      <Text style={styles.headlineh2}>User-Friendly Interface</Text>

      <Text style={styles.description}>
        We prioritize simplicity and ease of use. Our intuitive design ensures
        that you can interact with our AI smoothly, making your experience as
        effortless as possible.
        {'\n'}
      </Text>

      <Text style={styles.headlineh2}>Secure and Private</Text>

      <Text style={styles.description}>
        We understand the importance of privacy and security. All interactions
        are encrypted and securely stored, ensuring that your data is protected
        at all times.
        {'\n'}
      </Text>

      <Text style={styles.headlineh2}>Key Features</Text>

      <Text style={styles.description}>
        → Instant Responses: Get immediate answers to your assessments, no
        matter the time of day. {'\n'} {'\n'}→ Skills: Our Skills help you get
        the inference you need from your conversations. {'\n'} {'\n'}→
        Multi-Platform Access: Use disa on your favorite devices, whether it's
        your smartphone or tablet. {'\n'} {'\n'}→ Continuous Improvement: We are
        committed to regularly updating and enhancing our AI capabilities to
        serve you better. {'\n'}
        {'\n'}
      </Text>

      <Text style={styles.headlineh2}>Our Vision</Text>

      <Text style={styles.description}>
        We envision a future where AI-driven conversations are an integral part
        of daily life, enhancing communication and making information more
        accessible. By bridging the gap between human intelligence and
        artificial intelligence, we strive to create a world where technology
        empowers and enriches human interactions.
        {'\n'}
      </Text>

      <Text style={styles.headlineh2}>Join Us</Text>

      <Text style={styles.description}>
        Experience the future of communication with disa. Join our growing
        community and discover how intelligent conversations can make your life
        easier and more connected.
        {'\n'} {'\n'}
      </Text>

      <Text style={styles.description}>
        Version 2024.09.09 {'\n'} {'\n'}
      </Text>
    </ScrollView>
  );
}

const Tab = createBottomTabNavigator();

export default function App() {
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        tabBarIcon: ({ focused, color, size }) => {
          let iconName;

          if (route.name === 'Chats') {
            iconName = focused ? 'chatbubbles' : 'chatbubbles-outline';
          } else if (route.name === 'Updates') {
            iconName = focused ? 'disc' : 'disc-outline';
          } else if (route.name === 'Settings') {
            iconName = focused ? 'settings' : 'settings-outline';
          } else if (route.name === 'More') {
            iconName = focused
              ? 'information-circle'
              : 'information-circle-outline';
          }

          // You can return any component that you like here!
          return <Ionicons name={iconName} size={size} color={color} />;
        },
        tabBarActiveTintColor: Colors.greenwa,
        tabBarInactiveTintColor: 'gray',
      })}>
      <Tab.Screen
        name="Chats"
        component={HomeScreen}
        options={
          {
            // headerShown: false
          }
        }
      />

      <Tab.Screen name="Updates" component={UpdateScreen} />
      <Tab.Screen
        name="Settings"
        component={SettingsScreen}
        //options={{
        //  tabBarBadge: 3,
        //  tabBarBadgeStyle: { backgroundColor: "green", color: "white" },
        //}}
      />
      <Tab.Screen name="More" component={MoreScreen} />
    </Tab.Navigator>
  );
}
