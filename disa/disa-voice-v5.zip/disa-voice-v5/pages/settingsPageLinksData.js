import Keys from '../constants/Keys';
import Colors from '../constants/Colors';

const settingsPageLinksData = {
  support: [
    {
      name: 'Terms and Conditions',
      icon: 'document-text-outline',
      backgroundColor: Colors.greenwa,
      url: Keys.urlDisaTerm, // Add URL here
    },
    {
      name: 'Privacy Policy',
      icon: 'document-text-outline',
      backgroundColor: Colors.greenwa,
      url: Keys.urlDisaPolicy, // Add URL here
    },
  ],
};

export default settingsPageLinksData;
