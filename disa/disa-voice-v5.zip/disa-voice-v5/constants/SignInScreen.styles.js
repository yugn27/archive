import { StyleSheet } from 'react-native';
import Colors from './Colors';

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    padding: 20,
    backgroundColor: Colors.background,
    gap: 20,
  },
  description: {
    fontSize: 14,
    color: Colors.gray,
  },
  legal: {
    fontSize: 12,
    textAlign: 'center',
    color: '#000',
  },
  link: {
    color: Colors.primary,
  },
  button: {
    width: '100%',
    alignItems: 'center',
    backgroundColor: Colors.greenwa,
    padding: 10,
    borderRadius: 10,
  },
  buttonText: {
    color: Colors.white,
    fontSize: 22,
    fontWeight: '500',
  },
  list: {
    backgroundColor: '#fff',
    width: '100%',
    borderRadius: 10,
    padding: 10,
    gap: 10,
  },
  input: {
    backgroundColor: '#f2f2f2',
    width: '100%',
    fontSize: 16,
    padding: 10,
    borderRadius: 5,
  },

  imageUploadButton: {
    backgroundColor: Colors.lightGray,
    padding: 10,
    borderRadius: 5,
    alignItems: 'center',
    marginTop: 10,
  },
  imageUploadButtonText: {
    color: Colors.black,
    fontSize: 16,
  },
  previewImage: {
    width: 140,
    height: 140,
    resizeMode: 'cover',
    alignSelf: 'center',
    marginTop: 10,
    borderRadius: 100,
  },
});

export default styles;
