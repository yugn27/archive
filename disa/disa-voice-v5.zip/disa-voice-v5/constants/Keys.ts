export default {
  apiURLDisa: 'https://mtrytz6yai.execute-api.eu-north-1.amazonaws.com',
  apiURLDisaStatic: 'https://disa.dizio.in/api',
  urlDisaHome: 'https://disa.dizio.in/',
  urlDisaTerm: 'https://disa.dizio.in/terms-of-service.html',
  urlDisaPolicy: 'https://disa.dizio.in/policy.html',
  apiURLOpenai: 'https://api.openai.com/v1/chat/completions',
  apiKeyOpenai: 'sk-proj-pCOjwdIyMzLooNQbiDBET3BlbkFJJJGRGLVK8OXeesNH0l6n',
};

//development
//https://0d166283-8faa-41a7-af82-e982942cb8bf-00-2palpso27k2uo.pike.replit.dev/

//production
//https://mtrytz6yai.execute-api.eu-north-1.amazonaws.com
//https://fhzjvjrhkf.execute-api.eu-north-1.amazonaws.com
