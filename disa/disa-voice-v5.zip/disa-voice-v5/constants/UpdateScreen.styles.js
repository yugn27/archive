// HomeScreen.styles.js
import { StyleSheet } from 'react-native';
import Colors from '../constants/Colors';

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
    paddingHorizontal: 12,
  },
  newsItem: {
    backgroundColor: Colors.lightGreen, // Light background color for the card
    borderRadius: 16, // Rounded corners for the card
    padding: 6,
    marginVertical: 8,
    alignItems: 'center',
    //shadowColor: '#000', // Shadow for a subtle elevation effect
    //shadowOffset: { width: 0, height: 2 },
    //shadowOpacity: 0.1,
    //shadowRadius: 8,
    //elevation: 5,
  },
  newsImage: {
    width: '100%',
    height: 150,
    borderRadius: 12, // Rounded corners for the image
    marginBottom: 12,
  },
  newsTextContainer: {},
  newsTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: Colors.textPrimary,
    marginBottom: 8,
  },
  newsSummary: {
    fontSize: 14,
    color: Colors.textSecondary,
    marginBottom: 8,
  },
  newsDate: {
    fontSize: 12,
    color: Colors.textTertiary,
    textAlign: 'right',
    paddingRight: 5,
  },
});

export default styles;
