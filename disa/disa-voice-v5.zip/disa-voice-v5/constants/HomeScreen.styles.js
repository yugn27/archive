import { StyleSheet } from 'react-native';
import Colors from './Colors';

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
   list: {
    backgroundColor: '#fff',
    width: '100%',
    borderRadius: 10,
    padding: 10,
    gap: 10,
  },
  userList: {
    padding: 10,
  },
  userRow: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 10,
    borderBottomWidth: 1,
    borderBottomColor: Colors.lightGray,
  },
  avatar: {
    width: 50,
    height: 50,
    borderRadius: 25,
  },
  userInfo: {
    flex: 1,
    marginLeft: 10,
  },
  userName: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  lastMessage: {
    fontSize: 14,
    color: Colors.gray,
  },
  timestamp: {
    fontSize: 12,
    color: Colors.gray,
  },

  //news
  container: {
    flex: 1,
    backgroundColor: '#FFF',
  },
  newsItem: {
    flexDirection: 'row',
    padding: 10,
    borderBottomWidth: 1,
    borderBottomColor: Colors.lightGray,
  },
  newsImage: {
    width: '35%',
    height: '100%',
    borderRadius: 15,
    marginRight: 10,
  },
  newsTextContainer: {
    flex: 1,
  },
  newsTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 5,
  },
  newsSummary: {
    fontSize: 14,
    color: Colors.gray,
  },
  newsDate: {
    fontSize: 12,
    color: Colors.lightGray,
    marginTop: 5,
  },
  logoutText: {
    color: Colors.primary,
    fontSize: 18,
    textAlign: 'center',
    paddingVertical: 14,
  },
  welcome: {
    width: '100%',
    height: 300,
    borderRadius: 60,
    marginBottom: 80,
  },
  headline: {
    fontSize: 24,
    fontWeight: 'bold',
    marginVertical: 20,
    textAlign: 'center',
  },

  headlineh2: {
    fontSize: 20,
    fontWeight: 'bold',
    marginVertical: 10,
    textAlign: 'center',

    //textAlign: "center",
    //marginBottom: 80,

    paddingHorizontal: 10,
  },



headlinehyun: {
    fontSize: 16,
    fontWeight: 'bold',
    
    

    //textAlign: "center",
    //marginBottom: 80,

    
  },
  headlineName: {
    fontSize: 24,
    fontWeight: 'bold',
    //marginVertical: 20,
    textAlign: 'center',
  },

  headlineName22: {
    fontSize: 24,
    fontWeight: 'bold',
    marginTop: 20,
    textAlign: 'center',
  },

  headlineemail: {
    fontSize: 16,
    fontWeight: 'bold',
    //marginVertical: 0,
    textAlign: 'center',
  },
  description: {
    fontSize: 14,
    textAlign: 'center',
    //marginBottom: 80,
    color: Colors.gray,
    paddingHorizontal: 10,
  },
  accessToken: {
    fontSize: 18,
    marginBottom: 10,
  },

  avatar27: {
    width: 150, // Set the desired width of the image
    height: 150, // Set the desired height of the image
    borderRadius: 100, // Set the border radius for a circular image (optional)
    //flex: 1,
    //justifyContent: 'center',
    //alignItems: 'center',
    //textAlign: "center",
    paddingVertical: 10,
  },

  toggleContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginVertical: 10,
  },
  toggleButton: {
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderWidth: 1,
    borderColor: Colors.greenwa,
  },
  activeToggle: {
    backgroundColor: Colors.greenwa,
  },
  toggleText: {
    color: Colors.primary,
  },
  archiveButton: {
    padding: 10,
  },
});

export default styles;
