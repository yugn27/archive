import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import Colors from './constants/Colors';
import { Avatar, Header } from 'react-native-elements';
import { View, Text, Image, StyleSheet, TouchableOpacity, ScrollView, FlatList } from 'react-native';
import Ionicons from 'react-native-vector-icons/Ionicons';
//pages
import IntroPage from './pages/IntroPage';
import SignUp from './pages/SignUp';
import SignIn from './pages/SignIn';
import Home from './pages/Home';
import Chat from './pages/Chat';


const Stack = createStackNavigator();

function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="IntroPage">
        <Stack.Screen name="IntroPage" component={IntroPage}  options={{ headerShown: false }} />
       
        <Stack.Screen
          name="SignUp"
          component={SignUp}
          options={{ headerTitle: 'Create a New Account', headerLeft: null, headerStyle: { backgroundColor: Colors.greenwa, }, headerTitleStyle: { color: 'white' ,  }}} 
        />



        <Stack.Screen
          name="SignIn"
          component={SignIn}
          options={{ headerTitle: 'Welcome to Disa', headerLeft: null, headerStyle: { backgroundColor: Colors.greenwa, }, headerTitleStyle: { color: 'white'  }}} 
        />



 <Stack.Screen
          name="Home"
          component={Home}
          options={{ headerTitle: 'Welcome to Disa', headerShown: false, headerStyle: { backgroundColor: Colors.greenwa, }, headerTitleStyle: { color: 'white'  }}} 
        />





         <Stack.Screen
          name="Chat"
          component={Chat}
          options={{
            header: (props) => (
              <Header
                containerStyle={{ backgroundColor: Colors.greenwa }}
                leftComponent={
                  <TouchableOpacity onPress={() => props.navigation.goBack()} style={{ paddingLeft: 10 }}>
                    <Ionicons name="arrow-back-outline" size={28} color={Colors.white} />
                  </TouchableOpacity>
                }
                centerComponent={
                  <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                    <Avatar
                      source={{
                        uri: 'https://i.ibb.co/3TcBTH2/download.jpg',
                      }}
                      size={28}
                      rounded
                    />
                    <Text style={{ color: Colors.white, marginLeft: 10, fontSize: 16, fontWeight: '500' }}>Priya Singh (2239)</Text>
                  </View>
                }
                rightComponent={
                  <View style={{ flexDirection: 'row', gap: 14 }}>
                    <TouchableOpacity>
                      <Ionicons name="medical-outline" color={Colors.white} size={24} />
                    </TouchableOpacity>
                  </View>
                }
              />
            ),
          }}
        />



      </Stack.Navigator>
    </NavigationContainer>
  );
}

export default App;


