import React, { useEffect, useState } from 'react';


import Colors from '../constants/Colors';
import Ionicons from 'react-native-vector-icons/Ionicons';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView, FlatList, TextInput } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { Avatar, Header } from 'react-native-elements';

const messages = [
  { id: 1, text: 'Gen > Ortho | Done |12 Jun 23 Patient Tripped and Fell Down. Pain in the Right heel Pain in the Left Hand Root Cause: When the patient fell down, his left hand had a sprain Recommendation:', sent: false },
  { id: 2, text: 'It is really painful when I try to run. If I am walking it is a little less painful. Yes. Right leg, near the heel. Did you hurt yourself? Yes. I fell down tripping off a stone and tried to save myself. My hand is also paining.', sent: true },
  // Add more messages as needed
];

function HomeScreen() {
  const navigation = useNavigation();

  useEffect(() => {
    navigation.setOptions({
      headerRight: () => (
        <TouchableOpacity onPress={() => console.log('New chat')} style={{ paddingRight: 10 }}>
          <Ionicons name="add-circle-outline" size={28} color={Colors.greenwa} />
        </TouchableOpacity>
      ),
      headerLeft: () => (
        <TouchableOpacity onPress={() => navigation.goBack()} style={{ paddingLeft: 10 }}>
          <Ionicons name="arrow-back-outline" size={28} color={Colors.greenwa} />
        </TouchableOpacity>
      ),
    });
  }, [navigation]);

  const [message, setMessage] = useState('');

  const handleSend = () => {
    // Handle sending the message
    console.log(message);
    setMessage('');
  };

const [rating, setRating] = useState(0);  // State to hold the current rating

    // Function to render stars for rating
    const renderStars = () => {
        let stars = [];
        for (let i = 1; i <= 5; i++) {
            stars.push(
                <TouchableOpacity key={i} onPress={() => setRating(i)} style={styles.star}>
                    <Ionicons
                        name={i <= rating ? 'star' : 'star-outline'}
                        size={24}
                        color={i <= rating ? Colors.gold : Colors.gray}
                    />
                </TouchableOpacity>
            );
        }
        return stars;
    };


  return (
    <View style={styles.container}>
    
      {/* Chat Bubble */}
      <ScrollView
        style={styles.chatBubbleContainer}
        contentContainerStyle={{ paddingBottom: 20 }}
      >

        {/* Encryption Message */}
      <TouchableOpacity style={styles.encryptionMessageContainer} onPress={() => console.log('Learn more')}>
        <View style={styles.encryptionMessageInner}>
          <Ionicons name="ban-outline" size={16} color={Colors.greenwa} style={styles.encryptionIcon} />
          <Text style={styles.encryptionMessage}>
            Advisory services are disabled.
          </Text>
        </View>
      </TouchableOpacity>


       {/* Transcript Message */}
      <TouchableOpacity style={styles.transcriptMessageContainer} onPress={() => console.log('Learn more')}>
        <View style={styles.encryptionMessageInner}>
          <Ionicons name="document-text-outline" size={16} color={Colors.greenwa} style={styles.encryptionIcon} />
          <Text style={styles.encryptionMessage}>
            Your Transcript
          </Text>
        </View>
      </TouchableOpacity>
      

        <FlatList
          data={messages}
          renderItem={({ item }) => (
            <View style={[styles.bubble, item.sent ? styles.sent : styles.received]}>
              <Text style={styles.bubbleTextName}>{item.sent ? 'Discussion Transcript' : 'Summary'}</Text>
              <Text style={styles.bubbleText}>{item.text}</Text>
            </View>
          )}
          keyExtractor={(item) => item.id.toString()}
          inverted
        />


  {/* Encryption Message */}
   

       <TouchableOpacity style={styles.feedbackMessageContainer} onPress={() => console.log('Learn more')}>
            <View style={styles.encryptionMessageInner}>
                <Ionicons name="podium-outline" size={16} color={Colors.greenwa} style={styles.encryptionIcon} />
                <Text style={styles.encryptionMessage}>Feedback</Text>
                <View style={styles.starContainer}>
                    {renderStars()}
                </View>
            </View>
        </TouchableOpacity>
       
      </ScrollView>

      {/* Input Toolbar */}
      <View style={styles.inputToolbar}>
        <TouchableOpacity>
          <Ionicons name="add" color={Colors.greenwa} size={28} />
        </TouchableOpacity>
        <View style={styles.inputContainer}>
  <TextInput
    style={styles.input}
    placeholder="Type a message..."
    placeholderTextColor={Colors.gray}
    value={message}
    onChangeText={setMessage}
  />
</View>
        <View style={styles.sendActions}>
          <TouchableOpacity>
            <Ionicons name="mic-outline" color={Colors.greenwa} size={28} />
          </TouchableOpacity>
          <TouchableOpacity>
            <Ionicons name="arrow-redo-circle-outline" color={Colors.greenwa} size={28} />
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 10,
    backgroundColor: '#fff',
    borderRadius: 5,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.22,
    shadowRadius: 2.22,
    elevation: 3,
    margin: 10,
  },
  messageContainer: {
    marginBottom: 10,
  },
  message: {
    fontSize: 14,
    color: 'black',
  },
  actionsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  buttonGreen: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 5,
    backgroundColor: Colors.greenwa,
    borderRadius: 5,
    marginHorizontal: 5,
  },
  buttonRed: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 5,
    backgroundColor: Colors.red,
    borderRadius: 5,
    marginHorizontal: 5,
  },
   button: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 5,
    backgroundColor: '#E1E1E1',
    borderRadius: 5,
    marginHorizontal: 5,
  },
  buttonText: {
    marginLeft: 5,
    fontSize: 14,
    color: 'black',
  },
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  chatBubbleContainer: {
    flex: 1,
    padding: 10,
  },
  bubble: {
    maxWidth: '80%',
    padding: 10,
    borderRadius: 10,
    marginVertical: 5,
  },
  received: {
    backgroundColor: '#fff',
    alignSelf: 'flex-start',
    marginLeft: 10,
  },
  sent: {
    backgroundColor: Colors.lightGreen,
    alignSelf: 'flex-end',
    marginRight: 10,
  },
  bubbleText: {
    fontSize: 16,
  },
  inputToolbar: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 10,
    paddingBottom: '8%',
    backgroundColor: '#ffffff',
  },
  inputContainer: {
    flex: 1,
    backgroundColor: '#fff',
    borderRadius: 18,
    borderWidth: 1,
    borderColor: Colors.lightGray,
    paddingHorizontal: 10,
    paddingVertical: 8,
    marginHorizontal: 10,
  },
  placeholder: {
    color: Colors.gray,
  },
  sendActions: {
    flexDirection: 'row',
    gap: 14,
  },
  encryptionMessageContainer: {
    backgroundColor: '#ffeecd',
    borderRadius: 8,
    padding: 8,
    marginVertical: 8,
    marginHorizontal: '10%',
  },
  feedbackMessageContainer: {
    backgroundColor: '#ffffff',
    borderRadius: 8,
    padding: 8,
    marginVertical: 8,
    marginHorizontal: '10%',
  },
   transcriptMessageContainer: {
    backgroundColor: '#ffffff',
    borderRadius: 8,
    padding: 8,
    marginVertical: 8,
    marginHorizontal: '25%',
  },
  encryptionMessageInner: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  encryptionIcon: {
    marginRight: 8,
  },
  encryptionMessage: {
    fontSize: 14,
    color: '#54656f',
    flex: 1,
  },
  bubbleTextName: {
    fontSize: 12,
    fontWeight: 'bold',
    marginBottom: 4,
    color: Colors.greenwa,
  },
  

  
   
   
    starContainer: {
        flexDirection: 'row',
    },
    star: {
        marginHorizontal: 2,
    },
  
  
});

export default HomeScreen;