import React, { useEffect } from "react";
import Colors from "../constants/Colors";
import { defaultStyles } from "../constants/Styles";
import BoxedIcon from "../components/BoxedIcon";
import Ionicons from "react-native-vector-icons/Ionicons";
import {
  View,
  Text,
  Image,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  FlatList,
} from "react-native";
import { createStackNavigator } from "@react-navigation/stack";

const Stack = createStackNavigator();



import welcomeImage from "../assets/images/welcome.png";
const welcome_image = Image.resolveAssetSource(welcomeImage).uri;



import { SearchBar } from "@rneui/themed";

import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import {  useNavigation } from "@react-navigation/native";
//
// Static user data
const users = [
  {
    id: 1,
    name: "A Murugan",
    avatar: "https://i.ibb.co/3TcBTH2/download.jpg",
    lastMessage: "Gen > Ortho",
    timestamp: "10:30 AM",
  },
  {
    id: 2,
    name: "Priya Singh (2239)",
    avatar: "https://i.ibb.co/3TcBTH2/download.jpg",
    lastMessage: "Gen > Gyneic",
    timestamp: "9:45 AM",
  },
  {
    id: 3,
    name: "Avnish Shetty",
    avatar: "https://i.ibb.co/3TcBTH2/download.jpg",
    lastMessage: "Ganeswara Hari",
    timestamp: "8:15 AM",
  },
  // Add more users as needed
];

function HomeScreen() {
  const navigation = useNavigation();

  useEffect(() => {
    navigation.setOptions({
      headerRight: () => (
        <TouchableOpacity
          onPress={() => console.log("New chat")}
          style={{ paddingRight: 10 }}
        >
          <Ionicons
            name="add-circle-outline"
            size={28}
            color={Colors.greenwa}
          />
        </TouchableOpacity>
      ),
    });
  }, [navigation]);

  state = {
    search: "",
  };

  updateSearch = (search) => {
    this.setState({ search });
  };

  const { search } = this.state;
  return (
    <View style={styles.container}>
      <SearchBar
        platform="ios"
        containerStyle={{ height: 50 }} // Decrease the height of the search bar container
        inputContainerStyle={{ height: 35, backgroundColor: Colors.searchHome }}
        inputStyle={{}}
        leftIconContainerStyle={{}}
        rightIconContainerStyle={{}}
        loadingProps={{}}
        onChangeText={(newVal) => setValue(newVal)}
        onClearText={() => console.log("Clear text")}
        placeholder="Search"
        placeholderTextColor="#888"
        round
        value={search}
        showCancel
        cancelButtonTitle="Cancel"
        cancelButtonProps={{}}
        onCancel={() => console.log("Cancel search")}
        searchIcon={
          <Ionicons name="search-outline" size={20} color={Colors.primary} />
        } // Correctly use search icon
      />

      <Stack.Screen
        name="index"
        options={{
          title: "Settings",
          headerLargeTitle: true,
          headerShadowVisible: false,
          headerStyle: { backgroundColor: Colors.background },

          headerSearchBarOptions: {
            placeholder: "Search",
          },
          headerRight: () => <Text style={styles.userName}>yash</Text>,
        }}
      />






      {/* User List */}


      {/* User List */}
<ScrollView contentContainerStyle={styles.userList}>
  {users.map((user) => (
    <TouchableOpacity
      key={user.id}
      style={styles.userRow}
      onPress={() => navigation.navigate('Chat', { userId: user.id })}
    >
      <Image source={{ uri: user.avatar }} style={styles.avatar} />
      <View style={styles.userInfo}>
        <Text style={styles.userName}>{user.name}</Text>
        <Text style={styles.lastMessage}>{user.lastMessage}</Text>
      </View>
      <Text style={styles.timestamp}>{user.timestamp}</Text>
    </TouchableOpacity>
  ))}
</ScrollView>



     
    </View>
  );
}

// Example static data
const newsData = [
  {
    id: "1",
    title: "Latest COVID-19 Vaccine Updates Approaches",
    summary:
      "A look at innovative treatment strategies for heart disease, featuring insights from leading cardiologists.",
    date: "2024-05-10",
    imageUrl: "https://etimg.etb2bimg.com/photo/110024360.cms",
  },
  {
    id: "2",
    title: "Heart Disease: New Treatment Approaches",
    summary:
      "A look at innovative treatment strategies for heart disease, featuring insights from leading cardiologists.",
    date: "2024-05-09",
    imageUrl: "https://etimg.etb2bimg.com/photo/110024360.cms",
  },
  {
    id: "3",
    title: "Advances in Neurological Disorders",
    summary:
      "Recent breakthroughs in the treatment of neurological disorders, including Alzheimer's and Parkinson's disease.",
    date: "2024-05-08",
    imageUrl: "https://etimg.etb2bimg.com/photo/110024360.cms",
  },
  // Add more news items as needed
];

const NewsItem = ({ item }) => (
  <TouchableOpacity style={styles.newsItem}>
    <Image source={{ uri: item.imageUrl }} style={styles.newsImage} />
    <View style={styles.newsTextContainer}>
      <Text style={styles.newsTitle}>{item.title}</Text>
      <Text style={styles.newsSummary}>{item.summary}</Text>
      <Text style={styles.newsDate}>{item.date}</Text>
    </View>
  </TouchableOpacity>
);

function UpdateScreen() {
  return (
    <View style={styles.container}>
      <FlatList
        data={newsData}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => <NewsItem item={item} />}
      />
    </View>
  );
}

const settingsPageData = {
  devices: [
    {
      name: "Industry",
      icon: "golf-outline",
      backgroundColor: Colors.green,
    },
    {
      name: "Function",
      icon: "funnel-outline",
      backgroundColor: Colors.yellow,
    },
  ],
  items: [
    {
      name: "Languages",
      icon: "language-outline",
      backgroundColor: Colors.primary,
    },
    {
      name: "Clear All Chats",
      icon: "trash-outline",
      backgroundColor: "#33A5D1",
    },
    {
      name: "Delete Account",
      icon: "trash-outline",
      backgroundColor: Colors.green,
    },
    {
      name: "Notifications",
      icon: "notifications",
      backgroundColor: Colors.red,
    },
  ],
  support: [
    {
      name: "Help",
      icon: "information",
      backgroundColor: Colors.primary,
    },
    {
      name: "Tell a Friend",
      icon: "heart",
      backgroundColor: Colors.red,
    },
  ],
};

function SettingsScreen() {
  return (
    <View style={{ flex: 1, backgroundColor: Colors.background }}>
      <ScrollView
        contentInsetAdjustmentBehavior="automatic"
        contentContainerStyle={{ paddingBottom: 40 }}
      >
        {Object.keys(settingsPageData).map((key) => (
          <View style={defaultStyles.block} key={key}>
            <FlatList
              data={settingsPageData[key]}
              scrollEnabled={false}
              ItemSeparatorComponent={() => (
                <View style={defaultStyles.separator} />
              )}
              renderItem={({ item }) => (
                <View style={defaultStyles.item}>
                  <BoxedIcon
                    name={item.icon}
                    backgroundColor={item.backgroundColor}
                  />
                  <Text style={{ fontSize: 18, flex: 1 }}>{item.name}</Text>
                  <Ionicons
                    name="chevron-forward"
                    size={20}
                    color={Colors.gray}
                  />
                </View>
              )}
            />
          </View>
        ))}

        <TouchableOpacity onPress={() => console.log("Log Out")}>
          <Text style={styles.logoutText}>Log Out</Text>
        </TouchableOpacity>
      </ScrollView>
    </View>
  );
}

function MoreScreen() {
  const openLink = () => {
    Linking.openURL("https://example.com");
  };

  return (
    <View style={styles.container}>
      <Image source={{ uri: welcome_image }} style={styles.welcome} />
      <Text style={styles.headline}>About Disa</Text>
      <Text style={styles.description}>
        Discover the power of understanding your data with Disa App, your go-to AI tool that makes sense of complex information easily and quickly. {"\n"}
      </Text>

     
       <Text style={styles.description}>Version 2024.05.06 {"\n"}</Text>
        <Text style={styles.description}>ⓒ 2024 Disa </Text>
    </View>
  );
}

function BaMoreScreen() {
  return (
    <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}>
      <Text>Settings!</Text>
    </View>
  );
}

const Tab = createBottomTabNavigator();

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  userList: {
    padding: 10,
  },
  userRow: {
    flexDirection: "row",
    alignItems: "center",
    padding: 10,
    borderBottomWidth: 1,
    borderBottomColor: Colors.lightGray,
  },
  avatar: {
    width: 50,
    height: 50,
    borderRadius: 25,
  },
  userInfo: {
    flex: 1,
    marginLeft: 10,
  },
  userName: {
    fontSize: 16,
    fontWeight: "bold",
  },
  lastMessage: {
    fontSize: 14,
    color: Colors.gray,
  },
  timestamp: {
    fontSize: 12,
    color: Colors.gray,
  },

  //news
  container: {
    flex: 1,
    backgroundColor: "#FFF",
  },
  newsItem: {
    flexDirection: "row",
    padding: 10,
    borderBottomWidth: 1,
    borderBottomColor: Colors.lightGray,
  },
  newsImage: {
    width: "35%",
    height: "100%",
    borderRadius: 15,
    marginRight: 10,
  },
  newsTextContainer: {
    flex: 1,
  },
  newsTitle: {
    fontSize: 18,
    fontWeight: "bold",
    marginBottom: 5,
  },
  newsSummary: {
    fontSize: 14,
    color: Colors.gray,
  },
  newsDate: {
    fontSize: 12,
    color: Colors.lightGray,
    marginTop: 5,
  },
  logoutText: {
    color: Colors.primary,
    fontSize: 18,
    textAlign: "center",
    paddingVertical: 14,
  },
  welcome: {
    width: "100%",
    height: 300,
    borderRadius: 60,
    marginBottom: 80,
  },
  headline: {
    fontSize: 24,
    fontWeight: "bold",
    marginVertical: 20,
    textAlign: "center",
  },
  description: {
    fontSize: 14,
    textAlign: "center",
    //marginBottom: 80,
    color: Colors.gray,
    paddingHorizontal: 10,
  },
  
});

export default function App() {
  return (
   // <NavigationContainer>
      <Tab.Navigator
        screenOptions={({ route }) => ({
          tabBarIcon: ({ focused, color, size }) => {
            let iconName;

            if (route.name === "Chats") {
              iconName = focused
                ? "chatbubbles-outline"
                : "chatbubbles-outline";
            } else if (route.name === "Updates") {
              iconName = focused ? "triangle-outline" : "triangle-outline";
            } else if (route.name === "Settings") {
              iconName = focused ? "settings-outline" : "settings-outline";
            } else if (route.name === "More") {
              iconName = focused
                ? "help-circle-outline"
                : "help-circle-outline";
            }

            // You can return any component that you like here!
            return <Ionicons name={iconName} size={size} color={color} />;
          },
          tabBarActiveTintColor: Colors.greenwa,
          tabBarInactiveTintColor: "gray",
        })}
      >
        <Tab.Screen
          name="Chats"
          component={HomeScreen}
          options={
            {
              // headerShown: false
            }
          }
        />

        <Tab.Screen name="Updates" component={UpdateScreen} />
        <Tab.Screen
          name="Settings"
          component={SettingsScreen}
          options={{ tabBarBadge: 3 }}
        />
        <Tab.Screen name="More" component={MoreScreen} />
      </Tab.Navigator>
   // </NavigationContainer>
  );
}
