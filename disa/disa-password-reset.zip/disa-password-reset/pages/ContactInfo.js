import { View, Text, StyleSheet, Image } from "react-native";
import Colors from "../constants/Colors";

import Dropdown from "./DropDown";

import groupIcon from "../assets/images/group-icon.png";
const group_icon = groupIcon;

const ContactInfo = ({ route }) => {
  // Destructure userName and chatId from route.params with default values
  const { userName, chatId } = route.params;

  return (
    <View style={styles.container}>
      <Text>{"\n"}</Text>
      <Image source={{ uri: group_icon }} style={styles.avatar} />

      <Text style={styles.headline}>{userName}</Text>

      <Text style={styles.text}>Task ID - {chatId}</Text>

      <Dropdown
        data={[
          { value: "Default", label: "Default" },
          { value: "Service", label: "Service" },
          { value: "Product", label: "Product" },
        ]}
        onChange={console.log}
        placeholder="Select Template"
      />

       <Dropdown
        data={[
          { value: "01", label: "Yash Nayak" },
          { value: "02", label: "Satyen C" },
          { value: "03", label: "Pooja M" },
        ]}
        onChange={console.log}
        placeholder="Add Members"
      />


    </View>
  );
};

const styles = StyleSheet.create({
  /* container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: Colors.white,
  },
*/
  container: {
    flex: 1,
    backgroundColor: Colors.background,
    alignItems: "center",
    //justifyContent: "center",
    paddingHorizontal: 20,
    gap: 10,
  },
  avatar: {
    width: 150,
    height: 150,
    borderRadius: 75,
  },
  text: {
    fontSize: 18,
    color: Colors.black,
    marginBottom: 10,
  },
  optionContainer: {
    flexDirection: "row",
    alignItems: "center",
    marginVertical: 10,
  },
  optionLabel: {
    fontSize: 18,
    marginRight: 10,
    color: Colors.black,
  },
  picker: {
    width: 150,
    height: 40,
  },
  description: {
    fontSize: 14,
    color: Colors.gray,
    textAlign: "center",
  },
  welcome: {
    width: "100%",
    height: 300,
    borderRadius: 90,
    marginBottom: 80,
  },
  headline: {
    fontSize: 24,
    fontWeight: "bold",
    marginBottom: 10,
    color: Colors.black,
  },
});

export default ContactInfo;
