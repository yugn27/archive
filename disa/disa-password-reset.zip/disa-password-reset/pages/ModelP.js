import React, { useEffect, useState } from "react";
import { View, Text, TextInput, Button, Modal, TouchableOpacity, ActivityIndicator, ScrollView } from "react-native";
import Ionicons from "react-native-vector-icons/Ionicons";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { useNavigation } from "@react-navigation/native";
import { useAuth } from "../AuthContext";
import styles from "../constants/HomeScreen.styles";
import Colors from "../constants/Colors";

const ModelPScreen = () => {
  const navigation = useNavigation();
  const { accessToken } = useAuth();
  const { removeToken } = useAuth();

  const [isModalVisible, setModalVisible] = useState(false);
  const [newTemplate, setNewTemplate] = useState({
    industry: "",
    specialization: "",
    template_text: ""
  });
  const [selectedTemplate, setSelectedTemplate] = useState(null);
  const [loading, setLoading] = useState(false);

  const createTemplate = () => {
    setLoading(true);
    fetch('https://your-api-url.com/templates', {
      method: 'POST',
      headers: {
        Accept: 'application/json',
        'Content-Type': 'application/json',
        Authorization: `Bearer ${accessToken}`,
      },
      body: JSON.stringify(newTemplate),
    })
    .then(response => response.json())
    .then(data => {
      // Handle response data
      setNewTemplate({ industry: "", specialization: "", template_text: "" });
      setModalVisible(false);
    })
    .catch(error => console.error("Error creating template:", error))
    .finally(() => setLoading(false));
  };

  const updateTemplate = () => {
    setLoading(true);
    fetch(`https://your-api-url.com/templates/${selectedTemplate.id}`, {
      method: 'PUT',
      headers: {
        Accept: 'application/json',
        'Content-Type': 'application/json',
        Authorization: `Bearer ${accessToken}`,
      },
      body: JSON.stringify(selectedTemplate),
    })
    .then(response => response.json())
    .then(updatedTemplate => {
      // Handle updated template
      setSelectedTemplate(null);
    })
    .catch(error => console.error("Error updating template:", error))
    .finally(() => setLoading(false));
  };

  const handleModalClose = () => {
    setNewTemplate({ industry: "", specialization: "", template_text: "" });
    setSelectedTemplate(null);
    setModalVisible(false);
  };

  return (
    <View style={styles.container}>
      <TouchableOpacity onPress={() => setModalVisible(true)}>
        <Ionicons name="add-circle" size={28} color={Colors.greenwa} />
      </TouchableOpacity>

      <Modal
        visible={isModalVisible}
        animationType="slide"
        onRequestClose={handleModalClose}
      >
        <View style={{ padding: 20 }}>
          <TextInput
            placeholder="Industry"
            value={newTemplate.industry}
            onChangeText={(text) => setNewTemplate({ ...newTemplate, industry: text })}
            style={{ borderBottomWidth: 1, marginBottom: 10 }}
          />
          <TextInput
            placeholder="Specialization"
            value={newTemplate.specialization}
            onChangeText={(text) => setNewTemplate({ ...newTemplate, specialization: text })}
            style={{ borderBottomWidth: 1, marginBottom: 10 }}
          />
          <TextInput
            placeholder="Template Text"
            value={newTemplate.template_text}
            onChangeText={(text) => setNewTemplate({ ...newTemplate, template_text: text })}
            style={{ borderBottomWidth: 1, marginBottom: 10 }}
          />
          <Button title="Create Template" onPress={createTemplate} />
          <Button title="Close" onPress={handleModalClose} />
        </View>
      </Modal>
    </View>
  );
};

export default ModelPScreen;
