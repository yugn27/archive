import { useEffect, useState } from "react";
import Colors from "../constants/Colors";
import { defaultStyles } from "../constants/Styles";
import BoxedIcon from "../components/BoxedIcon";
import Keys from "../constants/Keys";
//import AsyncStorage from "@react-native-async-storage/async-storage";
import AsyncStorage from "@react-native-async-storage/async-storage";
import {
  Image,
  Text,
  TouchableOpacity,
  View,
  ScrollView,
  FlatList,
  ActivityIndicator,
  Modal,
} from "react-native";
import { createStackNavigator } from "@react-navigation/stack";
import { useNavigation } from "@react-navigation/native";
import { useAuth } from "../AuthContext";
import Ionicons from "react-native-vector-icons/Ionicons";
import styles from "../constants/HomeScreen.styles";
import { SearchBar } from "@rneui/themed";
//import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";

import welcomeImage from "../assets/images/welcome.png";
const welcome_image = welcomeImage;

import groupIcon from "../assets/images/group-icon.png";
const group_icon = groupIcon;

import vaccineImage from "../assets/images/vaccine.png";
const vaccine_image = vaccine_image;

import ModelP from "./ModelP"; // Import the Page component

const Stack = createStackNavigator();


function HomeScreen() {
  const navigation = useNavigation();
  const { accessToken } = useAuth();
  const { removeToken } = useAuth();
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(false);
  const [isModalVisible, setModalVisible] = useState(false);
  const [search, setSearch] = useState("");

  useEffect(() => {
    // Update navigation header options
    navigation.setOptions({
      headerRight: () => (
        <TouchableOpacity
          onPress={createNewChat} // Call the function to create a new chat
          style={{ paddingRight: 10 }}
          disabled={loading}
        >
          {loading ? (
            <ActivityIndicator color={Colors.greenwa} size="small" />
          ) : (
            <Ionicons name="add-circle" size={28} color={Colors.greenwa} />
          )}
        </TouchableOpacity>
      ),
    });

    // Fetch chat list from local storage
    fetchChatListFromStorage().then((storedUsers) => {
      if (storedUsers && storedUsers.length > 0) {
        setUsers(storedUsers);
      } else {
        // If no stored data, fetch from API
        fetchChatList();
      }
    });
  }, [accessToken, navigation]);

  const fetchChatListFromStorage = async () => {
    try {
      const storedUsers = await AsyncStorage.getItem("users");
      return storedUsers ? JSON.parse(storedUsers) : [];
    } catch (e) {
      console.error("Failed to fetch users from storage:", e);
      return [];
    }
  };

  const fetchChatList = () => {
    setLoading(true);
    console.log("accessToken from Home.js : " + accessToken);
    return fetch(Keys.apiURLDisa + "/allchats", {
      headers: {
        Accept: "application/json",
        Authorization: `Bearer ${accessToken}`,
      },
    })
      .then((response) => response.json())
      .then((data) => {
        if (data && Array.isArray(data)) {
          const newUsers = data.map((chat) => ({
            id: chat.chat_id,
            name: chat.creator_name,
            avatar: group_icon, // Static image
            lastMessage: "Task ID ", // You may customize this
            timestamp: new Date(chat.created_at).toLocaleTimeString([], {
              hour: "2-digit",
              minute: "2-digit",
            }), // Format timestamp
          }));
          storeUsersData(newUsers);
          setUsers(newUsers);
        } else {
          console.log("Unexpected data format:", data);
        }
      })
      .catch((error) => console.error("Error fetching data:", error))
      .finally(() => setLoading(false));
  };

  const storeUsersData = async (usersData) => {
    try {
      const jsonUsers = JSON.stringify(usersData);
      await AsyncStorage.setItem("users", jsonUsers);
      console.log("Users data stored successfully!");
    } catch (e) {
      console.error("Failed to store users data:", e);
    }
  };

  const createNewChat = () => {
    setLoading(true);
    console.log("createNewChat status " + loading);

    fetch(Keys.apiURLDisa + "/chats", {
      method: "POST",
      headers: {
        Accept: "application/json",
        Authorization: `Bearer ${accessToken}`,
      },
    })
      .then((response) => response.json())
      .then((data) => {
        console.log("Chat created:", data);

        // Refresh chat list after creating a new chat
        fetchChatList().then(() => {
          navigation.navigate("Chat", {
            chatId: data.chat_id,
            userName: "New Chat",
          });
        });
      })
      .catch((error) => {
        console.error("Error creating chat:", error);
        alert("Error creating new chat!");
      })
      .finally(() => setLoading(false));
  };

  const updateSearch = (search) => {
    setSearch(search);
  };

  const handleLogout = async () => {
    await removeToken();
    navigation.navigate("IntroPage");
  };

  return (
    <View style={styles.container}>
      {loading ? (
        <View style={{ paddingTop: 5, paddingBottom: 5 }}>
          <ActivityIndicator color={Colors.greenwa} size="small" />
        </View>
      ) : (
        console.log("ActivityIndicator Mandate")
      )}
      <SearchBar
        platform="ios"
        containerStyle={{ height: 50 }}
        inputContainerStyle={{ height: 35, backgroundColor: Colors.searchHome }}
        placeholder="Search"
        placeholderTextColor="#888"
        round
        value={search}
        showCancel
        cancelButtonTitle="Cancel"
        searchIcon={
          <Ionicons name="search-outline" size={20} color={Colors.primary} />
        }
        onChangeText={updateSearch}
      />

      <ScrollView contentContainerStyle={styles.userList}>
        {users.map((user) => (
          <TouchableOpacity
            key={user.id}
            style={styles.userRow}
            onPress={() =>
              navigation.navigate("Chat", {
                chatId: user.id,
                userName: user.name,
              })
            }
          >
            <Image source={{ uri: user.avatar }} style={styles.avatar} />
            <View style={styles.userInfo}>
              <Text style={styles.userName}>{user.name}</Text>
              <Text style={styles.lastMessage}>
                {user.lastMessage + user.id}
              </Text>
            </View>
            <Text style={styles.timestamp}>{user.timestamp}</Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      <Modal
        visible={isModalVisible}
        animationType="slide"
        onRequestClose={() => setModalVisible(false)}
      >
        <ModelP />
        <TouchableOpacity
          style={{ padding: 10, backgroundColor: Colors.greenwa }}
          onPress={() => setModalVisible(false)}
        >
          <Text style={{ color: "white", textAlign: "center" }}>Close</Text>
        </TouchableOpacity>
      </Modal>
    </View>
  );
}

const Tab = createBottomTabNavigator();

export default function App() {
  return (
    // <NavigationContainer>
    <Tab.Navigator
      screenOptions={({ route }) => ({
        tabBarIcon: ({ focused, color, size }) => {
          let iconName;

          if (route.name === "Chats") {
            iconName = focused ? "chatbubbles" : "chatbubbles-outline";
          } else if (route.name === "Updates") {
            iconName = focused ? "disc" : "disc-outline";
          } else if (route.name === "Settings") {
            iconName = focused ? "settings" : "settings-outline";
          } else if (route.name === "More") {
            iconName = focused ? "help-circle" : "help-circle-outline";
          }

          // You can return any component that you like here!
          return <Ionicons name={iconName} size={size} color={color} />;
        },
        tabBarActiveTintColor: Colors.greenwa,
        tabBarInactiveTintColor: "gray",
      })}
    >
      <Tab.Screen
        name="Chats"
        component={HomeScreen}
        options={
          {
            // headerShown: false
          }
        }
      />


     
    </Tab.Navigator>
    // </NavigationContainer>
  );
}
