import React, { useEffect, useState } from "react";
import {
  View,
  ScrollView,
  Text,
  TouchableOpacity,
  Modal,
  TextInput,
  Button,
  ActivityIndicator,
  Image,
} from "react-native";
import { useNavigation } from "@react-navigation/native";
import Ionicons from "react-native-vector-icons/Ionicons";
import { SearchBar } from "@rneui/themed";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { createStackNavigator } from "@react-navigation/stack";
import { useAuth } from "../AuthContext";
import styles from "../constants/HomeScreen.styles";
import Colors from "../constants/Colors";


//import groupIcon from "https://cdn5.vectorstock.com/i/1000x1000/02/44/document-billing-icon-design-template-vector-29580244.jpg";//const group_icon = groupIcon;


const Stack = createStackNavigator();


const apiURLTEMP = "https://04d1d439-aa82-4245-858e-732db64bddc2-00-xfgvjquhwtgn.worf.replit.dev"


function HomeScreen() {
  const navigation = useNavigation();
  const { accessToken } = useAuth();
  const { removeToken } = useAuth();

  const [templates, setTemplates] = useState([]);
  const [loading, setLoading] = useState(false);
  const [isModalVisible, setModalVisible] = useState(false);
  const [search, setSearch] = useState("");
  const [newTemplate, setNewTemplate] = useState({
    industry: "",
    specialization: "",
    template_text: "",
  });
  const [selectedTemplate, setSelectedTemplate] = useState(null);

  useEffect(() => {
    fetchTemplates();

    // Update navigation header options
    navigation.setOptions({
      headerRight: () => (
        <TouchableOpacity
          onPress={() => setModalVisible(true)}
          style={{ paddingRight: 10 }}
        >
          <Ionicons name="add-circle" size={28} color={Colors.greenwa} />
        </TouchableOpacity>


        
      ),
    });
  }, [accessToken]);

  const fetchTemplates = () => {
    setLoading(true);
    fetch(
      apiURLTEMP + "/templates",
      {
        headers: {
          Accept: "application/json",
          Authorization: `Bearer ${accessToken}`,
        },
      }
    )
      .then((response) => response.json())
      .then((data) => {
        if (Array.isArray(data)) {
          setTemplates(data);
        } else {
          setTemplates([]);
          console.error("Fetched data is not an array:", data);
        }
      })
      .catch((error) => {
        console.error("Error fetching templates:", error);
        setTemplates([]);
      })
      .finally(() => setLoading(false));
  };

  const createTemplate = () => {
    setLoading(true);
    fetch(
      apiURLTEMP +  "/templates",
      {
        method: "POST",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
          Authorization: `Bearer ${accessToken}`,
        },
        body: JSON.stringify(newTemplate),
      }
    )
      .then((response) => response.json())
      .then((data) => {
        setTemplates([...templates, data]);
        setNewTemplate({ industry: "", specialization: "", template_text: "" });
        setModalVisible(false);
      })
      .catch((error) => console.error("Error creating template:", error))
      .finally(() => setLoading(false));
  };

  const updateTemplate = (template) => {
    setLoading(true);
    fetch(
      apiURLTEMP +  `/templates/${template.id}`,
      {
        method: "PUT",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
          Authorization: `Bearer ${accessToken}`,
        },
        body: JSON.stringify(template),
      }
    )
      .then((response) => response.json())
      .then((updatedTemplate) => {
        setTemplates(
          templates.map((t) =>
            t.id === updatedTemplate.id ? updatedTemplate : t
          )
        );
        setSelectedTemplate(null);
      })
      .catch((error) => console.error("Error updating template:", error))
      .finally(() => setLoading(false));
  };

  const handleLogout = async () => {
    await removeToken();
    navigation.navigate("IntroPage");
  };

  return (
    <View style={styles.container}>
      {loading && (
        <View style={styles.loaderContainer}>
          <ActivityIndicator color={Colors.greenwa} size="large" />
        </View>
      )}

      <ScrollView contentContainerStyle={styles.userList}>
        {templates.map((template) => (
          <TouchableOpacity
            key={template.id}
            style={styles.userRow}
            onPress={() => setSelectedTemplate(template)}
          >


           <Image source={{ uri: "https://i.ibb.co/TcdRwmH/images.png" }} style={styles.avatar} />
            <View style={styles.userInfo}>
              <Text style={styles.userName}>{template.industry}</Text>
              <Text style={styles.lastMessage}>{template.specialization}</Text>
            </View>
            <Text style={styles.timestamp}>
              {new Date(template.created_date).toLocaleDateString()}
            </Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      <Modal
        visible={isModalVisible}
        animationType="slide"
        onRequestClose={() => setModalVisible(false)}
      >
        <View style={styles.modalContainer}>
          <h1>Create Template</h1>
          <Text>{"\n"}</Text>

          <Text>Industry</Text>

          <TextInput
            placeholder="Industry"
            value={newTemplate.industry}
            onChangeText={(text) =>
              setNewTemplate({ ...newTemplate, industry: text })
            }
            style={styles.modalInput}
          />
          <Text>Specialization</Text>
          <TextInput
            placeholder="Specialization"
            value={newTemplate.specialization}
            onChangeText={(text) =>
              setNewTemplate({ ...newTemplate, specialization: text })
            }
            style={styles.modalInput}
          />

          <Text>Template</Text>
          <TextInput
            placeholder="Template Text"
            value={newTemplate.template_text}
            onChangeText={(text) =>
              setNewTemplate({ ...newTemplate, template_text: text })
            }
            style={[styles.modalInput, styles.templateTextInput]}
            multiline={true}
            numberOfLines={4}
          />

          <View style={[styles.modalButtons, { flexDirection: "row", justifyContent: "center" }]}>
            <Button
              title="Submit"
              onPress={createTemplate}
              disabled={loading} // Disable button while loading
            />
            &nbsp;
            <Button
              title="Cancel"
              onPress={() => setModalVisible(false)}
              disabled={loading} // Disable button while loading
            />
          </View>
        </View>
      </Modal>

      <Modal
        visible={!!selectedTemplate}
        animationType="slide"
        onRequestClose={() => setSelectedTemplate(null)}
      >
        <View style={styles.modalContainer}>
          {selectedTemplate && (
            <>
              <h1>Edit Template</h1>
              <Text>{"\n"}</Text>

              <Text>Industry</Text>
              <TextInput
                placeholder="Industry"
                value={selectedTemplate.industry}
                onChangeText={(text) =>
                  setSelectedTemplate({ ...selectedTemplate, industry: text })
                }
                style={styles.modalInput}
              />
              <Text>Specialization</Text>
              <TextInput
                placeholder="Specialization"
                value={selectedTemplate.specialization}
                onChangeText={(text) =>
                  setSelectedTemplate({
                    ...selectedTemplate,
                    specialization: text,
                  })
                }
                style={styles.modalInput}
              />
              <Text>Template</Text>
              <TextInput
                placeholder="Template Text"
                value={selectedTemplate.template_text}
                onChangeText={(text) =>
                  setSelectedTemplate({
                    ...selectedTemplate,
                    template_text: text,
                  })
                }
                style={[styles.modalInput, styles.templateTextInput]}
                multiline={true}
                numberOfLines={4}
              />
              <View style={[styles.modalButtons, { flexDirection: "row", justifyContent: "center" }]}>
                <Button
                  title="Submit"
                  onPress={() => updateTemplate(selectedTemplate)}
                  disabled={loading} // Disable button while loading
                />
                &nbsp;
                <Button
                  title="Cancel"
                  onPress={() => setSelectedTemplate(null)}
                  disabled={loading} // Disable button while loading
                />
              </View>
            </>
          )}
        </View>
      </Modal>
    </View>
  );
}


const Tab = createBottomTabNavigator();

export default function App() {
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        tabBarIcon: ({ focused, color, size }) => {
          let iconName;

          if (route.name === "Templates") {
            iconName = focused ? "chatbubbles" : "chatbubbles-outline";
          } else if (route.name === "Updates") {
            iconName = focused ? "disc" : "disc-outline";
          } else if (route.name === "Settings") {
            iconName = focused ? "settings" : "settings-outline";
          } else if (route.name === "More") {
            iconName = focused ? "help-circle" : "help-circle-outline";
          }

          return <Ionicons name={iconName} size={size} color={color} />;
        },
        tabBarActiveTintColor: Colors.greenwa,
        tabBarInactiveTintColor: "gray",
      })}
    >
      <Tab.Screen name="Templates" component={HomeScreen} />
    </Tab.Navigator>
  );
}
