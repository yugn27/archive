import { useState } from 'react';
import {
  View,
  Text,
  Linking,
  TouchableOpacity,
  KeyboardAvoidingView,
  Platform,
  TextInput,
  Alert,
  ActivityIndicator,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { useAuth } from '../AuthContext';
import Keys from '../constants/Keys';
import Colors from '../constants/Colors';
import styles from '../constants/SignInScreen.styles';

const PasswordReset = () => {
  const { setToken } = useAuth();
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const navigation = useNavigation();
  const keyboardVerticalOffset = Platform.OS === 'ios' ? 90 : 0;
  
  const openMailClient = () => {
    const mailUrl = `mailto:help@dizio.in?subject=Password Reset&body=I am having trouble resetting my password. Please assist.`;
    Linking.openURL(mailUrl);
  };

  const handlePasswordReset = async () => {
    setLoading(true); // Set loading state to true on button press

    if (newPassword !== confirmPassword) {
      Alert.alert(
        'Password Mismatch',
        'New password and confirm password do not match.'
      );
      setLoading(false);
      return;
    }

    try {
      const formData = new URLSearchParams();
      formData.append('new_password', newPassword);

      const response = await fetch(Keys.apiURLDisa + '/password-reset', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
          Accept: 'application/json',
        },
        body: formData.toString(),
      });

      if (!response.ok) {
        throw new Error('Failed to reset password');
      }

      const data = await response.json();
      console.log('Password Reset Response:', data);

      // Handle successful password reset (e.g., navigate to another screen or show a success message)
      Alert.alert('Success', 'Password reset successfully.');
      navigation.navigate('SignIn');
    } catch (error) {
      console.error('Password reset error:', error.message);
      Alert.alert(
        'Password Reset Failed',
        'Unable to reset password. Please try again later.'
      );
    } finally {
      setLoading(false); // Set loading state to false after request is complete
    }
  };

  const isFormValid =
    newPassword.trim() !== '' &&
    confirmPassword.trim() !== '' &&
    newPassword === confirmPassword;

  return (
    <KeyboardAvoidingView
      keyboardVerticalOffset={keyboardVerticalOffset}
      style={{ flex: 1 }}
      behavior="padding">
      <View style={styles.container}>
        <Text style={styles.description}>Enter your new password here.</Text>

        <View style={styles.list}>
          <TextInput
            style={styles.input}
            placeholder="New Password"
            placeholderTextColor="#000000"
            value={newPassword}
            onChangeText={setNewPassword}
            secureTextEntry
          />
          <TextInput
            style={styles.input}
            placeholder="Confirm Password"
            placeholderTextColor="#000000"
            value={confirmPassword}
            onChangeText={setConfirmPassword}
            secureTextEntry
          />
        </View>

        <Text style={styles.legal}>
          <Text style={styles.link} onPress={openMailClient}>
            Can't reset your password?
          </Text>{' '}
          Send us an email for assistance.
        </Text>

        <View style={{ flex: 1 }} />

        <TouchableOpacity
          style={[
            styles.button,
            {
              marginBottom: 20,
              backgroundColor:
                loading || !isFormValid ? 'grey' : Colors.greenwa,
            },
          ]}
          onPress={handlePasswordReset}
          disabled={loading || !isFormValid} // Disable the button when loading is true or form is not valid
        >
          {loading ? (
            <ActivityIndicator color={Colors.white} size="large" />
          ) : (
            <Text style={[styles.buttonText, styles.enabled]}>
              Reset Password
            </Text>
          )}
        </TouchableOpacity>
      </View>
    </KeyboardAvoidingView>
  );
};

export default PasswordReset;
