import { useEffect, useState } from "react";
import Colors from "../constants/Colors";
import { defaultStyles } from "../constants/Styles";
import BoxedIcon from "../components/BoxedIcon";
import Keys from "../constants/Keys";

//import AsyncStorage from "@react-native-async-storage/async-storage";

import AsyncStorage from "@react-native-async-storage/async-storage";
import {
  Image,
  Text,
  TouchableOpacity,
  View,
  ScrollView,
  FlatList,
  ActivityIndicator,
  Modal,
} from "react-native";
import { createStackNavigator } from "@react-navigation/stack";
import { useNavigation } from "@react-navigation/native";
import { useAuth } from "../AuthContext";
import Ionicons from "react-native-vector-icons/Ionicons";
import styles from "../constants/HomeScreen.styles";
import { SearchBar } from "@rneui/themed";

//import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';

import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";

import welcomeImage from "../assets/images/welcome.png";
const welcome_image = Image.resolveAssetSource(welcomeImage).uri;

import groupIcon from "../assets/images/group-icon.png";
const group_icon = Image.resolveAssetSource(groupIcon).uri;

import vaccineImage from "../assets/images/vaccine.png";
const vaccine_image = Image.resolveAssetSource(vaccineImage).uri;

import ModelP from "./ModelP"; // Import the Page component

const Stack = createStackNavigator();


function HomeScreen() {
  const navigation = useNavigation();
  const { accessToken } = useAuth();
  const { removeToken } = useAuth();
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(false);
  const [isModalVisible, setModalVisible] = useState(false);

  useEffect(() => {
    navigation.setOptions({
      headerRight: () => (
        <TouchableOpacity
          onPress={createNewChat}
          style={{ paddingRight: 10 }}
          disabled={loading}
        >
          {loading ? (
            <ActivityIndicator color={Colors.greenwa} size="small" />
          ) : (
            <Ionicons name="add-circle" size={28} color={Colors.greenwa} />
          )}
        </TouchableOpacity>
      ),
    });

    // Load chat list from local storage first
    loadChatListFromStorage();
    // Then fetch updated chat list from API
    fetchChatList();
  }, [accessToken, navigation]);

  const loadChatListFromStorage = async () => {
    try {
      const storedUsers = await AsyncStorage.getItem('chatList');
      if (storedUsers) {
        setUsers(JSON.parse(storedUsers));
      }
    } catch (error) {
      console.error('Error loading chat list from storage:', error);
    }
  };




const fetchChatList = () => {
    console.log("accessToken from Home.js : " + accessToken);
    return fetch(Keys.apiURLDisa + "/allchats", {
      headers: {
        Accept: "application/json",
        Authorization: `Bearer ${accessToken}`,
      },
    })
      .then((response) => response.json())
      .then((data) => {
        console.log("Fetched data: ", data);
        if (data && Array.isArray(data)) {
          const newUsers = data.map((chat) => ({
            id: chat.chat_id,
            name: chat.creator_name,
            avatar: group_icon,
            lastMessage: "Task ID ",
            timestamp: new Date(chat.created_at).toLocaleTimeString([], {
              hour: "2-digit",
              minute: "2-digit",
            }),
          }));

          setUsers(newUsers);
          storeChatListData(newUsers);
        } else {
          console.log("Unexpected data format:", data);
        }
      })
      .catch((error) => console.error("Error fetching data:", error));
  };

  const storeChatListData = async (chatListData) => {
    try {
      const jsonChatList = JSON.stringify(chatListData);
      await AsyncStorage.setItem("chatList", jsonChatList);
      console.log("Chat list data stored successfully!");
    } catch (e) {
      console.error("Failed to store chat list data:", e);
    }
  };

  const createNewChat = () => {
    setLoading(true);
    console.log("createNewChat status " + loading);

    fetch(Keys.apiURLDisa + "/chats", {
      method: "POST",
      headers: {
        Accept: "application/json",
        Authorization: `Bearer ${accessToken}`,
      },
    })
      .then((response) => response.json())
      .then((data) => {
        console.log("Chat created:", data);

        fetchChatList().then(() => {
          navigation.navigate("Chat", {
            chatId: data.chat_id,
            userName: "New Chat",
          });
          setLoading(false);
        });
      })
      .catch((error) => {
        console.error("Error creating chat:", error);
        alert("Error creating new chat!");
        setLoading(false);
      });
  };

  state = {
    search: "",
  };

  updateSearch = (search) => {
    this.setState({ search });
  };

  const { search } = this.state;

  // Function to store users data in AsyncStorage
  const storeUsersData = async (usersData) => {
    try {
      const jsonUsers = JSON.stringify(usersData);
      await AsyncStorage.setItem("users", jsonUsers);
      //console.log("Users data stored successfully!");
    } catch (e) {
      console.error("Failed to store users data:", e);
    }
  };

  return (
    <View style={styles.container}>
      {loading ? (
        <View style={{ paddingTop: 5, paddingBottom: 5 }}>
          <ActivityIndicator color={Colors.greenwa} size="small" />
        </View>
      ) : (
        console.log("ActivityIndicator Mandate")
      )}
      <SearchBar
        platform="ios"
        containerStyle={{ height: 50 }} // Decrease the height of the search bar container
        inputContainerStyle={{ height: 35, backgroundColor: Colors.searchHome }}
        inputStyle={{}}
        leftIconContainerStyle={{}}
        rightIconContainerStyle={{}}
        loadingProps={{}}
        onChangeText={(newVal) => setValue(newVal)}
        onClearText={() => console.log("Clear text")}
        placeholder="Search"
        placeholderTextColor="#888"
        round
        value={search}
        showCancel
        cancelButtonTitle="Cancel"
        cancelButtonProps={{}}
        onCancel={() => console.log("Cancel search")}
        searchIcon={
          <Ionicons name="search-outline" size={20} color={Colors.primary} />
        } // Correctly use search icon
      />

      <Stack.Screen
        name="index"
        options={{
          title: "Settings",
          headerLargeTitle: true,
          headerShadowVisible: false,
          headerStyle: { backgroundColor: Colors.background },
          headerSearchBarOptions: {
            placeholder: "Search",
          },
          headerRight: () => <Text style={styles.userName}>yash</Text>,
        }}
      />

      {/* User List */}
      <ScrollView contentContainerStyle={styles.userList}>
        {users.map((user) => (
          <TouchableOpacity
            key={user.id}
            style={styles.userRow}
            // Update the onPress function in HomeScreen
            onPress={() =>
              navigation.navigate("Chat", {
                chatId: user.id,
                userName: user.name,
              })
            }
          >
            <Image source={{ uri: user.avatar }} style={styles.avatar} />
            <View style={styles.userInfo}>
              <Text style={styles.userName}>{user.name}</Text>
              <Text style={styles.lastMessage}>
                {user.lastMessage + user.id}
              </Text>
            </View>
            <Text style={styles.timestamp}>{user.timestamp}</Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      {/* Modal for showing the Page component */}
      <Modal
        visible={isModalVisible}
        animationType="slide"
        onRequestClose={() => setModalVisible(false)}
      >
        <ModelP />
        <TouchableOpacity
          style={{ padding: 10, backgroundColor: Colors.greenwa }}
          onPress={() => setModalVisible(false)}
        >
          <Text style={{ color: "white", textAlign: "center" }}>Close</Text>
        </TouchableOpacity>
      </Modal>
    </View>
  );
}

// Example static data
const newsData = [
  {
    id: "1",
    title: "Latest COVID-19 Vaccine Updates Approaches",
    summary:
      "A look at innovative treatment strategies for heart disease, featuring insights from leading cardiologists.",
    date: "2024-05-10",
    imageUrl: vaccine_image,
  },
  {
    id: "2",
    title: "Heart Disease: New Treatment Approaches",
    summary:
      "A look at innovative treatment strategies for heart disease, featuring insights from leading cardiologists.",
    date: "2024-05-09",
    imageUrl: vaccine_image,
  },
  {
    id: "3",
    title: "Advances in Neurological Disorders",
    summary:
      "Recent breakthroughs in the treatment of neurological disorders, including Alzheimer's and Parkinson's disease.",
    date: "2024-05-08",
    imageUrl: vaccine_image,
  },
  // Add more news items as needed
];

const NewsItem = ({ item }) => (
  <TouchableOpacity style={styles.newsItem}>
    <Image source={{ uri: item.imageUrl }} style={styles.newsImage} />
    <View style={styles.newsTextContainer}>
      <Text style={styles.newsTitle}>{item.title}</Text>
      <Text style={styles.newsSummary}>{item.summary}</Text>
      <Text style={styles.newsDate}>{item.date}</Text>
    </View>
  </TouchableOpacity>
);

function UpdateScreen() {
  return (
    <View style={styles.container}>
      <FlatList
        data={newsData}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => <NewsItem item={item} />}
      />
    </View>
  );
}

const settingsPageData = {
  devices: [
    {
      name: "Industry",
      icon: "golf-outline",
      backgroundColor: Colors.green,
    },
    {
      name: "Function",
      icon: "funnel-outline",
      backgroundColor: Colors.yellow,
    },
  ],
  items: [
    {
      name: "Languages",
      icon: "language-outline",
      backgroundColor: Colors.primary,
    },
    {
      name: "Clear All Chats",
      icon: "trash-outline",
      backgroundColor: "#33A5D1",
    },
    {
      name: "Delete Account",
      icon: "trash-outline",
      backgroundColor: Colors.green,
    },
    {
      name: "Notifications",
      icon: "notifications",
      backgroundColor: Colors.red,
    },
  ],
  support: [
    {
      name: "Help",
      icon: "information",
      backgroundColor: Colors.primary,
    },
    {
      name: "Tell a Friend",
      icon: "heart",
      backgroundColor: Colors.red,
    },
  ],
};

function SettingsScreen() {

  const { removeToken } = useAuth();
  const navigation = useNavigation();

  const handleLogout = async () => {
    await removeToken();
    navigation.navigate('IntroPage');
  };
  
  return (
    <View style={{ flex: 1, backgroundColor: Colors.background }}>
      <ScrollView
        contentInsetAdjustmentBehavior="automatic"
        contentContainerStyle={{ paddingBottom: 40 }}
      >
        {Object.keys(settingsPageData).map((key) => (
          <View style={defaultStyles.block} key={key}>
            <FlatList
              data={settingsPageData[key]}
              scrollEnabled={false}
              ItemSeparatorComponent={() => (
                <View style={defaultStyles.separator} />
              )}
              renderItem={({ item }) => (
                <View style={defaultStyles.item}>
                  <BoxedIcon
                    name={item.icon}
                    backgroundColor={item.backgroundColor}
                  />
                  <Text style={{ fontSize: 18, flex: 1 }}>{item.name}</Text>
                  <Ionicons
                    name="chevron-forward"
                    size={20}
                    color={Colors.gray}
                  />
                </View>
              )}
            />
          </View>
        ))}

        <TouchableOpacity onPress={handleLogout}>
          <Text style={styles.logoutText}>Log Out</Text>
        </TouchableOpacity>
      </ScrollView>
    </View>
  );
}

function MoreScreen() {
  const openLink = () => {
    Linking.openURL(Keys.urlDisaHome);
  };

  return (
    <ScrollView style={styles.container}>
    
      <Image source={{ uri: welcome_image }} style={styles.welcome} />
      <Text style={styles.headline}>About Disa</Text>
      <Text style={styles.description}>
        Discover the power of understanding your data with Disa App, your go-to
        AI tool that makes sense of complex information easily and quickly.{" "}
        {"\n"}
      </Text>

      <Text style={styles.description}>Version 2024.05.06 {"\n"}</Text>
      <Text style={styles.description}>ⓒ 2024 Disa </Text>
      </ScrollView>
  );
}

const Tab = createBottomTabNavigator();

export default function App() {
  return (
    // <NavigationContainer>
    <Tab.Navigator
      screenOptions={({ route }) => ({
        tabBarIcon: ({ focused, color, size }) => {
          let iconName;

          if (route.name === "Chats") {
            iconName = focused ? "chatbubbles" : "chatbubbles-outline";
          } else if (route.name === "Updates") {
            iconName = focused ? "disc" : "disc-outline";
          } else if (route.name === "Settings") {
            iconName = focused ? "settings" : "settings-outline";
          } else if (route.name === "More") {
            iconName = focused ? "help-circle" : "help-circle-outline";
          }

          // You can return any component that you like here!
          return <Ionicons name={iconName} size={size} color={color} />;
        },
        tabBarActiveTintColor: Colors.greenwa,
        tabBarInactiveTintColor: "gray",
      })}
    >
      <Tab.Screen
        name="Chats"
        component={HomeScreen}
        options={
          {
            // headerShown: false
          }
        }
      />

      <Tab.Screen name="Updates" component={UpdateScreen} />
      <Tab.Screen
        name="Settings"
        component={SettingsScreen}
        options={{
          tabBarBadge: 3,
          tabBarBadgeStyle: { backgroundColor: "green", color: "white" },
        }}
      />
      <Tab.Screen name="More" component={MoreScreen} />
    </Tab.Navigator>
    // </NavigationContainer>
  );
}
