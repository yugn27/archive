import { StyleSheet } from "react-native";
import Colors from "./Colors";

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  userList: {
    padding: 10,
  },
  userRow: {
    flexDirection: "row",
    alignItems: "center",
    padding: 10,
    borderBottomWidth: 1,
    borderBottomColor: Colors.lightGray,
  },
  avatar: {
    width: 50,
    height: 50,
    borderRadius: 25,
  },
  userInfo: {
    flex: 1,
    marginLeft: 10,
  },
  userName: {
    fontSize: 16,
    fontWeight: "bold",
  },
  lastMessage: {
    fontSize: 14,
    color: Colors.gray,
  },
  timestamp: {
    fontSize: 12,
    color: Colors.gray,
  },

  //news
  container: {
    flex: 1,
    backgroundColor: "#FFF",
  },
  newsItem: {
    flexDirection: "row",
    padding: 10,
    borderBottomWidth: 1,
    borderBottomColor: Colors.lightGray,
  },
  newsImage: {
    width: "35%",
    height: "100%",
    borderRadius: 15,
    marginRight: 10,
  },
  newsTextContainer: {
    flex: 1,
  },
  newsTitle: {
    fontSize: 18,
    fontWeight: "bold",
    marginBottom: 5,
  },
  newsSummary: {
    fontSize: 14,
    color: Colors.gray,
  },
  newsDate: {
    fontSize: 12,
    color: Colors.lightGray,
    marginTop: 5,
  },
  logoutText: {
    color: Colors.primary,
    fontSize: 18,
    textAlign: "center",
    paddingVertical: 14,
  },
  welcome: {
    width: "100%",
    height: 300,
    borderRadius: 60,
    marginBottom: 80,
  },
  headline: {
    fontSize: 24,
    fontWeight: "bold",
    marginVertical: 20,
    textAlign: "center",
  },
  description: {
    fontSize: 14,
    textAlign: "center",
    //marginBottom: 80,
    color: Colors.gray,
    paddingHorizontal: 10,
  },
  accessToken: {
    fontSize: 18,
    marginBottom: 10,
  },




  //new

   container: {
    flex: 1,
    backgroundColor: "#fff",
    padding: 10,
  },
  userList: {
    flexGrow: 1,
  },
  userRow: {
    flexDirection: "row",
    alignItems: "center",
    padding: 10,
    borderBottomWidth: 1,
    borderBottomColor: Colors.lightGray,
  },
  userInfo: {
    flex: 1,
  },
  userName: {
    fontSize: 18,
    fontWeight: "bold",
    marginBottom: 5,
  },
  lastMessage: {
    color: Colors.darkGray,
  },
  timestamp: {
    fontSize: 12,
    color: Colors.gray,
  },
  modalContainer: {
    flex: 1,
    justifyContent: "center",
    padding: 20,
    backgroundColor: "#fff",
  },
  modalInput: {
    marginBottom: 10,
    padding: 10,
    borderWidth: 1,
    borderColor: Colors.lightGray,
    borderRadius: 5,
  },
  templateTextInput: {
    height: 100,
    textAlignVertical: "top",
  },
  modalButtons: {
    flexDirection: "row",
    justifyContent: "space-around",
  },
});

export default styles;
