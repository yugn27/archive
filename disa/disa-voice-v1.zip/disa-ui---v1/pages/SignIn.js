import React, { useState } from 'react';

import Colors from '../constants/Colors';
import { Ionicons } from '@expo/vector-icons';
import { View, Text, StyleSheet, Linking, TouchableOpacity, KeyboardAvoidingView, Platform, ScrollView , TextInput, Button } from 'react-native';
import MaskInput from 'react-native-mask-input';
import { createStackNavigator } from '@react-navigation/stack';
import { NavigationContainer } from '@react-navigation/native';


const SignIn = ({ navigation }) => {


  
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [mobileNumber, setMobileNumber] = useState('');
  const [corporateCode, setCorporateCode] = useState('');
  const [password, setPassword] = useState('');
  const keyboardVerticalOffset = Platform.OS === 'ios' ? 90 : 0;

  const openLink = () => {
    Linking.openURL('https://example.com/');
  };

  const handleSignIn = () => {
    // Handle sign up logic here
   
    console.log('Mobile Number:', mobileNumber);
   
    console.log('Password:', password);
  };

  return (
    <KeyboardAvoidingView
      keyboardVerticalOffset={keyboardVerticalOffset}
      style={{ flex: 1 }}
      behavior="padding">
      <View style={styles.container}>
        <Text style={styles.description}>
          Please enter your details to sign in.
        </Text>

        <View style={styles.list}>
         

        
          <TextInput
            style={styles.input}
            placeholder="Mobile Number"
            placeholderTextColor="#000000"  
            value={mobileNumber}
            onChangeText={setMobileNumber}
            keyboardType="phone-pad"
          />

          <TextInput
            style={styles.input}
            placeholder="Password"
            placeholderTextColor="#000000"  
            value={password}
            onChangeText={setPassword}
            secureTextEntry
          />
        </View>

        <Text style={styles.legal}>
          You must be{' '}
          <Text style={styles.link} onPress={openLink}>
            at least 16 years old
          </Text>{' '}
          to register. Learn how Disa works with the{' '}
          <Text style={styles.link} onPress={openLink}>
            Disa Solutions
          </Text>
          .
        </Text>

        <View style={{ flex: 1 }} />

        <TouchableOpacity
          style={[styles.button, { marginBottom: 20 }]}
         onPress={() => navigation.navigate('Home', { name: 'Home' })}>
          <Text style={[styles.buttonText, styles.enabled]}>Sign In</Text>
        </TouchableOpacity>
      </View>
    </KeyboardAvoidingView>
  );
};


const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    padding: 20,
    backgroundColor: Colors.background,
    gap: 20,
  },
  description: {
    fontSize: 14,
    color: Colors.gray,
  },
  legal: {
    fontSize: 12,
    textAlign: 'center',
    color: '#000',
  },
  link: {
    color: Colors.primary,
  },
  button: {
    width: '100%',
    alignItems: 'center',
    backgroundColor: Colors.greenwa,
    padding: 10,
    borderRadius: 10,
   
  },
  
  buttonText: {
    color: Colors.white,
    fontSize: 22,
    fontWeight: '500',
  },
  list: {
    backgroundColor: '#fff',
    width: '100%',
    borderRadius: 10,
    padding: 10,
    gap: 10,
  },
  input: {
    backgroundColor: '#f2f2f2',
    width: '100%',
    fontSize: 16,
    padding: 10,
    borderRadius: 5,
  },
});


export default SignIn;

